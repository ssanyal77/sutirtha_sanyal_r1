This is a full-system simulator implementation of Hardware Transactional Memory (HTM).
The base simulator is M5[1]. The architecture is Alpha 21264. The HTM policy follows lazy conflict detection and lazy versioning (LL). 
Conflicts between multiple threads are detected at the commit time and versions are upgraded when a transaction commits. 
If multiple threads accessed disjoint sets of data, they can commit in parallel. Among conflicting threads, which starts commit first 
continues causing others to abort.

For compilation and execution of M5, please consult M5 documentation. 
For invoking the CPU model supporting HTM, add --transact switch along with other options in the command line.

For testing, transactional codes could be written using posix threads. The transaction starts with a special assembly instruction 
(__asm__("xor $31, $0, $31")) 
and ends with another special instruction (__asm__("xor $31, $1, $31")). 
The code should be cross-compiled for alpha.
The applications from the STAMP benchmark[2] suite are included in the directory benchmarks/htm.




[1] N.L. Binkert, R.G. Dreslinski, L.R. Hsu, K.T. Lim, A.G. Saidi, and S.K.
Reinhardt. The M5 Simulator: Modeling Networked Systems. IEEE
MICRO, pages 52�60, 2006.

[2] Chi Cao Minh, JaeWoong Chung, Christos Kozyrakis, and Kunle
Olukotun. Stamp: Stanford transactional applications for multiprocessing.
In IISWC �08: Proceedings of The IEEE International
Symposium on Workload Characterization, September 2008.
