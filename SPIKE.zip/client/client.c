//Author - Sutirtha Sanyal
#include <stdio.h>
#include <stdlib.h>
#define __USE_LARGEFILE64
#define __USE_FILE_OFFSET64
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>
#include <signal.h>
#include <termios.h>
#include <inttypes.h>
#define MAXINOUTBUF 51200
#define KEY_SIZE 16
#define EXPANDED_KEY_SIZE 176
#define INIT_ATTEMPT 5
unsigned char have_key='N';
unsigned char validity[4];
unsigned char session_key_expanded[EXPANDED_KEY_SIZE];
char filename[256];
int fd;
void (*intr_handler)(int);
void (*term_handler)(int);
void  aes_128_encrypt_cbc(void * input, void * key, void * iv, size_t datasize,void * output);
void  aes_128_decrypt_cbc(void * input, void * key, void * iv, size_t datasize,void * output);
void  aes_128_n_encrypt_cbc(void * input, void * key, void * iv, size_t datasize,void * output);
void  aes_128_n_decrypt_cbc(void * input, void * key, void * iv, size_t datasize,void * output);
void expandkey (void* key, void * expanded_key);
void cleanup(int sig);
void generate_one_nonce(unsigned char nonce[KEY_SIZE])
{
  int i;
  for (i=0;i<KEY_SIZE;i++)
    nonce[i]=rand()%256;
}
void construct_addr(char * name,char * portno,struct addrinfo * addr)
{
  struct addrinfo hints, *servinfo=NULL;
  int rv;
  memset((void*)&hints, 0, sizeof (hints));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_DGRAM;
  if((rv=getaddrinfo(name, portno, &hints, &servinfo))!=0)
    {
      fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
      exit(1);
    }
  *addr=*servinfo;
}
int still_valid(int fp_key)
{
  struct stat st;
  fstat(fp_key,&st);
  int val;
  memcpy(&val,validity,4);
  time_t mod=st.st_mtime;
  time_t nw;
  time(&nw);
  if(nw-mod>val)
    return 0;
  return 1;
}
void printblank()
{
  int i;
  for (i=0;i<25;i++)
    {
      printf("\b");
    }
}
void printline(int x)
{
  int i;
  unsigned char ch='\%';
  printf("[");
  for (i=0;i<20;i++)
    {
      if (i<x/5)
	{
	  printf(".");
	  continue;
	}
      printf(" ");
    }
  printf("]");
  printf("%d",x);
  printf("%c",ch);
}
void start_display(void)
{
  short i;
  char ch='\%';
  printf("[");
  for (i=0;i<20;i++)
    {
      printf(" ");
    }
  printf("]");
  printf("0%c",ch);
}
void showprogress(int x)
{
  static int prev=0;
  char ch='\%';
  int y=x/5;
  if (y>prev)
    {
      prev=y;
      printblank();
      printline(x);
      fflush(stdout);
    }
  else
    {
      if(x<10)
	{
	  printf("\b\b");
	  printf("%d%c",x,ch);
	  fflush(stdout);
	}
      else
	{
	  printf("\b\b\b");
	  printf("%d%c",x,ch);
	  fflush(stdout);
	}
    }
}
void restore_handlers()
{
  signal(SIGINT,intr_handler);
  signal(SIGTERM,term_handler);
}
void cleanup(int sig)
{
  close(fd);
  char delstr[261];
  memset(delstr,0,sizeof(delstr));
  strcat(delstr,"rm ");
  strcat(delstr,"\"");
  strcat(delstr,filename);
  strcat(delstr,"\"");
  if (system(delstr)!=0)
    {
      restore_handlers();
      exit(1);
    }
  printf("\n");
  restore_handlers();
  exit(1);
}
int main(int argc, char **argv)
{
  int sockfd;
  struct addrinfo hints, *servinfo, *p;
  int rv; int buffersize=MAXINOUTBUF;
  unsigned char  buf[500],buf_serv[MAXINOUTBUF],buf2_serv[MAXINOUTBUF];
  struct addrinfo as_addr;
  struct addrinfo s_addr;
  struct sockaddr_storage as_addr_storage;
  struct sockaddr_storage s_addr_storage;
  unsigned char clientid[40];
  unsigned  char serverid[40];
  unsigned char iv_aes[16];
  unsigned char nonce[KEY_SIZE];
  unsigned char encrypted_nonce[KEY_SIZE];
  unsigned char clientsecret[KEY_SIZE];
  char verbose=0;
  struct timeval rcvwt;
  srand(time(NULL)+1);
  memset(buf,'\0',sizeof(buf));
  memset(clientsecret,'\0',KEY_SIZE);
  if ((argc != 8 || strcmp(argv[1],"-v")==0 || strlen(argv[7])>=40 || strlen(argv[6])>=256) && 
      (argc!= 9 || (strcmp(argv[1],"-v")==0 && (strlen(argv[7])>=256 || strlen(argv[8])>=40)) || ((strcmp(argv[1],"-v")!=0) && (strlen(argv[6])>=256 || strlen(argv[7])>=40 || strlen(argv[8])>KEY_SIZE)))
      && (argc!= 10 || strcmp(argv[1],"-v")!=0 || strlen(argv[7])>=256 || strlen(argv[8])>=40 || strlen(argv[9])>KEY_SIZE)) 
    {
      fprintf(stderr,"usage: ./client <-v> IP KMSIP KMSPort  ServerIP ServerPort Filename ClientID <Password>\n");
      exit(1);
    }
  if (argc==8 || (argc==9 && strcmp(argv[1],"-v")==0))
    {
      printf("Password:");
      struct termios old,new;
      tcgetattr(STDIN_FILENO,&old);
      memcpy((void*)&new,(void*)&old,sizeof(struct termios));
      new.c_lflag &= ~ECHO;
      tcsetattr(STDIN_FILENO,TCSANOW,&new);
      if(!scanf("%s",clientsecret))
	exit(1);
      tcsetattr(STDIN_FILENO,TCSANOW,&old);
      printf("\n"); 
    }
  else
    if(argc==9)
      memcpy(clientsecret,argv[8],strlen(argv[8])); 
    else
      memcpy(clientsecret,argv[9],strlen(argv[9])); 
  if (strcmp(argv[1],"-v")==0)
    verbose=1;
  rcvwt.tv_sec=1;rcvwt.tv_usec=0; 
  memset((void*)&hints, 0, sizeof (hints));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_DGRAM;
  int portint;
  char port [5];
  port[4]='\0';
  while(1)
    {
      portint=rand()%7000+1000;
      sprintf(port,"%d",portint); 
      if ((rv = getaddrinfo(strcmp(argv[1],"-v")==0?argv[2]:argv[1], port, &hints, &servinfo)) != 0) 
	{
	  continue;
	}
      for(p = servinfo; p != NULL; p = p->ai_next) 
	{
	  if ((sockfd = socket(p->ai_family, p->ai_socktype,
			       p->ai_protocol)) == -1) 
	    {
	      continue;
	    }
	  setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(void *)&rcvwt,sizeof(rcvwt));
	  setsockopt(sockfd,SOL_SOCKET,SO_RCVBUF,(void *)&buffersize,sizeof(buffersize));
	  if (bind(sockfd,p->ai_addr,p->ai_addrlen) == -1) 
	    {
	      close(sockfd);
	      continue;
	    }
	  break;
	}
      if (p == NULL) 
	{
	  continue;
	}
      break;
    }
  memset((void*)clientid, '\0', 40);
  if(strcmp(argv[1],"-v")!=0)
    {
      memcpy(clientid,argv[7],strlen(argv[7]));
      construct_addr(argv[2],argv[3],&as_addr);
      construct_addr(argv[4],argv[5],&s_addr);
    }
  else
    {
      memcpy(clientid,argv[8],strlen(argv[8]));
      construct_addr(argv[3],argv[4],&as_addr);
      construct_addr(argv[5],argv[6],&s_addr);    
    }
  as_addr_storage=*((struct sockaddr_storage*)as_addr.ai_addr);
  s_addr_storage=*((struct sockaddr_storage*)s_addr.ai_addr);
  socklen_t as_addr_storage_length = sizeof(as_addr_storage);
  socklen_t s_addr_storage_length = sizeof(s_addr_storage);
  memset((void*)iv_aes, '\0', 16);
  char numattempt=0;
  while(numattempt<INIT_ATTEMPT)
    {
      memset(buf,'\0',41);
      buf[0]='N';
      memcpy((void*)(buf+1),(void*)clientid,40);
      if (sendto(sockfd, buf , 41, 0, (struct sockaddr*)&s_addr_storage, s_addr_storage_length)==-1)
	{
	  printf("%s\n",strerror(errno));
	  exit(1);
	}
      if(  recvfrom(sockfd, buf, 41, 0, (struct sockaddr*)&s_addr_storage, &s_addr_storage_length)==-1)
	{
	  numattempt++;
	  if(numattempt==INIT_ATTEMPT){
	    printf("Server unreachable.\n");
	    exit(1);
	  }
	}
      else
	break;
    }
  unsigned char message_type;
  if (buf[0]=='Y')
    {
      char filenm[56];
      sprintf(filenm,"session_key.out.%s",clientid);
      int fp_key=open(filenm,O_RDONLY);
      if(fp_key==-1) close(fp_key);
      else
	{
	  unsigned char buf_temp[EXPANDED_KEY_SIZE];
	  if(!read(fp_key,buf_temp,KEY_SIZE))
	    exit(1);
	  aes_128_decrypt_cbc(buf_temp,clientsecret,iv_aes,4,validity);
	  if (still_valid(fp_key))
	    {
	      have_key='Y';
	      memset(buf_temp,0,EXPANDED_KEY_SIZE);
	      if(!read(fp_key,buf_temp,EXPANDED_KEY_SIZE))
		exit(1);
	      aes_128_decrypt_cbc(buf_temp,clientsecret,iv_aes,EXPANDED_KEY_SIZE,session_key_expanded);
	    }
	  else
	    {
	      memset(validity,0,4);
	      memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
	      have_key='N';
	    }
	  close(fp_key);
	}
      generate_one_nonce(nonce);
      aes_128_encrypt_cbc((void *)nonce,(void *)clientsecret,(void *)iv_aes,sizeof(nonce),(void *)encrypted_nonce);
      message_type=3;
      memset((void*)serverid, '\0', 40);
      memcpy((void*)serverid,(void*)(buf+1),40);
      memset((void*)buf, '\0', 200);
      memcpy((void*)(buf),(void *)&message_type,1);
      memcpy((void*)(buf+1),(void *)clientid,40);
      memcpy((void*)(buf+41),(void *)serverid,40);
      memcpy((void*)(buf+81),(void *)&have_key,1);
      memcpy((void*)(buf+82),(void *)encrypted_nonce, 16);
      aes_128_encrypt_cbc((void *)encrypted_nonce,(void *)clientsecret,(void *)iv_aes,sizeof(nonce),(void *)nonce);
      memcpy((void*)(buf+98),(void *)nonce, 16);
      aes_128_decrypt_cbc((void *)encrypted_nonce,(void *)clientsecret,(void *)iv_aes,sizeof(nonce),(void *)nonce);
      if (sendto(sockfd, buf ,114 , 0, (struct sockaddr*)&as_addr_storage, as_addr_storage_length)==-1)
	{
	  printf("%s\n",strerror(errno));
	  exit(1);
	}
      memset(buf,0,sizeof(buf));
      unsigned char test_buf[48];
      memset(test_buf,0,48);
      if(recvfrom(sockfd, buf, 80, 0, (struct sockaddr*)&as_addr_storage, &as_addr_storage_length)==-1)
	{
	  printf("Password incorrect or KMS unreachable.\n");
	  exit(1);
	}
      if(memcmp(buf+32,test_buf,48)==0) 
	{
	  if (buf[0]=='N' && buf[1]=='F')
	    {
	      printf("Client id incorrect.\n");
	      exit(1);
	    }
	  unsigned char decrypted_message5[17];
	  memset((void*)iv_aes, '\0', 16);
	  aes_128_decrypt_cbc((void*)buf,(void *)clientsecret,(void *)iv_aes,17,(void *)decrypted_message5);
	  unsigned char decrypted_nonce[KEY_SIZE];
	  unsigned char more_message;
	  memcpy((void*)&more_message,(void*)(decrypted_message5),1);
	  memcpy((void*)decrypted_nonce,(void*)(decrypted_message5+1),KEY_SIZE);
	  if (more_message=='Y')
	    {
	      memset((void*)buf, '\0', 200);
	      message_type=7;
	      memcpy((void*)(buf),(void *)&message_type,1);
	      memcpy((void*)(buf+1),(void *)clientid,40);
	      memcpy((void*)(buf+41),(void *)serverid,40);
	      memset((void*)iv_aes, '\0', 16);
	      short i;
	      for (i=0;i<KEY_SIZE;i++)
		decrypted_nonce[i]=decrypted_nonce[i]+1;
	      aes_128_encrypt_cbc((void *)decrypted_nonce,(void *)clientsecret,(void *)iv_aes,sizeof(nonce),(void *)encrypted_nonce);
	      memcpy((void*)(buf+81),(void *)encrypted_nonce, 16);
	      if (sendto(sockfd, buf ,97 , 0, (struct sockaddr*)&as_addr_storage, as_addr_storage_length)==-1)
		{
		  printf("%s\n",strerror(errno));
		  exit(1);
		}
	      if (recvfrom(sockfd, buf ,80 , 0, (struct sockaddr*)&as_addr_storage, &as_addr_storage_length)==-1)
		{
		  printf("KMS unreachable or Authentication failure.\n");
		  exit(1);
		}
	      memset((void*)iv_aes, '\0', 16);
	      unsigned char decrypted_all[80];
	      aes_128_decrypt_cbc(buf,(void *)clientsecret,(void *)iv_aes,80,(void *)decrypted_all);
	      expandkey(decrypted_all+40+1,(void*)session_key_expanded);
	      memcpy((void*)validity, decrypted_all+40+16+1,4);
	      unsigned char test_nonce[KEY_SIZE];
	      memcpy((void*)test_nonce, decrypted_all+40+20+1,16);
	      if(memcmp(test_nonce,nonce,KEY_SIZE)!=0)
		{
		  printf("Authentication failure.\n");
		  exit(1);
		}
	      char filenm[56];
	      sprintf(filenm,"session_key.out.%s",clientid);
	      FILE *fp_key=fopen(filenm,"w");
	      unsigned char session_key_enc[EXPANDED_KEY_SIZE];
	      unsigned char validity_enc[KEY_SIZE];
	      aes_128_encrypt_cbc(session_key_expanded,clientsecret,iv_aes,EXPANDED_KEY_SIZE,session_key_enc);
	      aes_128_encrypt_cbc(validity,clientsecret,iv_aes,4,validity_enc);
	      fwrite(validity_enc,1,KEY_SIZE,fp_key);
	      fwrite(session_key_enc,1,EXPANDED_KEY_SIZE,fp_key);
	      fclose(fp_key);
	    }
	  else
	    {
	      if(memcmp(decrypted_nonce,nonce,KEY_SIZE)!=0) 
		{
		  printf("Authentication failure.\n");
		  exit(1);
		}
	    }
	}
      else 
	{
	  memset((void*)iv_aes, '\0', 16);
	  unsigned char decrypted_all[80];
	  aes_128_decrypt_cbc(buf,(void *)clientsecret,(void *)iv_aes,80,(void *)decrypted_all);
	  expandkey(decrypted_all+40+1,(void*)session_key_expanded);
	  memcpy((void*)validity, decrypted_all+40+16+1,4);
	  unsigned char test_nonce[KEY_SIZE];
	  memcpy((void*)test_nonce, decrypted_all+40+20+1,16);
	  if(memcmp(test_nonce,nonce,KEY_SIZE)!=0)
	    {
	      printf("Authentication failure.\n");
	      exit(1);
	    }
	  char filenm[56];
	  sprintf(filenm,"session_key.out.%s",clientid);
	  FILE *fp_key=fopen(filenm,"w");
	  unsigned char session_key_enc[EXPANDED_KEY_SIZE];
	  unsigned char validity_enc[KEY_SIZE];
	  aes_128_encrypt_cbc(session_key_expanded,clientsecret,iv_aes,EXPANDED_KEY_SIZE,session_key_enc);
	  aes_128_encrypt_cbc(validity,clientsecret,iv_aes,4,validity_enc);
	  fwrite(validity_enc,1,KEY_SIZE,fp_key);
	  fwrite(session_key_enc,1,EXPANDED_KEY_SIZE,fp_key);
	  fclose(fp_key);
	}
      memset(buf,0,500);
      buf[0]='Y';
      aes_128_n_encrypt_cbc(clientid,(void *)session_key_expanded,(void *)iv_aes,40,(void *)(buf+1));
      message_type = 1;
      aes_128_n_encrypt_cbc(&message_type,(void *)session_key_expanded,(void *)iv_aes,1,(void *)(buf+49));
      unsigned char verify_nonce=rand()%256;
      aes_128_n_encrypt_cbc(&verify_nonce,(void *)session_key_expanded,(void *)iv_aes,1,(void *)(buf+65));
      unsigned char verify_nonce2=verify_nonce+1;
      if (sendto(sockfd, buf , 81, 0, (struct sockaddr*)&s_addr_storage, s_addr_storage_length)==-1)
	{
	  printf("%s\n",strerror(errno));
	  exit(1);
	}
      if (recvfrom(sockfd, buf , 80, 0, (struct sockaddr*)&s_addr_storage, &s_addr_storage_length)==-1)
	{
	  printf("Server busy.\n");
	  exit(1);
	}
      unsigned char serverid[40];
      aes_128_n_decrypt_cbc((void *)(buf),(void *)session_key_expanded,(void *)iv_aes,40,serverid);
      unsigned char response_type;
      aes_128_n_decrypt_cbc((void *)(buf+48),(void *)session_key_expanded,(void *)iv_aes,1,&response_type);
      if(response_type==1)
	{
	  aes_128_n_decrypt_cbc((void *)(buf+64),(void *)session_key_expanded,(void *)iv_aes,1,&verify_nonce);
	  if(verify_nonce==verify_nonce2)
	    {
	      //Authentication is complete at this stage.. Now we start a file transfer.. but can be anything else like coap request..
	      //http request ..
	      memset(buf,0,500);
	      buf[0]='Y';
	      aes_128_n_encrypt_cbc(clientid,(void *)session_key_expanded,(void *)iv_aes,40,(void *)(buf+1));
	      message_type = 2;
	      aes_128_n_encrypt_cbc(&message_type,(void *)session_key_expanded,(void *)iv_aes,1,(void *)(buf+49));
	      memset(filename,0,256);
	      strcat(filename,strcmp(argv[1],"-v")!=0?argv[6]:argv[7]);
	      aes_128_n_encrypt_cbc(filename,(void *)session_key_expanded,(void *)iv_aes,256,(void *)(buf+65));
	      struct timeval rcvwt2;
	      rcvwt2.tv_sec=60;rcvwt2.tv_usec=0;
	      setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(void *)&rcvwt2,sizeof(rcvwt2));
	      if (sendto(sockfd, buf , 321, 0, (struct sockaddr*)&s_addr_storage, s_addr_storage_length)==-1)
		{
		  printf("%s\n",strerror(errno));
		  exit(1);
		}
	      if (recvfrom(sockfd, buf , 96, 0, (struct sockaddr*)&s_addr_storage, &s_addr_storage_length)==-1)
		{
		  printf("Server unreachable.\n");
		  exit(1);
		}
	      unsigned char serverid[40];
	      aes_128_n_decrypt_cbc((void *)(buf),(void *)session_key_expanded,(void *)iv_aes,40,serverid);
	      unsigned char response_type;
	      aes_128_n_decrypt_cbc((void *)(buf+48),(void *)session_key_expanded,(void *)iv_aes,1,&response_type);
	      if(response_type==1)
		{
		  unsigned char filefound;
		  aes_128_n_decrypt_cbc((void *)(buf+48+KEY_SIZE),(void *)session_key_expanded,(void *)iv_aes,1,&filefound);
		  if(filefound =='N')
		    {
		      printf("File not found.\n");
		      exit(1);
		    }
		  else if (filefound=='Y')
		    {
		      fd=open64(strcmp(argv[1],"-v")!=0?argv[6]:argv[7],O_CREAT|O_RDWR,S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH);
		      if(fd==-1)
			{
			  printf("No write permission.\n");
			  exit(1);
			}
		      uint64_t filesize;
		      aes_128_n_decrypt_cbc((void *)(buf+48+KEY_SIZE+16),(void *)session_key_expanded,(void *)iv_aes,sizeof(uint64_t),(void*)&filesize);
		      memset(buf,0,500);
		      buf[0]='Y';
		      aes_128_n_encrypt_cbc(clientid,(void *)session_key_expanded,(void *)iv_aes,40,(void *)(buf+1));
		      message_type = 11;
		      aes_128_n_encrypt_cbc(&message_type,(void *)session_key_expanded,(void *)iv_aes,1,(void *)(buf+49));
		      if(sendto(sockfd, buf , 65, 0, (struct sockaddr*)&s_addr_storage, s_addr_storage_length)==-1)
			{
			  exit(1);
			}
		      int rem=filesize%MAXINOUTBUF;
		      int numblock = (filesize-rem)/MAXINOUTBUF;
		      int startprocess=0;
		      if(verbose)
		        start_display();	
		      intr_handler=signal(SIGINT,NULL);
		      term_handler=signal(SIGTERM,NULL);
		      signal(SIGINT,cleanup);
		      signal(SIGTERM,cleanup);	   
		      while (startprocess < numblock+1)
			{
			  if (startprocess<numblock)
			    {
			      memset(buf_serv,'\0',sizeof(buf_serv));
			      if(recvfrom(sockfd, buf_serv, MAXINOUTBUF , 0, (struct sockaddr*)&s_addr_storage, &s_addr_storage_length)!=MAXINOUTBUF) 
				{
				  printf("\nServer unreachable or File corrupt.");
				  cleanup(SIGINT);
				}
			      aes_128_n_decrypt_cbc((void *)(buf_serv),(void *)session_key_expanded,(void *)iv_aes,MAXINOUTBUF,buf2_serv);
			      if (write(fd,buf2_serv,MAXINOUTBUF)==-1)
				{
				  printf("\nWrite failed.");
				  cleanup (SIGINT);
				}
			      aes_128_n_encrypt_cbc((void *)(buf_serv),(void *)session_key_expanded,(void *)iv_aes,MAXINOUTBUF,buf2_serv);
			    }
			  else
			    {
			      memset(buf_serv,'\0',sizeof(buf_serv));
			      if(recvfrom(sockfd, buf_serv, rem+16-rem%16 , 0, (struct sockaddr*)&s_addr_storage, &s_addr_storage_length)!=rem+16-rem%16)
				{
				  printf("\nServer unreachable or File corrupt.");
				  cleanup (SIGINT);
				}
			      aes_128_n_decrypt_cbc((void *)(buf_serv),(void *)session_key_expanded,(void *)iv_aes,rem,buf2_serv);
			      if (write(fd,buf2_serv,rem)==-1)
				{
				  printf("\nWrite failed.");
				  cleanup (SIGINT);
				}
			      aes_128_n_encrypt_cbc((void *)(buf_serv),(void *)session_key_expanded,(void *)iv_aes,rem+16-rem%16,buf2_serv);
			    }
			  memset(buf,0,500);
			  buf[0]='Y';
			  aes_128_n_encrypt_cbc(clientid,(void *)session_key_expanded,(void *)iv_aes,40,(void *)(buf+1));
			  if (startprocess<numblock)
			    memcpy((void *)(buf+49),&buf2_serv[MAXINOUTBUF-KEY_SIZE],KEY_SIZE);
			  else
			    memcpy((void *)(buf+49),&buf2_serv[rem-rem%16],KEY_SIZE); 
			  if(sendto(sockfd, buf, 65, 0, (struct sockaddr*)&s_addr_storage, s_addr_storage_length)==-1)
			    {
			      printf("\n%s",strerror(errno));
			      cleanup(SIGINT);
			    }
			  if(verbose)
			    {
			      int percent;
			      if (numblock!=0)
				percent=(startprocess*100)/numblock;
			      else
				percent=100;
			      showprogress(percent);
			    }
			  startprocess++;
			}
		      if (recvfrom(sockfd, buf , KEY_SIZE, 0, (struct sockaddr*)&s_addr_storage, &s_addr_storage_length)==-1)
			{
			  printf("\nServer unreachable or File corrupt.");
			  cleanup(SIGINT);
			}
		      char ok[3];
		      const char x[3]={'o','k','\0'};
		      aes_128_n_decrypt_cbc((void *)(buf),(void *)session_key_expanded,(void *)iv_aes,3,(void *)ok);
		      if (strcmp(ok,x)!=0){
			printf("\nFile corrupted.");
			cleanup(SIGINT);
		      }
		      close(fd);
		      restore_handlers();
		      if(verbose) {
			printf("\n");
			printf("Download Complete: %1$s\n",filename);
		      }
		    }//file found
		}//response 1
	    }//post authentication verification
	}//again response 1
    }//if serv gives Y in first response
  freeaddrinfo(servinfo);
  close(sockfd);
  return 0;
}
