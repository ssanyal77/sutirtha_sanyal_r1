#include <stdio.h>
#include <stdlib.h>
#include <string.h>
extern unsigned char F_S [256];
extern int num_round;
unsigned char xtimes(unsigned char* byte);
void block_xor(unsigned char* x, unsigned char * y,unsigned char word);
void expandkey(unsigned char* key, unsigned char* expanded_key);
void subbyte(unsigned char * state, unsigned char word)
{
  int i=0;
  if(word==0x00)
    for (i=0;i<16;i++)
      *(state+i)= F_S[((*(state+i))&0xf0)+((*(state+i))&0x0f)];
  else
    for (i=0;i<4;i++)
      *(state+i)= F_S[((*(state+i))&0xf0)+((*(state+i))&0x0f)];
}
void shift (unsigned char* ch1,unsigned char* ch2,unsigned char* ch3,unsigned char* ch4)
{
  unsigned char temp;
  temp = *ch1;
  *ch1 = *ch2;
  *ch2 = *ch3;
  *ch3 = *ch4;
  *ch4 = temp;
} 
void shiftrow(unsigned char* state)
{
  shift(state+1,state+5,state+9,state+13);
  shift(state+2,state+6,state+10,state+14);
  shift(state+2,state+6,state+10,state+14);
  shift(state+3,state+7,state+11,state+15);
  shift(state+3,state+7,state+11,state+15);
  shift(state+3,state+7,state+11,state+15);
}
void trans_one_col(unsigned char* state)
{
  unsigned char temp1, temp2, temp3, temp4;
  temp1 = xtimes(state)^(xtimes(state+1)^(*(state+1)))^(*(state+2))^(*(state+3));
  temp2 = (*(state))^xtimes(state+1)^((*(state+2))^(xtimes(state+2)))^(*(state+3));
  temp3 = (*(state))^(*(state+1))^(xtimes(state+2))^((xtimes(state+3))^(*(state+3)));
  temp4 = (xtimes(state)^(*(state)))^(*(state+1))^(*(state+2))^(xtimes(state+3));
  *state = temp1;
  *(state+1) = temp2;
  *(state+2) = temp3;
  *(state+3) = temp4;
}
void mixcolumns(unsigned char* state)
{
  int i;
  for (i=0;i<16;i=i+4)
    trans_one_col(state+i);
}
void encrypt(unsigned char * state, unsigned char* key, char expand)
{
  unsigned char* expanded_key;
  if(expand)
    {
      expanded_key = malloc(sizeof(unsigned char)*16*(num_round+1));
      expandkey(key,expanded_key);
    }
  else
    expanded_key=key;
  int round = 1;
  block_xor(state,expanded_key,0x00);
  while (round < num_round)
    {
      subbyte(state,0x00);
      shiftrow(state);
      mixcolumns(state);
      block_xor(state,expanded_key+16*round,0x00);
      round++;
    }
  subbyte(state,0x00);
  shiftrow(state);
  block_xor(state,expanded_key+16*round,0x00);
  if(expand)
    free(expanded_key);
}
void  aes_128_encrypt_cbc(void * input, void * key, void * iv, size_t datasize,void * output)
{
  int numblock;
  int i;
  int j = (datasize%16==0)?((datasize!=0)?datasize:16):datasize+16-datasize%16;
  numblock=j/16;
  unsigned char  *input_state=(unsigned char *)malloc(j);
  for (i=0;i<datasize;i++)
    *(input_state+i)=*((unsigned char*)(input+i));
  for (i=datasize;i<j;i++)
    *(input_state+i)='0';
  block_xor(input_state,(unsigned char*)iv,0x00);
  for (i=0;i<numblock;i++) {
    encrypt(input_state+i*16,key,1);
    if(i!=numblock-1)
      block_xor((input_state+16*(i+1)),(input_state+i*16),0x00);
  }
  for (i=0;i<j;i++)
    *((unsigned char*)(output+i))=*(input_state+i);
  free(input_state);
}
void  aes_128_n_encrypt_cbc(void * input, void * key, void * iv, size_t datasize,void * output)
{
  int numblock;
  int i;
  int j = (datasize%16==0)?((datasize!=0)?datasize:16):datasize+16-datasize%16;
  numblock=j/16;
  unsigned char  *input_state=(unsigned char *)malloc(j);
  for (i=0;i<datasize;i++)
    *(input_state+i)=*((unsigned char*)(input+i));
  for (i=datasize;i<j;i++)
    *(input_state+i)='0';
  block_xor(input_state,(unsigned char*)iv,0x00);
  for (i=0;i<numblock;i++) {
    encrypt(input_state+i*16,key,0);
    if(i!=numblock-1)
      block_xor((input_state+16*(i+1)),(input_state+i*16),0x00);
  }
  for (i=0;i<j;i++)
    *((unsigned char*)(output+i))=*(input_state+i);
  free(input_state);
}
