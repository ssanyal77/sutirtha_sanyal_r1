#include <stdio.h>
#include <stdlib.h>
#include <string.h>
extern unsigned char I_F_S[256];
extern int num_round;
unsigned char nxtimes(unsigned char* state, int times);
void block_xor(unsigned char* x, unsigned char * y,unsigned char word);
void expandkey(unsigned char* key, unsigned char* expanded_key);
void invsubbyte(unsigned char * state, unsigned char word)
{
  int i=0;
  if(word==0x00)
    for (i=0;i<16;i++)
      *(state+i)= I_F_S[((*(state+i))&0xf0)+((*(state+i))&0x0f)];
  else
    for (i=0;i<4;i++)
      *(state+i)= I_F_S[((*(state+i))&0xf0)+((*(state+i))&0x0f)];
}
void invshift (unsigned char* ch1,unsigned char* ch2,unsigned char* ch3,unsigned char* ch4)
{
  unsigned char temp;
  temp = *ch4;
  *ch4 = *ch3;
  *ch3 = *ch2;
  *ch2 = *ch1;
  *ch1 = temp;
} 
void invshiftrow(unsigned char* state)
{
  invshift(state+1,state+5,state+9,state+13);
  invshift(state+2,state+6,state+10,state+14);
  invshift(state+2,state+6,state+10,state+14);
  invshift(state+3,state+7,state+11,state+15);
  invshift(state+3,state+7,state+11,state+15);
  invshift(state+3,state+7,state+11,state+15);
}
void inv_trans_one_col(unsigned char* state)
{
  unsigned char temp1, temp2, temp3, temp4;
  temp1 = (nxtimes(state,3)^nxtimes(state,2)^nxtimes(state,1))^(nxtimes(state+1,3)^nxtimes(state+1,1)^nxtimes(state+1,0))^(nxtimes(state+2,3)^nxtimes(state+2,2)^nxtimes(state+2,0))^(nxtimes(state+3,3)^nxtimes(state+3,0));
  temp2 = (nxtimes(state,3)^nxtimes(state,0))^(nxtimes(state+1,3)^nxtimes(state+1,2)^nxtimes(state+1,1))^(nxtimes(state+2,3)^nxtimes(state+2,1)^nxtimes(state+2,0))^(nxtimes(state+3,3)^nxtimes(state+3,2)^nxtimes(state+3,0));
  temp3 = (nxtimes(state,3)^nxtimes(state,2)^nxtimes(state,0))^(nxtimes(state+1,3)^nxtimes(state+1,0))^(nxtimes(state+2,3)^nxtimes(state+2,2)^nxtimes(state+2,1))^(nxtimes(state+3,3)^nxtimes(state+3,1)^nxtimes(state+3,0));
  temp4 = (nxtimes(state,3)^nxtimes(state,1)^nxtimes(state,0))^(nxtimes(state+1,3)^nxtimes(state+1,2)^nxtimes(state+1,0))^(nxtimes(state+2,3)^nxtimes(state+2,0))^(nxtimes(state+3,3)^nxtimes(state+3,2)^nxtimes(state+3,1));
  *state = temp1;
  *(state+1) = temp2;
  *(state+2) = temp3;
  *(state+3) = temp4;
}
void invmixcolumns(unsigned char* state)
{
  int i;
  for (i=0;i<16;i=i+4)
    inv_trans_one_col(state+i);
}
void decrypt(unsigned char * state, unsigned char* key, char expand)
{
  unsigned char* expanded_key;
  if (expand)
    {
      expanded_key = malloc(sizeof(unsigned char)*16*(num_round+1));
      expandkey(key,expanded_key);
    }
  else
    expanded_key=key;
  int round = 10;
  block_xor(state,expanded_key+16*round,0x00);
  while (round > 0)
    {
      invshiftrow(state);
      invsubbyte(state,0x00);
      round--;
      block_xor(state,expanded_key+16*round,0x00);
      if(round>0)
	invmixcolumns(state);
    }
  if(expand)
    free(expanded_key);
}
void  aes_128_decrypt_cbc(void * input, void * key, void * iv, size_t datasize,void * output)
{
  int numblock;
  int i;
  int j = (datasize%16==0)?((datasize!=0)?datasize:16):datasize+16-datasize%16;
  numblock=j/16;
  void * input_state=(void*)malloc(j);
  for (i=0;i<j;i++)
    *((unsigned char*)(input_state+i))=*((unsigned char*)(input+i));
  decrypt(input_state,key,1);
  block_xor((unsigned char*)input_state,(unsigned char*)iv,0x00);
  for (i=1;i<numblock;i++) {
    decrypt(input_state+16*i,key,1);
    block_xor((unsigned char*)(input_state+16*i),(unsigned char*)(input+16*(i-1)),0x00);
  }
  for (i=0;i<datasize;i++)
    *((unsigned char*)(output+i))=*((unsigned char*)(input_state+i));
  free(input_state);
}
void  aes_128_n_decrypt_cbc(void * input, void * key, void * iv, size_t datasize,void * output)
{
  int numblock;
  int i;
  int j = (datasize%16==0)?((datasize!=0)?datasize:16):datasize+16-datasize%16;
  numblock=j/16;
  void * input_state=(void*)malloc(j);
  for (i=0;i<j;i++)
    *((unsigned char*)(input_state+i))=*((unsigned char*)(input+i));
  decrypt(input_state,key,0);
  block_xor((unsigned char*)input_state,(unsigned char*)iv,0x00);
  for (i=1;i<numblock;i++) {
    decrypt(input_state+16*i,key,0);
    block_xor((unsigned char*)(input_state+16*i),(unsigned char*)(input+16*(i-1)),0x00);
  }
  for (i=0;i<datasize;i++)
    *((unsigned char*)(output+i))=*((unsigned char*)(input_state+i));
  free(input_state);
}
