This creates a static library (libaes.a) of 128-bit Advanced Encryption Standard (AES) functions. 
The implementation follows the algorithm described in http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf .
128 bits key schedule generation, encryption and decryption (in CBC mode) routines are implemented.
