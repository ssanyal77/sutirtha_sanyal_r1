This is an implementation of a secure file server. 
It carries out the authentication phase according to the protocol SPIKE 
(http://ieeexplore.ieee.org/xpl/login.jsp?tp=&arnumber=6596049).
The salient features of the protocol are implemented in this version. 
 
The program consists of a client (client.c), a server (server.c) and the Key Management Server (KMS) (kms.c).

The encryption method used is AES in CBC mode with 128 bits key.

Both the KMS and the server are multi-threaded. KMS can simultaneously handle authentication requests from
several pairs of nodes. 
The server can serve several clients or a client can issue several requests to the same or different servers, 
in parallel. 


Compiling and Execution
************************

Ideally KMS and client-server pair for an user should be run in two different machines. 
KMS and server must run in separate machines. 

KMS requires a master record file which stores ids (can be 39 characters long) and passwords 
(can be 16 characters long) of all the clients and servers in the network (master.dat). 
Server and client need to provide the password at startup.

For generating fast binaries,

make 

For generating size optimized binaries,

make small 

For execution,

i) For kms,
./kms <kms ip> <kms port> <master filename>

One example command line:
./kms 181.0.0.3 4344 master.dat

ii) For  server,
./server <server ip> <server port> <kms ip> <kms port> <server id> 

Example command lines:

./server 181.0.0.22 3425 181.0.0.3 4344 alice 
./server 181.0.0.23 3424 181.0.0.3 4344 bob 
 
IV used in the CBC is set to 16 byte long string of nulls.
Ports 8000 and above are used internally by the KMS and servers and hence should not be used by the user.

iii) For client,
./client [-v] <client ip>  <kms ip> <kms_port> <server ip> <server port> <file name> <client id> [password] 

Example command lines:

./client 181.0.0.22 181.0.0.3 4344 181.0.0.23 3424 A.txt alice [password]
./client -v 181.0.0.23 181.0.0.3 4344 181.0.0.22 3425 B.txt bob [password]

Client binds to an available port. Password optionally can be put as last argument for batch processing. 
If verbose option (-v) is given, it displays the current download completion status.

Here filename is the name of the file in server which client wishes to download, securely. 
If authentication is successful and file is found, server sends the file encrypted with the session key obtained from the KMS.
Client decrypts it using the same session key and stores the file in the current location.
