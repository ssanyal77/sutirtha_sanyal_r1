//Author - Sutirtha Sanyal
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <time.h>
#define KEY_SIZE 16
typedef struct tag
{
  unsigned char name[40];
  int id;
  unsigned char passplain[KEY_SIZE+1];
  struct tag* next;
}namepass;
int numconnections=0;
pthread_mutex_t numconnectlock;
pthread_mutex_t master_table_op_lock;
namepass *namepasslist=NULL;
typedef struct tag4{
  pthread_t th;
  int  tid;
  unsigned char clientid[40];
  unsigned char serverid[40];
  int main_socket;
  int thread_socket;
  struct sockaddr_storage st2;
  char alive;
  struct tag4 * next;
}threadinfo;
threadinfo * global_thread_list=NULL;
typedef struct key_struct{
  unsigned char session_key[KEY_SIZE];
  unsigned char *clientidlist;
  int lifetime;
  struct key_struct * next;
  struct key_struct * prev;
}key_table;
key_table *master_key_table=NULL;
int numnodes=0;
void  aes_128_encrypt_cbc(void * input, void * key, void * iv, size_t datasize,void * output);
void  aes_128_decrypt_cbc(void * input, void * key, void * iv, size_t datasize,void * output);
void update_into_key_table(int client1,int client2,int lifetime,unsigned char session_key[])
{
  char updated=0;
  key_table * start = master_key_table;
  while(start != NULL)
    {
      if(client1!=-1)
	{
	  start->clientidlist[client1]=0;
	  if(memcmp(start->session_key,session_key,KEY_SIZE)==0)
	    {
	      start->clientidlist[client1]=1;
	      updated=1;
	    }
	}
      if(client2!=-1)
	{
	  start->clientidlist[client2]=0;
	  if(memcmp(start->session_key,session_key,KEY_SIZE)==0)
	    {
	      start->clientidlist[client2]=1;
	      updated=1;
	    }
	}
      start=start->next;
    }
  if(updated)
    return;
  start=master_key_table;
  if (start == NULL) {
    master_key_table = (key_table*) malloc(sizeof(key_table));
    master_key_table->next=master_key_table->prev=NULL;
    memcpy(master_key_table->session_key,session_key,KEY_SIZE);
    master_key_table->lifetime=lifetime;
    master_key_table->clientidlist=malloc(numnodes);
    memset(master_key_table->clientidlist,0,numnodes);
    if(client1!=-1) {
      master_key_table->clientidlist[client1]=1;
    }
    if(client2!=-1) {
      master_key_table->clientidlist[client2]=1;
    }
  }
  else {
    while (start->next !=NULL)
      start=start->next;
    start->next=(key_table*) malloc(sizeof(key_table));
    start->next->next=NULL;
    start->next->prev=start;
    memcpy(start->next->session_key,session_key,KEY_SIZE);
    start->next->lifetime=lifetime;
    start->next->clientidlist=malloc(numnodes);
    memset(start->next->clientidlist,0,numnodes);
    if(client1!=-1) {
      start->next->clientidlist[client1]=1;
    }
    if(client2!=-1) {
      start->next->clientidlist[client2]=1;
    }  
  }
}
int search_in_key_table(unsigned char clientid[], unsigned char session_key[],int* validity)
{
  int client1=-1; key_table * start;
  namepass * namepasslistiter=namepasslist;
  while (namepasslistiter!=NULL)
    {
      if(memcmp(clientid,namepasslistiter->name,40)==0)
	{
	  client1=namepasslistiter->id;
	  break;
	}
      namepasslistiter=namepasslistiter->next;
    }
  start=master_key_table;
  while(start!=NULL)
    {
      if(start->clientidlist[client1]==1)
	{
	  memcpy(session_key,start->session_key,KEY_SIZE);
	  *validity=start->lifetime;
	  return 1;
	}
      start=start->next;
    }
  return 0;
}
void* reduce_lifetime(void *arg)
{
  key_table * start, * temp;
  unsigned char *allzero=malloc(numnodes);
  memset(allzero,0,numnodes);
  while(1)
    {
      sleep(1);
      pthread_mutex_lock(&master_table_op_lock);
      start=master_key_table;
      while(start!=NULL)
	{
	  while(1)
	    {
	      if(start==NULL)
		break;
       	      start->lifetime--;
	      if(start->lifetime==0||memcmp(start->clientidlist,allzero,numnodes)==0)
		{
		  if(start->prev!=NULL)
		    start->prev->next=start->next;
		  if(start->next!=NULL)
		    start->next->prev=start->prev;
		  temp = start;
		  if(start==master_key_table) {
		    start=start->next;
		    master_key_table=start;
		  }
		  else
		    start=start->next;
		  free(temp->clientidlist);
		  free(temp);
		}
	      else
		break;
	    }
	  if(start!=NULL)
	    start=start->next;
	}
      pthread_mutex_unlock(&master_table_op_lock);
    }
}
void store_session_key(unsigned char myid[],unsigned char peerid[],unsigned char session_key[],int now)
{
  int client1=-1,client2=-1;
  namepass * namepasslistiter=namepasslist;
  while (namepasslistiter!=NULL)
    {
      if(myid!=0&&memcmp(myid,namepasslistiter->name,40)==0)
	{
	  client1=namepasslistiter->id;
	}
      if(peerid!=0&&memcmp(peerid,namepasslistiter->name,40)==0)
	{
	  client2=namepasslistiter->id;
	}
      namepasslistiter=namepasslistiter->next;
    }
  update_into_key_table(client1,client2,now,session_key);
}
void generate_session_key(unsigned char nonce[KEY_SIZE])
{
  int i;
  for (i=0;i<KEY_SIZE;i++)
    nonce[i]=rand()%256;
}
void generate_one_nonce(unsigned char nonce[KEY_SIZE])
{
  int i;
  for (i=0;i<KEY_SIZE;i++)
    nonce[i]=rand()%256;
}
void construct_addr(char * name, char * portno,struct addrinfo * addr)
{
  struct addrinfo hints, *servinfo=NULL;
  memset((void*)&hints, 0, sizeof (hints));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_DGRAM;
  getaddrinfo(name, portno, &hints, &servinfo);
  *addr=*servinfo;
}
void loadlist(namepass ** namepasslist, char * filename)
{
  FILE* fp2 = fopen(filename,"r");
  namepass * namepasslist2=NULL;
  if (fp2==NULL) {printf("Master file not found or no read permission\n");exit(1);}
  *namepasslist=(namepass *)malloc(sizeof(namepass));
  while(!feof(fp2))
    {
      if(namepasslist2==NULL) namepasslist2=*namepasslist;
      memset((*namepasslist)->passplain,'\0',KEY_SIZE+1);
      if (fscanf(fp2,"%s %s",(*namepasslist)->name,(*namepasslist)->passplain) == 2)
	{
	  (*namepasslist)->id=numnodes;
	  (*namepasslist)->next=(namepass *)malloc(sizeof(namepass));
	  (*namepasslist)=(*namepasslist)->next;
	  numnodes++;
	}
    }
  (*namepasslist)->next=NULL;
  *namepasslist=namepasslist2;
  fclose(fp2);
}
int check_and_load_secrets(namepass *namepasslist,unsigned char clientid[],unsigned char      
			   serverid[],unsigned char clientsecret[],unsigned char serversecret[])
{
  short clientfound=0,serverfound=0;
  while (namepasslist!=NULL)
    {
      if(memcmp(clientid,namepasslist->name,40)==0)
	{
	  clientfound=1;
	  memcpy((void*)clientsecret, namepasslist->passplain,KEY_SIZE); 
	}
      if(memcmp(serverid,namepasslist->name,40)==0)
	{
	  serverfound=1;
	  memcpy((void*)serversecret, namepasslist->passplain,KEY_SIZE); 
	}
      namepasslist=namepasslist->next;
    }
  if (clientfound*serverfound==0)
    return 0;
  return 1;
}
typedef struct tag3
{
  int client_int_socket;
  struct sockaddr_storage my_storage;
  struct sockaddr_storage peer_storage;
  unsigned char myid[40];
  unsigned char peerid[40];
  unsigned char have_key;
  unsigned char clientsecret[KEY_SIZE];
  unsigned char encrypted_nonce[KEY_SIZE];
  unsigned char mac[KEY_SIZE];
}client_arg;
client_arg arg;
void prepare_arg(int indicator,unsigned char clientsecret[KEY_SIZE], unsigned char * buf, unsigned char clientid[40],unsigned char serverid[40],unsigned char have_key, unsigned char encrypted_nonce[KEY_SIZE], unsigned char mac[KEY_SIZE], struct sockaddr_storage client_addr,int client_int_socket)
{
  if(indicator==1)
    {
      memcpy((void*)buf,(void*)clientid, 40);
      memcpy((void*)(buf+40),(void*)serverid, 40);
      memcpy((void*)(buf+80),(void*)&client_int_socket, 4);
      memcpy((void*)(buf+84),(void*)&have_key, 1);
      memcpy((void*)(buf+85),(void*)encrypted_nonce, 16);
      memcpy((void*)(buf+101),(void*)clientsecret, 16);
      memcpy((void*)(buf+117),(void*)mac, 16);
      memcpy((void*)(buf+133),(void*)&client_addr, sizeof(struct sockaddr_storage));
    }
  else
    {
      arg.client_int_socket=client_int_socket;
      memcpy((void*)(arg.myid),(void*)clientid,40);
      memcpy((void*)(arg.peerid),(void*)serverid,40);
      arg.my_storage=client_addr;
      arg.have_key = have_key;
      memcpy(arg.clientsecret,(void*)clientsecret,KEY_SIZE);
      memcpy(arg.mac,(void*)mac,KEY_SIZE);
      memcpy((void*)(arg.encrypted_nonce),(void*)encrypted_nonce,16);
    }
}
int unique_client_server(unsigned char clientid[40],unsigned char serverid[40],int * client_int_socket,struct sockaddr_storage * client_int_addr_storage)
{
  pthread_mutex_lock(&numconnectlock);
  threadinfo *st=global_thread_list;
  while(st!=NULL)
    {
      unsigned char id1[40];
      unsigned char id2[40];
      memcpy((void*)id1,(void*)st->clientid,40);
      memcpy((void*)id2,(void*)st->serverid,40);
      if ((memcmp(id2,clientid,40)==0 && memcmp(id1,serverid,40)==0) || (memcmp(id1,clientid,40)==0 && memcmp(id2,serverid,40)==0))
	{
	  *client_int_socket=st->main_socket;
	  *client_int_addr_storage=st->st2;
	  pthread_mutex_unlock(&numconnectlock);
	  return 0;
	}
      st=st->next;
    }
  pthread_mutex_unlock(&numconnectlock);
  return 1;
}
void cleanup(char ind)
{
  threadinfo * th_start1=global_thread_list;
  if (th_start1==NULL) return;
  threadinfo * th_start2=th_start1->next;
  int tid=pthread_self();
  while(th_start1!=NULL)
    {
      if (th_start2!=NULL)
	{
	  if (th_start1->tid==tid && ind==0)
	    {
	      th_start1->alive=0;
	      return;
	    }
	  if (th_start1->alive==0 && ind==1)
	    {
	      global_thread_list=th_start1->next;
	      close(th_start1->main_socket);
	      close(th_start1->thread_socket);
	      numconnections--;
       	      free(th_start1);
	      return;
	    }
	  if (th_start2->tid==tid && ind==0)
	    {
	      th_start2->alive=0;
	      return;
	    }
	  if(th_start2->alive==0 && ind==1)
	    {
	      th_start1->next=th_start2->next;
	      close(th_start2->main_socket);
	      close(th_start2->thread_socket);
	      numconnections--;
       	      free(th_start2);
	      return;
	    }
	}
      else
	{
	  if (th_start1->tid==tid && ind==0)
	    {
	      th_start1->alive=0;
	      return;
	    }
	  if(th_start1->alive==0 && ind==1)
	    {
	      global_thread_list=NULL;
	      close(th_start1->main_socket);
	      close(th_start1->thread_socket);
	      numconnections--;
       	      free(th_start1);
	      return;
	    }
	}
      th_start1=th_start1->next;
      if(th_start1!=NULL)
	th_start2=th_start1->next;
    }
  return;
}
void * clientstart(void* argptr)
{
  unsigned char myid[40];
  unsigned char i_have_key;
  unsigned char peer_have_key;
  unsigned char session_key [KEY_SIZE];
  int now;  
  unsigned char my_encrypted_nonce[KEY_SIZE];
  unsigned char peer_encrypted_nonce[KEY_SIZE];
  unsigned char my_nonce[KEY_SIZE];
  unsigned char peer_nonce[KEY_SIZE];
  unsigned char more_message;
  unsigned char mypass[KEY_SIZE];
  unsigned char peerpass[KEY_SIZE];
  unsigned char my_mac[KEY_SIZE];
  unsigned char peer_mac[KEY_SIZE];
  unsigned char iv_aes[KEY_SIZE];
  memset((void*)iv_aes,0,KEY_SIZE);
  memcpy(myid,(* ((client_arg*)argptr) ).myid,40);
  unsigned char buf_this_con[500];
  unsigned char peerid[40];
  memcpy(peerid,(*((client_arg*)argptr)).peerid,40);
  unsigned char nonce_list [2][72];
  i_have_key=(* ((client_arg*)argptr) ).have_key;
  memcpy((void*)my_encrypted_nonce, (void*)((*((client_arg*)argptr)).encrypted_nonce),KEY_SIZE);
  int this_connection_int_socket;
  this_connection_int_socket=(*((client_arg*)argptr)).client_int_socket;
  struct sockaddr_storage my_storage = (*((client_arg*)argptr)).my_storage;
  struct sockaddr_storage my_incoming_addr;
  size_t my_incoming_addr_length=sizeof(struct sockaddr_storage);
  memcpy((void*)mypass,(*((client_arg*)argptr)).clientsecret,KEY_SIZE);
  memcpy((void*)my_mac,(*((client_arg*)argptr)).mac,KEY_SIZE);
  aes_128_encrypt_cbc((void*)my_encrypted_nonce,(void*)mypass,(void*)iv_aes,KEY_SIZE,(void*)my_nonce);
  if(memcmp(my_mac,my_nonce,KEY_SIZE)!=0)
    {
      pthread_mutex_lock(&numconnectlock);
      cleanup(0);
      pthread_mutex_unlock(&numconnectlock);
      pthread_exit(NULL);
    }
  aes_128_decrypt_cbc((void*)my_encrypted_nonce,(void*)mypass,(void*)iv_aes,KEY_SIZE,(void*)my_nonce);
  memcpy(nonce_list[0],myid,40);
  memcpy(nonce_list[0]+40,my_nonce,KEY_SIZE);
  generate_one_nonce(my_nonce);
  memcpy(nonce_list[0]+40+KEY_SIZE,my_nonce,KEY_SIZE);
  if(recvfrom(this_connection_int_socket, buf_this_con, 500, 0, (struct sockaddr*)&my_incoming_addr, &my_incoming_addr_length)==-1)
    {
      pthread_mutex_lock(&numconnectlock);
      cleanup(0);
      pthread_mutex_unlock(&numconnectlock);
      pthread_exit(NULL);
    }
  struct sockaddr_storage peer_storage;
  memcpy((void*)&peer_storage,buf_this_con+133,sizeof(struct sockaddr_storage));
  memcpy((void*)&peer_have_key,buf_this_con+84,1);
  memcpy((void*)&peer_encrypted_nonce,buf_this_con+85,16);
  memcpy((void*)&peerpass,buf_this_con+101,16);
  memcpy((void*)peer_mac,buf_this_con+117,KEY_SIZE);
  aes_128_encrypt_cbc((void*)peer_encrypted_nonce,(void*)peerpass,(void*)iv_aes,KEY_SIZE,(void*)peer_nonce);
  if(memcmp(peer_mac,peer_nonce,KEY_SIZE)!=0)
    {
      pthread_mutex_lock(&numconnectlock);
      cleanup(0);
      pthread_mutex_unlock(&numconnectlock);
      pthread_exit(NULL);
    }
  aes_128_decrypt_cbc((void*)peer_encrypted_nonce,(void*)peerpass,(void*)iv_aes,KEY_SIZE,(void*)peer_nonce);
  memcpy(nonce_list[1],peerid,40);
  memcpy(nonce_list[1]+40,peer_nonce,KEY_SIZE);
  generate_one_nonce(peer_nonce);
  memcpy(nonce_list[1]+40+KEY_SIZE,peer_nonce,KEY_SIZE);
  pthread_mutex_lock(&master_table_op_lock);
  if(i_have_key=='Y' && search_in_key_table(myid, session_key,&now)==0)
    i_have_key='N';
  if(peer_have_key=='Y' && search_in_key_table(peerid, session_key,&now)==0)
    peer_have_key='N';
  pthread_mutex_unlock(&master_table_op_lock);
  if(i_have_key=='N' && peer_have_key=='N')
    {
      memset((void*)buf_this_con,0,sizeof(buf_this_con));
      more_message='Y';
      memcpy((void*)buf_this_con, (void*)&more_message,1);
      memcpy((void*)(buf_this_con+1),(void*)my_nonce, sizeof(my_nonce));
      unsigned char temp[5*KEY_SIZE];
      aes_128_encrypt_cbc((void*)buf_this_con,(void*)mypass,(void*)iv_aes,KEY_SIZE+1,(void*)temp);
      memcpy((void*)(buf_this_con),(void*)temp, 2*KEY_SIZE);
      memcpy((void*)(buf_this_con+2*KEY_SIZE),(void*)&my_storage, sizeof(my_storage));
      memcpy((void*)(buf_this_con+2*KEY_SIZE+sizeof(my_storage)), (void*)&more_message,1);
      memcpy((void*)(buf_this_con+2*KEY_SIZE+sizeof(my_storage)+1),(void*)peer_nonce, sizeof(peer_nonce));
      aes_128_encrypt_cbc((void*)(buf_this_con+2*KEY_SIZE+sizeof(my_storage)),(void*)peerpass,(void*)iv_aes,KEY_SIZE+1,(void*)temp);
      memcpy((void*)(buf_this_con+2*KEY_SIZE+sizeof(my_storage)),(void*)temp, 2*KEY_SIZE);
      memcpy((void*)(buf_this_con+4*KEY_SIZE+sizeof(my_storage)),(void*)&peer_storage, sizeof(peer_storage));
      unsigned char length=2*KEY_SIZE;
      unsigned char nummessage = 2;
      memcpy((void*)(buf_this_con+498),(void*)&length,1);
      memcpy((void*)(buf_this_con+497),(void*)&length,1);
      memcpy((void*)(buf_this_con+499),(void*)&nummessage,1);
      char i;
      for (i=0;i<KEY_SIZE;i++)
	{
	  nonce_list[0][40+KEY_SIZE+i]+=1;
	  nonce_list[1][40+KEY_SIZE+i]+=1;
	}
      sendto(this_connection_int_socket, buf_this_con, 500 , 0, (struct sockaddr*)&my_incoming_addr, my_incoming_addr_length);
      if(recvfrom(this_connection_int_socket, buf_this_con, 500, 0, (struct sockaddr*)&my_incoming_addr, &my_incoming_addr_length)==-1)
	{
	  pthread_mutex_lock(&numconnectlock);
	  cleanup(0);
	  pthread_mutex_unlock(&numconnectlock);
	  pthread_exit(NULL);
	}
      memcpy((void*)&peer_storage,buf_this_con+133,sizeof(struct sockaddr_storage));
      memcpy((void*)&peer_encrypted_nonce,buf_this_con+85,16);
      memcpy((void*)&peerpass,buf_this_con+101,16);
      memcpy((void*)peerid,buf_this_con,40);
      aes_128_decrypt_cbc((void*)peer_encrypted_nonce,(void*)peerpass,(void*)iv_aes,KEY_SIZE,(void*)peer_nonce);
      if(memcmp(peerid,nonce_list[0],40)==0)
	{
	  if( memcmp(peer_nonce,nonce_list[0]+40+KEY_SIZE,KEY_SIZE)!=0)
	    {
	      pthread_mutex_lock(&numconnectlock);
	      cleanup(0);
	      pthread_mutex_unlock(&numconnectlock);
	      pthread_exit(NULL);
	    }
	  else
	    memcpy(peer_nonce,nonce_list[0]+40,KEY_SIZE);
	}
      else 
	{
	  if( memcmp(peer_nonce,nonce_list[1]+40+KEY_SIZE,KEY_SIZE)!=0)
	    {
	      pthread_mutex_lock(&numconnectlock);
	      cleanup(0);
	      pthread_mutex_unlock(&numconnectlock);
	      pthread_exit(NULL);
	    }
	  else
	    memcpy(peer_nonce,nonce_list[1]+40,KEY_SIZE);
	}
      if(recvfrom(this_connection_int_socket, buf_this_con, 500, 0, (struct sockaddr*)&my_incoming_addr, &my_incoming_addr_length)==-1)
	{
	  pthread_mutex_lock(&numconnectlock);
	  cleanup(0);
	  pthread_mutex_unlock(&numconnectlock);
	  pthread_exit(NULL);
	}
      memcpy((void*)&my_storage,buf_this_con+133,sizeof(struct sockaddr_storage));
      memcpy((void*)&my_encrypted_nonce,buf_this_con+85,16);
      memcpy((void*)&mypass,buf_this_con+101,16);
      memcpy((void*)&myid,buf_this_con,40);
      aes_128_decrypt_cbc((void*)my_encrypted_nonce,(void*)mypass,(void*)iv_aes,KEY_SIZE,(void*)my_nonce);
      if(memcmp(myid,nonce_list[0],40)==0)
	{
	  if( memcmp(my_nonce,nonce_list[0]+40+KEY_SIZE,KEY_SIZE)!=0)
	    {
	      pthread_mutex_lock(&numconnectlock);
	      cleanup(0);
	      pthread_mutex_unlock(&numconnectlock);
	      pthread_exit(NULL);
	    }
	  else
	    memcpy(my_nonce,nonce_list[0]+40,KEY_SIZE);
	}
      else 
	{
	  if( memcmp(my_nonce,nonce_list[1]+40+KEY_SIZE,KEY_SIZE)!=0)
	    {
	      pthread_mutex_lock(&numconnectlock);
	      cleanup(0);
	      pthread_mutex_unlock(&numconnectlock);
	      pthread_exit(NULL);
	    }
	  else
	    memcpy(my_nonce,nonce_list[1]+40,KEY_SIZE);
	}
      generate_session_key(session_key);
      now = 3600;
      pthread_mutex_lock(&master_table_op_lock);
      store_session_key(myid,peerid,session_key,now);
      pthread_mutex_unlock(&master_table_op_lock);
      more_message='K';
      memset(buf_this_con,0,sizeof(buf_this_con));
      memcpy(buf_this_con,&more_message,1);
      memcpy(buf_this_con+1,myid,40);
      memcpy(buf_this_con+40+1,session_key,KEY_SIZE);
      memcpy(buf_this_con+40+KEY_SIZE+1,(void*)&now,sizeof(int));
      memcpy(buf_this_con+40+KEY_SIZE+4+1,(void*)peer_nonce,sizeof(peer_nonce));
      aes_128_encrypt_cbc((void*)buf_this_con,(void*)peerpass,(void*)iv_aes,2*KEY_SIZE+4+40+1,(void*)temp);
      memcpy(buf_this_con,temp,5*KEY_SIZE);
      memcpy(buf_this_con+5*KEY_SIZE,(void*)&peer_storage,sizeof(struct sockaddr_storage));
      memcpy(buf_this_con+5*KEY_SIZE+sizeof(peer_storage),&more_message,1);
      memcpy(buf_this_con+5*KEY_SIZE+sizeof(peer_storage)+1,peerid,40);
      memcpy(buf_this_con+5*KEY_SIZE+sizeof(peer_storage)+40+1,session_key,KEY_SIZE);
      memcpy(buf_this_con+6*KEY_SIZE+sizeof(peer_storage)+40+1,(void*)&now,sizeof(int));
      memcpy(buf_this_con+6*KEY_SIZE+sizeof(peer_storage)+4+40+1,(void*)my_nonce,sizeof(my_nonce));
      aes_128_encrypt_cbc((void*)(buf_this_con+5*KEY_SIZE+sizeof(peer_storage)),(void*)mypass,(void*)iv_aes,2*KEY_SIZE+4+40+1,(void*)temp);
      memcpy(buf_this_con+5*KEY_SIZE+sizeof(peer_storage),temp,5*KEY_SIZE);
      memcpy(buf_this_con+10*KEY_SIZE+sizeof(peer_storage),(void*)&my_storage,sizeof(struct sockaddr_storage));
      length=5*KEY_SIZE;
      memcpy((void*)(buf_this_con+498),(void*)&length,1);
      memcpy((void*)(buf_this_con+497),(void*)&length,1);
      memcpy((void*)(buf_this_con+499),(void*)&nummessage,1);
      sendto(this_connection_int_socket, buf_this_con, 500 , 0, (struct sockaddr*)&my_incoming_addr, my_incoming_addr_length);
    }
  else if((i_have_key=='Y' && peer_have_key=='N') || (i_have_key=='N' && peer_have_key=='Y') )
    {
      memset((void*)buf_this_con,0,sizeof(buf_this_con));
      if(i_have_key=='Y')
	{
	  more_message='N';
	  pthread_mutex_lock(&master_table_op_lock);
	  search_in_key_table(myid, session_key,&now);
	  pthread_mutex_unlock(&master_table_op_lock);
	  memcpy(my_nonce,nonce_list[0]+40,KEY_SIZE);
	}
      else more_message='Y';
      memcpy((void*)buf_this_con, (void*)&more_message,1);
      memcpy((void*)(buf_this_con+1),(void*)my_nonce, sizeof(my_nonce));
      unsigned char temp[5*KEY_SIZE];
      aes_128_encrypt_cbc((void*)buf_this_con,(void*)mypass,(void*)iv_aes,KEY_SIZE+1,(void*)temp);
      memcpy((void*)(buf_this_con),(void*)temp, 2*KEY_SIZE);
      memcpy((void*)(buf_this_con+2*KEY_SIZE),(void*)&my_storage, sizeof(my_storage));
      if(peer_have_key=='Y')
	{
	  more_message='N';
	  pthread_mutex_lock(&master_table_op_lock);
	  search_in_key_table(peerid, session_key,&now);
	  pthread_mutex_unlock(&master_table_op_lock);
	  memcpy(peer_nonce,nonce_list[1]+40,KEY_SIZE);
	}
      else more_message='Y';
      memcpy((void*)(buf_this_con+2*KEY_SIZE+sizeof(my_storage)), (void*)&more_message,1);
      memcpy((void*)(buf_this_con+2*KEY_SIZE+sizeof(my_storage)+1),(void*)peer_nonce, sizeof(peer_nonce));
      aes_128_encrypt_cbc((void*)(buf_this_con+2*KEY_SIZE+sizeof(my_storage)),(void*)peerpass,(void*)iv_aes,KEY_SIZE+1,(void*)temp);
      memcpy((void*)(buf_this_con+2*KEY_SIZE+sizeof(my_storage)),(void*)temp, 2*KEY_SIZE);
      memcpy((void*)(buf_this_con+4*KEY_SIZE+sizeof(my_storage)),(void*)&peer_storage, sizeof(peer_storage));
      char i;
      for (i=0;i<KEY_SIZE;i++)
	if (i_have_key=='N')
	  nonce_list[0][40+KEY_SIZE+i]+=1;
	else
	  nonce_list[1][40+KEY_SIZE+i]+=1; 
      unsigned char length=2*KEY_SIZE;
      unsigned char nummessage = 2;
      memcpy((void*)(buf_this_con+498),(void*)&length,1);
      memcpy((void*)(buf_this_con+497),(void*)&length,1);
      memcpy((void*)(buf_this_con+499),(void*)&nummessage,1);
      sendto(this_connection_int_socket, buf_this_con, 500 , 0, (struct sockaddr*)&my_incoming_addr, my_incoming_addr_length);
      if(recvfrom(this_connection_int_socket, buf_this_con, 500, 0, (struct sockaddr*)&my_incoming_addr, &my_incoming_addr_length)==-1)
	{
	  pthread_mutex_lock(&numconnectlock);
	  cleanup(0);
	  pthread_mutex_unlock(&numconnectlock);
	  pthread_exit(NULL);
	}
      memcpy((void*)&my_storage,buf_this_con+133,sizeof(struct sockaddr_storage));
      memcpy((void*)&my_encrypted_nonce,buf_this_con+85,16);
      memcpy((void*)&mypass,buf_this_con+101,16);
      memcpy((void*)&myid,buf_this_con,40);
      aes_128_decrypt_cbc((void*)my_encrypted_nonce,(void*)mypass,(void*)iv_aes,KEY_SIZE,(void*)my_nonce);
      if(memcmp(myid,nonce_list[0],40)==0)
	{
	  if( memcmp(my_nonce,nonce_list[0]+40+KEY_SIZE,KEY_SIZE)!=0)
	    {
	      pthread_mutex_lock(&numconnectlock);
	      cleanup(0);
	      pthread_mutex_unlock(&numconnectlock);
	      pthread_exit(NULL);
	    }
	  else
	    memcpy(my_nonce,nonce_list[0]+40,KEY_SIZE);
	}
      else 
	{
	  if( memcmp(my_nonce,nonce_list[1]+40+KEY_SIZE,KEY_SIZE)!=0)
	    {
	      pthread_mutex_lock(&numconnectlock);
	      cleanup(0);
	      pthread_mutex_unlock(&numconnectlock);
	      pthread_exit(NULL);
	    }
	  else
	    memcpy(my_nonce,nonce_list[1]+40,KEY_SIZE);
	}
      pthread_mutex_lock(&master_table_op_lock);
      store_session_key(myid,0,session_key,now);
      pthread_mutex_unlock(&master_table_op_lock);
      memcpy((void*)&myid,buf_this_con+40,40);
      memset(buf_this_con,0,sizeof(buf_this_con));
      more_message='K';
      memcpy(buf_this_con,&more_message,1);
      memcpy(buf_this_con+1,myid,40);
      memcpy(buf_this_con+40+1,session_key,KEY_SIZE);
      memcpy(buf_this_con+40+KEY_SIZE+1,(void*)&now,sizeof(int));
      memcpy(buf_this_con+40+KEY_SIZE+4+1,(void*)my_nonce,sizeof(my_nonce));
      aes_128_encrypt_cbc((void*)buf_this_con,(void*)mypass,(void*)iv_aes,2*KEY_SIZE+4+40+1,(void*)temp);
      memcpy(buf_this_con,temp,5*KEY_SIZE);
      memcpy(buf_this_con+5*KEY_SIZE,(void*)&my_storage,sizeof(struct sockaddr_storage));
      length=5*KEY_SIZE;
      nummessage=1;
      memcpy((void*)(buf_this_con+498),(void*)&length,1);
      memcpy((void*)(buf_this_con+499),(void*)&nummessage,1);
      sendto(this_connection_int_socket, buf_this_con, 500 , 0, (struct sockaddr*)&my_incoming_addr, my_incoming_addr_length);
    }
  else if(i_have_key=='Y' && peer_have_key=='Y')
    {
      unsigned char session_key1[KEY_SIZE],session_key2[KEY_SIZE];
      int now1,now2;
      memcpy(peer_nonce,nonce_list[1]+40,KEY_SIZE);
      memcpy(my_nonce,nonce_list[0]+40,KEY_SIZE);
      pthread_mutex_lock(&master_table_op_lock);
      search_in_key_table(myid, session_key1,&now1);
      search_in_key_table(peerid, session_key2,&now2);
      pthread_mutex_unlock(&master_table_op_lock);
      if (memcmp(session_key1,session_key2,KEY_SIZE)==0)
	{
	  memset((void*)buf_this_con,0,sizeof(buf_this_con));
	  more_message='N';
	  memcpy((void*)buf_this_con, (void*)&more_message,1);
	  memcpy((void*)(buf_this_con+1),(void*)my_nonce, sizeof(my_nonce));
	  unsigned char temp[2*KEY_SIZE];
	  aes_128_encrypt_cbc((void*)buf_this_con,(void*)mypass,(void*)iv_aes,KEY_SIZE+1,(void*)temp);
	  memcpy((void*)(buf_this_con),(void*)temp, 2*KEY_SIZE);
	  memcpy((void*)(buf_this_con+2*KEY_SIZE),(void*)&my_storage, sizeof(my_storage));
	  memcpy((void*)(buf_this_con+2*KEY_SIZE+sizeof(my_storage)), (void*)&more_message,1);
	  memcpy((void*)(buf_this_con+2*KEY_SIZE+sizeof(my_storage)+1),(void*)peer_nonce, sizeof(peer_nonce));
	  aes_128_encrypt_cbc((void*)(buf_this_con+2*KEY_SIZE+sizeof(my_storage)),(void*)peerpass,(void*)iv_aes,KEY_SIZE+1,(void*)temp);
	  memcpy((void*)(buf_this_con+2*KEY_SIZE+sizeof(my_storage)),(void*)temp, 2*KEY_SIZE);
	  memcpy((void*)(buf_this_con+4*KEY_SIZE+sizeof(my_storage)),(void*)&peer_storage, sizeof(peer_storage));
	  unsigned char length=2*KEY_SIZE;
	  unsigned char nummessage = 2;
	  memcpy((void*)(buf_this_con+498),(void*)&length,1);
	  memcpy((void*)(buf_this_con+497),(void*)&length,1);
	  memcpy((void*)(buf_this_con+499),(void*)&nummessage,1);
	  sendto(this_connection_int_socket, buf_this_con, 500 , 0, (struct sockaddr*)&my_incoming_addr, my_incoming_addr_length);
	}
      else {
	memset((void*)buf_this_con,0,sizeof(buf_this_con));
	if(now1>now2)
	  {
	    unsigned char length1,length2;
	    more_message='N';
	    memcpy((void*)buf_this_con, (void*)&more_message,1);
	    memcpy((void*)(buf_this_con+1),(void*)my_nonce, sizeof(my_nonce));
	    unsigned char temp[5*KEY_SIZE];
	    aes_128_encrypt_cbc((void*)buf_this_con,(void*)mypass,(void*)iv_aes,KEY_SIZE+1,(void*)temp);
	    memcpy((void*)(buf_this_con),(void*)temp, 2*KEY_SIZE);
	    memcpy((void*)(buf_this_con+2*KEY_SIZE),(void*)&my_storage, sizeof(my_storage));
	    more_message='K';
	    memcpy(buf_this_con+2*KEY_SIZE+sizeof(my_storage),&more_message,1);
	    memcpy(buf_this_con+2*KEY_SIZE+sizeof(my_storage)+1,myid,40);
	    memcpy(buf_this_con+2*KEY_SIZE+sizeof(my_storage)+40+1,session_key1,KEY_SIZE);
	    memcpy(buf_this_con+2*KEY_SIZE+sizeof(my_storage)+40+KEY_SIZE+1,(void*)&now1,sizeof(int));
	    memcpy(buf_this_con+2*KEY_SIZE+sizeof(my_storage)+40+KEY_SIZE+4+1,(void*)peer_nonce,sizeof(peer_nonce));
	    aes_128_encrypt_cbc((void*)buf_this_con+2*KEY_SIZE+sizeof(peer_storage),(void*)peerpass,(void*)iv_aes,2*KEY_SIZE+4+40+1,(void*)temp);
	    memcpy(buf_this_con+2*KEY_SIZE+sizeof(my_storage),temp,5*KEY_SIZE);
	    memcpy(buf_this_con+2*KEY_SIZE+sizeof(my_storage)+5*KEY_SIZE,(void*)&peer_storage,sizeof(struct sockaddr_storage));
	    length1=2*KEY_SIZE;
	    length2=5*KEY_SIZE;
	    unsigned char nummessage = 2;
	    memcpy((void*)(buf_this_con+497),(void*)&length1,1);
	    memcpy((void*)(buf_this_con+498),(void*)&length2,1);
	    memcpy((void*)(buf_this_con+499),(void*)&nummessage,1);
	    pthread_mutex_lock(&master_table_op_lock);
	    store_session_key(peerid,0,session_key1,now1);
	    pthread_mutex_unlock(&master_table_op_lock);
	    sendto(this_connection_int_socket, buf_this_con, 500 , 0, (struct sockaddr*)&my_incoming_addr, my_incoming_addr_length);
	  }
	else
	  {
	    unsigned char length1,length2;
	    more_message='N';
	    memcpy((void*)buf_this_con, (void*)&more_message,1);
	    memcpy((void*)(buf_this_con+1),(void*)peer_nonce, sizeof(my_nonce));
	    unsigned char temp[5*KEY_SIZE];
	    aes_128_encrypt_cbc((void*)buf_this_con,(void*)peerpass,(void*)iv_aes,KEY_SIZE+1,(void*)temp);
	    memcpy((void*)(buf_this_con),(void*)temp, 2*KEY_SIZE);
	    memcpy((void*)(buf_this_con+2*KEY_SIZE),(void*)&peer_storage, sizeof(my_storage));
	    more_message='K';
	    memcpy(buf_this_con+2*KEY_SIZE+sizeof(my_storage),&more_message,1);
	    memcpy(buf_this_con+2*KEY_SIZE+sizeof(my_storage)+1,peerid,40);
	    memcpy(buf_this_con+2*KEY_SIZE+sizeof(my_storage)+40+1,session_key2,KEY_SIZE);
	    memcpy(buf_this_con+2*KEY_SIZE+sizeof(my_storage)+40+KEY_SIZE+1,(void*)&now2,sizeof(int));
	    memcpy(buf_this_con+2*KEY_SIZE+sizeof(my_storage)+40+KEY_SIZE+4+1,(void*)my_nonce,sizeof(peer_nonce));
	    aes_128_encrypt_cbc((void*)buf_this_con+2*KEY_SIZE+sizeof(my_storage),(void*)mypass,(void*)iv_aes,2*KEY_SIZE+4+40+1,(void*)temp);
	    memcpy(buf_this_con+2*KEY_SIZE+sizeof(my_storage),temp,5*KEY_SIZE);
	    memcpy(buf_this_con+2*KEY_SIZE+sizeof(my_storage)+5*KEY_SIZE,(void*)&my_storage,sizeof(struct sockaddr_storage));
	    length1=2*KEY_SIZE;
	    length2=5*KEY_SIZE;
	    unsigned char nummessage = 2;
	    memcpy((void*)(buf_this_con+497),(void*)&length1,1);
	    memcpy((void*)(buf_this_con+498),(void*)&length2,1);
	    memcpy((void*)(buf_this_con+499),(void*)&nummessage,1);
	    pthread_mutex_lock(&master_table_op_lock);
	    store_session_key(myid,0,session_key2,now2);
	    pthread_mutex_unlock(&master_table_op_lock);
	    sendto(this_connection_int_socket, buf_this_con, 500 , 0, (struct sockaddr*)&my_incoming_addr, my_incoming_addr_length);
	  }
      }
    }
  pthread_mutex_lock(&numconnectlock);
  cleanup(0);
  pthread_mutex_unlock(&numconnectlock);
  pthread_exit(NULL);
}
void create_new_thread(void *(clientstart)(void * arg), void* arg, int main_sock, int th_sock, unsigned char clientid[],unsigned char serverid[], struct sockaddr_storage * st2)
{
  threadinfo * th_start=global_thread_list;
  if (th_start!=NULL) 
    while (th_start->next!=NULL)
      th_start = th_start->next;
  if(th_start!=NULL)
    {
      th_start->next=(threadinfo*)malloc(sizeof(threadinfo));
      th_start=th_start->next;
    }
  else
    {
      th_start=(threadinfo*)malloc(sizeof(threadinfo));
      global_thread_list=th_start;
    }
  memcpy(th_start->clientid,clientid,40);
  memcpy(th_start->serverid,serverid,40);
  th_start->main_socket=main_sock;
  th_start->thread_socket=th_sock;
  th_start->st2 = *st2;
  th_start->alive=1;
  th_start->next=NULL;
  pthread_create(&(th_start->th),NULL,clientstart,arg);
  th_start->tid=(int)th_start->th;
}
int main(int argc, char **argv)
{
  int sockfd;  
  pthread_t timer_thread;
  struct addrinfo hints, *servinfo, *p;
  int rv;
  unsigned char buf[500];
  struct addrinfo client_int_addr;
  size_t client_int_addr_storage_len = sizeof(struct sockaddr_storage);
  unsigned char clientsecret[KEY_SIZE];
  unsigned char serversecret[KEY_SIZE];
  unsigned char clientid[40];
  unsigned char serverid[40];
  unsigned char have_key='X'; 
  unsigned char encrypted_nonce[KEY_SIZE];
  unsigned char mac[KEY_SIZE];
  struct sockaddr_storage client_addr;
  size_t client_addr_len=sizeof(client_addr);
  struct timeval rcvwt;
  rcvwt.tv_sec=0;rcvwt.tv_usec=1;
  pthread_mutex_init(&numconnectlock,NULL);
  pthread_mutex_init(&master_table_op_lock,NULL);
  srand(time(NULL));
  if (argc != 4) 
    {
      fprintf(stderr,"usage: ./kms IP portno MasterRecordFileName\n");
      exit(1);
    }
  loadlist(&namepasslist,argv[3]); 
  memset(serversecret,'\0',sizeof(serversecret));
  memset(clientsecret,'\0',sizeof(clientsecret));  
  memset((void*)&client_int_addr,'\0',sizeof(client_int_addr));
  memset((void*)&hints, 0, sizeof (hints));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_DGRAM;
  if ((rv = getaddrinfo(argv[1], argv[2], &hints, &servinfo)) != 0) 
    {
      fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
      return 1;
    }
  for(p = servinfo; p != NULL; p = p->ai_next) 
    {
      if ((sockfd = socket(p->ai_family, p->ai_socktype,
			   p->ai_protocol)) == -1) 
	{
	  continue;
	}
      setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(void *)&rcvwt,sizeof(rcvwt));
      if (bind(sockfd,p->ai_addr,p->ai_addrlen) == -1) 
	{
	  close(sockfd);
	  continue;
	}
      break;
    }
  if (p == NULL) 
    {
      fprintf(stderr, "KMS failed to bind socket\n");
      exit(1);
    }
  char client_int_port[5]="8000";
  client_int_port[4]='\0';
  int client_int_socket;
  struct sockaddr_storage client_int_addr_store;
  pthread_create(&timer_thread,NULL,reduce_lifetime,NULL);
  int empty=0;
  while(1)
    {
      empty=0;
      memset(buf,'\0',sizeof(buf));
      if( recvfrom(sockfd, buf, sizeof(buf) , 0, (struct sockaddr*)&client_addr, &client_addr_len)==-1)
	{
	  empty=1;
	}
      if (!empty)
	{
	  unsigned char message_type;
	  memcpy((void*)&message_type,buf,1);
	  if(message_type==3)
	    {
	      memset(clientid,'\0',sizeof(clientid));
	      memcpy(clientid,buf+1,40);
	      memset(serverid,'\0',sizeof(serverid));
	      memcpy(serverid,buf+41,40);
	      memcpy((void*)&have_key,buf+81,1);
	      memcpy((void*)encrypted_nonce,buf+82,16);
	      memcpy((void*)mac,buf+98,16);
	    }
	  else if(message_type==7)
	    {
	      memset(clientid,'\0',sizeof(clientid));
	      memcpy(clientid,buf+1,40);
	      memset(serverid,'\0',sizeof(serverid));
	      memcpy(serverid,buf+41,40);
	      have_key='P';
	      memset((void*)mac,0,16);
	      memcpy((void*)encrypted_nonce,buf+81,16);
	    }
	  memset(buf,'\0',sizeof(buf));
	  if(check_and_load_secrets(namepasslist,clientid,serverid,clientsecret,serversecret)==0)
	    {
	      memcpy(buf,"NF",2);
	      if(sendto(sockfd, buf, 3, 0, (struct sockaddr*)&client_addr, client_addr_len)==-1)
		{
		  printf("%s\n",strerror(errno));
		  exit(1);
		};
	      continue;
	    }
	  if(unique_client_server(clientid,serverid,&client_int_socket,&client_int_addr_store)==1)
	    { 
	      int client_int_sockets,client_int_sockets2;
	      struct sockaddr_storage client_int_addr_storage2;
	      construct_addr(argv[1],client_int_port,&client_int_addr);
	      if ((client_int_sockets = socket(client_int_addr.ai_family, client_int_addr.ai_socktype,
					       client_int_addr.ai_protocol)) == -1) 
		{
		  continue;
		}
	      setsockopt(client_int_sockets,SOL_SOCKET,SO_RCVTIMEO,(void *)&rcvwt,sizeof(rcvwt));
	      if (bind(client_int_sockets,client_int_addr.ai_addr,client_int_addr.ai_addrlen) == -1) 
		{
		  continue;
		}
	      int x;
	      x=strtoll(client_int_port,NULL,10);
	      sprintf(client_int_port,"%d",++x);
	      construct_addr(argv[1],client_int_port,&client_int_addr);
	      client_int_addr_storage2=*((struct sockaddr_storage*)client_int_addr.ai_addr);
	      if ((client_int_sockets2 = socket(client_int_addr.ai_family, client_int_addr.ai_socktype,
						client_int_addr.ai_protocol)) == -1) 
		{
		  continue;
		}
	      struct timeval rcvwt2;
	      rcvwt2.tv_sec=1;rcvwt2.tv_usec=0;
	      setsockopt(client_int_sockets2,SOL_SOCKET,SO_RCVTIMEO,(void *)&rcvwt2,sizeof(rcvwt2));
	      if (bind(client_int_sockets2,client_int_addr.ai_addr,client_int_addr.ai_addrlen) == -1) 
		{
		  continue;
		}
	      x=strtoll(client_int_port,NULL,10);
	      sprintf(client_int_port,"%d",++x);
	      pthread_mutex_lock(&numconnectlock);
	      prepare_arg(0,clientsecret,buf,clientid,serverid,have_key,encrypted_nonce,mac,client_addr,client_int_sockets2);
	      create_new_thread(clientstart,(void*)&arg,client_int_sockets,client_int_sockets2,clientid,serverid,&client_int_addr_storage2);
	      numconnections++;
	      pthread_mutex_unlock(&numconnectlock);
	    }
	  else 
	    {
	      prepare_arg(1,clientsecret,buf,clientid,serverid,have_key,encrypted_nonce,mac,client_addr,client_int_socket);
	      sendto(client_int_socket, buf, 500, 0, (struct sockaddr*)&client_int_addr_store, client_int_addr_storage_len);
	    }
	}
      pthread_mutex_lock(&numconnectlock);
      if(numconnections==0)
	strcpy(client_int_port,"8000");
      threadinfo * start= global_thread_list;
      while (start!=NULL)
	{
	  memset(buf,0,sizeof(buf));
	  if(recvfrom(start->main_socket, buf, 500, 0, (struct sockaddr*)&client_int_addr_store, &client_int_addr_storage_len)!=-1)
	    {
	      unsigned char nummessage=buf[499];
	      if(nummessage==2) 
		{
		  unsigned char length1=buf[497];
		  unsigned char length2=buf[498];
		  unsigned char *buf1;
		  buf1=(unsigned char*)malloc(length1);
		  struct sockaddr_storage dest1;
		  unsigned char *buf2;
		  buf2=(unsigned char*)malloc(length2);
		  struct sockaddr_storage dest2;
		  memcpy((void*)buf1,(void*)buf,length1);
		  memcpy((void*)&dest1,(void*)(buf+length1),sizeof(dest1));
		  memcpy((void*)buf2,(void*)(buf+length1+sizeof(dest1)),length2);
		  memcpy((void*)&dest2,(void*)(buf+length1+length2+sizeof(dest1)),sizeof(dest2));
		  sendto(sockfd, buf1, length1, 0, (struct sockaddr*)&dest1, sizeof(dest1));
		  sendto(sockfd, buf2, length2, 0, (struct sockaddr*)&dest2, sizeof(dest2));
		  free(buf1);
		  free(buf2);
		}
	      else 
		{
		  unsigned char length=buf[498];
		  unsigned char *buf1;
		  struct sockaddr_storage dest1;
		  buf1=(unsigned char*)malloc(length);
		  memcpy((void*)buf1,(void*)buf,length);
		  memcpy((void*)&dest1,(void*)(buf+length),sizeof(dest1));
		  sendto(sockfd, buf1, length, 0, (struct sockaddr*)&dest1, sizeof(dest1));
		  free(buf1);
		}
	    }
	  start=start->next;
	}
      cleanup(1);
      pthread_mutex_unlock(&numconnectlock);
    }
  return 0;
}
