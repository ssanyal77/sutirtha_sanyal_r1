//Author - Sutirtha Sanyal
#include <stdio.h>
#include <stdlib.h>
#define __USE_LARGEFILE64
#define __USE_FILE_OFFSET64
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <time.h>
#include <sys/stat.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <termios.h>
#include <ctype.h>
#include <dirent.h>
#include <inttypes.h>
#define MAXINOUTBUF 51200
#define BUFSIZE 51350
#define KEY_SIZE 16
#define EXPANDED_KEY_SIZE 176
unsigned char s_2_as_key[KEY_SIZE]; 
unsigned char session_key_expanded[EXPANDED_KEY_SIZE];
unsigned char validity[4];
unsigned char myid[40]; 
void  aes_128_encrypt_cbc(void * input, void * key, void * iv, size_t datasize,void * output);
void  aes_128_decrypt_cbc(void * input, void * key, void * iv, size_t datasize,void * output);
void  aes_128_n_encrypt_cbc(void * input, void * key, void * iv, size_t datasize,void * output);
void  aes_128_n_decrypt_cbc(void * input, void * key, void * iv, size_t datasize,void * output);
void expandkey (void* key, void * expanded_key);
struct sockaddr_storage as_addr_storage;
pthread_mutex_t global_auth_thread_lock;
pthread_mutex_t global_serv_client_lock;
void generate_one_nonce(unsigned char nonce[KEY_SIZE])
{
  int i;
  for (i=0;i<KEY_SIZE;i++)
    nonce[i]=rand()%256;
}
unsigned char have_key='N';
void construct_addr(char * name,char * portno,struct addrinfo * addr)
{
  struct addrinfo hints, *servinfo=NULL;
  int rv;
  memset((void*)&hints, 0, sizeof (hints));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_DGRAM;
  if ((rv=getaddrinfo(name, portno, &hints, &servinfo))!=0)
    {
      fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
      exit(1);
    }
  *addr=*servinfo;
}
typedef struct tag3
{
  int client_int_socket;
  unsigned char clientid[40];
  unsigned char myid[40];
  struct sockaddr_storage return_storage;
  struct sockaddr_storage int_storage;
}client_auth_arg;
client_auth_arg argtoauth;
typedef struct tag5
{
  int client_int_socket;
  unsigned char clientid[40];
  struct sockaddr_storage return_storage;
  struct sockaddr_storage int_storage;
  unsigned char first_buf[500];
}client_serv_arg;
client_serv_arg argtoserv;
typedef struct tag4{
  pthread_t th;
  int  tid;
  int main_socket;
  int thread_socket;
  char alive;
  struct tag4 * next;
}threadinfo;
typedef struct tag7{
  pthread_t th;
  unsigned char cid[40];
  struct sockaddr_storage client_addr;
  int main_socket;
  int thread_socket;
  unsigned char alive;
  unsigned char waiting;
  struct sockaddr_storage client_int_storage;
  struct tag7* next;
}servingclientinfo;
typedef struct tag9{
  char *name;
  struct tag9* next;
}entry;
threadinfo * global_thread_list=NULL;
servingclientinfo * global_servingclient_list=NULL;
int num_s_clt;
void freelist(entry *list)
{
  entry *list2;
  while(list!=NULL)
    {
      list2=list->next;
      free(list->name);
      free(list);
      list=list2;
    }
}
void create_list(int * fd,const char *filename,char *base, entry **dirs)
{
  DIR * dirp=opendir(base);
  struct dirent* direntry=NULL;
  if (dirp!=NULL) direntry=readdir(dirp);
  entry * dirs2=NULL;
  while(direntry!=NULL)
    {
      if(direntry->d_type==4 && strcmp(direntry->d_name,".")!=0 && strcmp(direntry->d_name,"..")!=0)
	{
	  if((*dirs)==NULL)(*dirs)=malloc(sizeof(entry));
	  else
	    {
	      (*dirs)->next=malloc(sizeof(entry));
	      (*dirs)=(*dirs)->next;
	    }
	  if(dirs2==NULL)(dirs2)=(*dirs);
	  (*dirs)->name=malloc(sizeof(char)*(strlen(direntry->d_name)+1));
	  memset(((*dirs)->name),0,(strlen(direntry->d_name)+1));
	  memcpy((*dirs)->name,direntry->d_name,strlen(direntry->d_name));
	  (*dirs)->next=NULL;
	}
      else if (direntry->d_type==8 && strcmp(direntry->d_name,filename)==0)
	{
	  char *base3=malloc(strlen(base)+2+strlen(filename));
	  memset(base3,0,strlen(base)+2+strlen(filename));
	  memcpy(base3,base,strlen(base));
	  strcat(base3,"/");
	  strcat(base3,filename);
	  *fd=open64(base3,O_RDONLY);
	  free(base3);
	  *dirs=dirs2;
	  closedir(dirp);
	  return;
	}
      direntry=readdir(dirp);
    }
  closedir(dirp);
  *dirs=dirs2;
}
void searchfromhere(const char* filename,int *fd,char *base,char *add)
{
  entry *dirs=NULL;
  char *base2;
  if(add!=NULL)
    {
      base2=malloc((strlen(base)+strlen(add)+2)*sizeof(char));
      memset(base2,0,(strlen(base)+strlen(add)+2));
      memcpy(base2,base,strlen(base));
      strcat(base2,"/");
      strcat(base2,add);
    }
  else
    {
      base2=malloc((strlen(base)+1)*sizeof(char));
      memset(base2,0,(strlen(base)+1));
      memcpy(base2,base,strlen(base));
    }
  create_list(fd,filename,base2,&dirs);
  if(*fd!=-1) 
    {
      free(base2);
      freelist(dirs);
      return;
    }
  while(dirs!=NULL)
    {
      searchfromhere(filename,fd,base2,dirs->name);
      if(*fd!=-1) 
	{
	  free(base2);
	  freelist(dirs);
	  return;
	}
      entry * dirs2;
      dirs2=dirs->next;
      free(dirs);
      dirs=dirs2;
    }
  free(base2);
  return; 
}
void cleanup(threadinfo ** f1, char ind)
{
  threadinfo * th_start1=*f1;
  if(th_start1==NULL) return;
  threadinfo * th_start2=th_start1->next;
  int tid=pthread_self();
  while(th_start1!=NULL)
    {
      if (th_start2!=NULL)
	{
	  if (th_start1->tid==tid && ind==0)
	    {
	      th_start1->alive=0;
	      return;
	    }
	  if(th_start1->alive==0 && ind==1)
	    {
	      *f1=th_start1->next;
	      close(th_start1->main_socket);
	      close(th_start1->thread_socket);
       	      free(th_start1);
	      return;
	    }
	  if (th_start2->tid==tid && ind==0)
	    {
	      th_start2->alive=0;
	      return;
	    }
	  if(th_start2->alive==0 && ind==1)
	    {
	      th_start1->next=th_start2->next;
	      close(th_start2->main_socket);
	      close(th_start2->thread_socket);
       	      free(th_start2);
	      return;
	    }     
	}
      else
	{
	  if (th_start1->tid==tid && ind==0)
	    {
	      th_start1->alive=0;
	      return;
	    }
	  if(th_start1->alive==0 && ind==1)
	    {
	      *f1=NULL;
	      close(th_start1->main_socket);
	      close(th_start1->thread_socket);
       	      free(th_start1);
	      return;
	    }     
	}
      th_start1=th_start1->next;
      if(th_start1!=NULL)
	th_start2=th_start1->next;
    }
  return;
}
void cleanup2(servingclientinfo ** f1,unsigned char name[], struct sockaddr_storage *st)
{
  servingclientinfo * th_start1=*f1;
  servingclientinfo * th_start2=NULL;
  if(th_start1!=NULL)th_start2=th_start1->next;
  while(th_start1!=NULL)
    {
      if (th_start2!=NULL)
	{
	  if (memcmp(th_start1->cid,name,40)==0 && memcmp((void*)&(th_start1->client_addr),(void*)st,sizeof(struct sockaddr_storage))==0 )
	    {
	      memset(th_start1->cid,0,40);
	      memset((void*)&(th_start1->client_addr),0,sizeof(struct sockaddr_storage));
	      th_start1->alive=0;
	      return;
	    }
	  else if (memcmp(th_start2->cid,name,40)==0  && memcmp((void*)&(th_start2->client_addr),(void*)st,sizeof(struct sockaddr_storage))==0 )
	    {
	      memset(th_start2->cid,0,40);
	      memset((void*)&(th_start2->client_addr),0,sizeof(struct sockaddr_storage));
	      th_start2->alive=0;
	      return;
	    }
	}
      else
	{
	  if (memcmp(th_start1->cid,name,40)==0  && memcmp((void*)&(th_start1->client_addr),(void*)st,sizeof(struct sockaddr_storage))==0) 
	    {
	      memset(th_start1->cid,0,40);
	      memset((void*)&(th_start1->client_addr),0,sizeof(struct sockaddr_storage));
	      th_start1->alive=0;
	      return;
	    }
	}
      th_start1=th_start1->next;
      if(th_start1!=NULL)
	th_start2=th_start1->next;
    }
  return;
}
void cleanup3(void)
{
  servingclientinfo * th_start1=global_servingclient_list;
  if(th_start1==NULL) return;
  servingclientinfo * th_start2=th_start1->next;
  while(th_start1!=NULL)
    {
      if (th_start2!=NULL)
	{
	  if (th_start1->alive==0)
	    {
	      if(th_start1->waiting==0)
		num_s_clt--;
	      global_servingclient_list=th_start1->next;
	      close(th_start1->main_socket);
	      close(th_start1->thread_socket);
	      free(th_start1);
	      return;
	    }
	  else if (th_start2->alive==0)
	    {
	      if(th_start2->waiting==0)
		num_s_clt--;
	      th_start1->next=th_start2->next;
	      close(th_start2->main_socket);
	      close(th_start2->thread_socket);
	      free(th_start2);
	      return;
	    }
	}
      else
	{
	  if (th_start1->alive==0) 
	    {
	      if(th_start1->waiting==0)
		num_s_clt--;
	      global_servingclient_list=NULL;
	      close(th_start1->main_socket);
	      close(th_start1->thread_socket);
	      free(th_start1);
	      return;
	    }
	}
      th_start1=th_start1->next;
      if(th_start1!=NULL)
	th_start2=th_start1->next;
    }
  return;
}
void create_new_auth_thread(void *(clientauthstart)(void * arg), void* arg, int sock1, int sock2)
{
  threadinfo * th_start=global_thread_list;
  if (th_start!=NULL) 
    while (th_start->next!=NULL)
      th_start = th_start->next;
  if(th_start!=NULL)
    {
      th_start->next=(threadinfo*)malloc(sizeof(threadinfo));
      th_start=th_start->next;
    }
  else
    {
      th_start=(threadinfo*)malloc(sizeof(threadinfo));
      global_thread_list=th_start;
    }
  pthread_create(&(th_start->th),NULL,clientauthstart,arg);
  th_start->tid=(int)th_start->th;
  th_start->main_socket=sock1;
  th_start->thread_socket=sock2;
  th_start->alive=1;
  th_start->next=NULL;
}
void prepare_auth_arg(client_auth_arg *arg, unsigned char clientid[], unsigned char myid[],struct sockaddr_storage int_storage,struct sockaddr_storage client_addr, int client_int_socket)
{
  arg->client_int_socket=client_int_socket;
  memcpy ((arg->clientid),(void*)clientid,40);
  memcpy ((arg->myid),(void*)myid,40);
  memcpy((void*)&(arg->return_storage),(void*)&client_addr,sizeof(struct sockaddr_storage));
  memcpy((void*)&(arg->int_storage),(void*)&int_storage,sizeof(struct sockaddr_storage));
  pthread_mutex_lock(&global_auth_thread_lock);
  pthread_mutex_unlock(&global_auth_thread_lock);
}
void create_or_update_serv_thread(void *(* clientservstart)(void * arg), void* arg,unsigned char clientid[], int main_socket, int thread_socket, struct sockaddr_storage * st, struct sockaddr_storage * clt_addr,char create)
{
  servingclientinfo * th_start=global_servingclient_list;
  if(create){
    if (th_start!=NULL) 
      while (th_start->next!=NULL)
	th_start = th_start->next;
    if(th_start!=NULL)
      {
	th_start->next=(servingclientinfo*)malloc(sizeof(servingclientinfo));
	th_start=th_start->next;
      }
    else
      {
	th_start=(servingclientinfo*)malloc(sizeof(servingclientinfo));
	global_servingclient_list=th_start;
      }
    memcpy(th_start->cid,clientid,40);
    th_start->client_addr=*clt_addr;
    th_start->next=NULL;
    th_start->alive=1;
    th_start->waiting=1;
    return;
  }
  else
    {
      while(th_start!=NULL)
	{
	  if(memcmp(th_start->cid,clientid,40)==0 && memcmp((void*)&th_start->client_addr,clt_addr,sizeof(struct sockaddr_storage))==0)
	    {
	      th_start->main_socket=main_socket;
	      th_start->thread_socket=thread_socket;
	      th_start->client_int_storage=*st;
	      th_start->waiting=0;
	      num_s_clt++;
	      pthread_create(&(th_start->th),NULL,clientservstart,arg);
	    }
	  th_start=th_start->next;
	}
    }
}
void * client_auth_start(void * arg)
{
  unsigned char buf[500]; 
  unsigned char clientid[40];
  unsigned char myid[40];
  struct sockaddr_storage client_addr;
  struct sockaddr_storage this_con_int_storage;
  size_t client_addr_len = sizeof(struct sockaddr_storage); 
  unsigned char ch='Y';
  memset((void*)buf, '\0', 500);
  memcpy((void*)buf,(void*)&ch,1);
  memcpy(myid,(* ((client_auth_arg*)arg) ).myid,40);
  memcpy(clientid,(*((client_auth_arg*)arg)).clientid,40);
  memcpy(&client_addr,&((*((client_auth_arg*)arg)).return_storage),sizeof(struct sockaddr_storage));
  memcpy(&this_con_int_storage,&((*((client_auth_arg*)arg)).int_storage),sizeof(struct sockaddr_storage));
  memcpy((void*)(buf+1),(void*)&myid,40);
  memcpy((void*)(buf+41),(void*)&client_addr,sizeof(struct sockaddr_storage));
  int this_con_socket = (*((client_auth_arg*)arg)).client_int_socket;
  int nummessage=2;
  int length1=41;
  int length2;
  unsigned char nonce[KEY_SIZE],iv_aes[KEY_SIZE],encrypted_nonce[KEY_SIZE];
  generate_one_nonce(nonce);
  memset((void*)iv_aes, '\0', 16);
  aes_128_encrypt_cbc((void *)nonce,(void *)s_2_as_key,(void *)iv_aes,sizeof(nonce),(void *)encrypted_nonce);
  unsigned char message_type=3;
  memcpy((void*)(buf+41+sizeof(struct sockaddr_storage)),(void *)&message_type,1);
  memcpy((void*)(buf+41+sizeof(struct sockaddr_storage)+1),(void *)myid,40);
  memcpy((void*)(buf+41+sizeof(struct sockaddr_storage)+41),(void *)clientid,40);
  memcpy((void*)(buf+41+sizeof(struct sockaddr_storage)+81),(void *)&have_key,1);
  memcpy((void*)(buf+41+sizeof(struct sockaddr_storage)+82),(void *)encrypted_nonce, KEY_SIZE);
  aes_128_encrypt_cbc((void *)encrypted_nonce,(void *)s_2_as_key,(void *)iv_aes,sizeof(nonce),(void *)nonce);
  memcpy((void*)(buf+41+sizeof(struct sockaddr_storage)+98),(void *)nonce, KEY_SIZE);
  aes_128_decrypt_cbc((void *)encrypted_nonce,(void *)s_2_as_key,(void *)iv_aes,sizeof(nonce),(void *)nonce);
  memcpy((void*)(buf+41+sizeof(struct sockaddr_storage)+98+KEY_SIZE),(void *)&as_addr_storage, sizeof(struct sockaddr_storage));
  length2=114;
  memcpy((void*)(buf+497),(void*)&length1,1);
  memcpy((void*)(buf+498),(void*)&length2,1);
  memcpy((void*)(buf+499),(void*)&nummessage,1);
  if (sendto(this_con_socket, buf, 500, 0, (struct sockaddr*)&this_con_int_storage, client_addr_len)==-1)
    {
      pthread_mutex_lock(&global_auth_thread_lock);
      cleanup(&global_thread_list,0);
      pthread_mutex_unlock(&global_auth_thread_lock);
      pthread_exit(NULL);
    }
  memset(buf,0,sizeof(buf));
  unsigned char test_buf[48];
  memset(test_buf,0,48);
  if(  recvfrom(this_con_socket, buf, 80, 0, (struct sockaddr*)&this_con_int_storage, &client_addr_len)==-1)
    {
      pthread_mutex_lock(&global_auth_thread_lock);
      cleanup(&global_thread_list,0);
      pthread_mutex_unlock(&global_auth_thread_lock);
      pthread_exit(NULL);
    }
  if(memcmp(buf+32,test_buf,48)==0) 
    {
      if (buf[0]=='N' && buf[1]=='F') 
	{
	  pthread_mutex_lock(&global_auth_thread_lock);
	  cleanup(&global_thread_list,0);
	  pthread_mutex_unlock(&global_auth_thread_lock);
	  pthread_exit(NULL);
	}
      unsigned char decrypted_message5[17];
      memset((void*)iv_aes, '\0', 16);
      aes_128_decrypt_cbc((void*)buf,(void *)s_2_as_key,(void *)iv_aes,17,(void *)decrypted_message5);
      unsigned char decrypted_nonce[KEY_SIZE];
      unsigned char more_message;
      memcpy((void*)&more_message,(void*)(decrypted_message5),1);
      memcpy((void*)decrypted_nonce,(void*)(decrypted_message5+1),KEY_SIZE);
      if (more_message=='Y')
	{
	  memset((void*)buf, '\0', 500);
	  message_type=7;
	  memcpy((void*)(buf),(void *)&message_type,1);
	  memcpy((void*)(buf+1),(void *)myid,40);
	  memcpy((void*)(buf+41),(void *)clientid,40);
	  memset((void*)iv_aes, '\0', 16);
	  short i;
	  for (i=0;i<KEY_SIZE;i++)
	    decrypted_nonce[i]=decrypted_nonce[i]+1;
	  aes_128_encrypt_cbc((void *)decrypted_nonce,(void *)s_2_as_key,(void *)iv_aes,sizeof(nonce),(void *)encrypted_nonce);
	  memcpy((void*)(buf+81),(void *)encrypted_nonce, 16);
	  memcpy((void*)(buf+81+KEY_SIZE),(void *)&as_addr_storage, sizeof(struct sockaddr_storage));
	  nummessage=1;
	  length1=97;
	  memcpy((void*)(buf+498),(void*)&length1,1);
	  memcpy((void*)(buf+499),(void*)&nummessage,1);
	  if (sendto(this_con_socket, buf ,500 , 0, (struct sockaddr*)&this_con_int_storage, sizeof(struct sockaddr_storage))==-1)
	    {
	      pthread_mutex_lock(&global_auth_thread_lock);
	      cleanup(&global_thread_list,0);
	      pthread_mutex_unlock(&global_auth_thread_lock);
	      pthread_exit(NULL);
	    }
	  if (recvfrom(this_con_socket, buf ,80 , 0, (struct sockaddr*)&this_con_int_storage, &client_addr_len)==-1)
	    {
	      pthread_mutex_lock(&global_auth_thread_lock);
	      cleanup(&global_thread_list,0);
	      pthread_mutex_unlock(&global_auth_thread_lock);
	      pthread_exit(NULL);
	    }
	  memset((void*)iv_aes, '\0', 16);
	  unsigned char decrypted_all[80];
	  aes_128_decrypt_cbc(buf,(void *)s_2_as_key,(void *)iv_aes,80,(void *)decrypted_all);
	  unsigned char test_nonce[KEY_SIZE];
	  memcpy((void*)test_nonce, decrypted_all+40+20+1,16);
	  if(memcmp(test_nonce,nonce,KEY_SIZE)!=0)
	    {
	      pthread_mutex_lock(&global_auth_thread_lock);
	      cleanup(&global_thread_list,0);
	      pthread_mutex_unlock(&global_auth_thread_lock);
	      pthread_exit(NULL);
	    }
	  pthread_mutex_lock(&global_serv_client_lock);
	  if (num_s_clt==0)
	    {
	      expandkey(decrypted_all+40+1,(void*)session_key_expanded);
	    }        
	  memcpy((void*)validity, decrypted_all+40+16+1,4);
	  pthread_mutex_lock(&global_auth_thread_lock);
	  have_key='Y';
	  pthread_mutex_unlock(&global_auth_thread_lock);
	  char filenm[56];
	  sprintf(filenm,"session_key.out.%s",myid);
	  FILE *fp_key=fopen(filenm,"w");
	  unsigned char session_key_new[EXPANDED_KEY_SIZE];
	  unsigned char session_key_enc[EXPANDED_KEY_SIZE];
	  unsigned char validity_enc[KEY_SIZE];
	  expandkey(decrypted_all+40+1,(void*)session_key_new);
	  aes_128_encrypt_cbc(session_key_new,s_2_as_key,iv_aes,EXPANDED_KEY_SIZE,session_key_enc);
	  aes_128_encrypt_cbc(decrypted_all+40+16+1,s_2_as_key,iv_aes,4,validity_enc);
	  fwrite(validity_enc,1,KEY_SIZE,fp_key);
	  fwrite(session_key_enc,1,EXPANDED_KEY_SIZE,fp_key);
	  fclose(fp_key);
	  create_or_update_serv_thread(NULL,NULL,clientid,-1,-1,NULL,&client_addr,1);
	  pthread_mutex_unlock(&global_serv_client_lock);
	}
      else
	{
	  if(memcmp(decrypted_nonce,nonce,KEY_SIZE)!=0) 
	    {
	      pthread_mutex_lock(&global_auth_thread_lock);
	      cleanup(&global_thread_list,0);
	      pthread_mutex_unlock(&global_auth_thread_lock);
	      pthread_exit(NULL);
	    }
	  pthread_mutex_lock(&global_serv_client_lock);
	  create_or_update_serv_thread(NULL,NULL,clientid,-1,-1,NULL,&client_addr,1);
	  pthread_mutex_unlock(&global_serv_client_lock);
	}
    }
  else 
    {
      memset((void*)iv_aes, '\0', 16);
      unsigned char decrypted_all[80];
      aes_128_decrypt_cbc(buf,(void *)s_2_as_key,(void *)iv_aes,80,(void *)decrypted_all);
      unsigned char test_nonce[KEY_SIZE];
      memcpy((void*)test_nonce, decrypted_all+40+20+1,16);
      if(memcmp(test_nonce,nonce,KEY_SIZE)!=0)
	{
	  pthread_mutex_lock(&global_auth_thread_lock);
	  cleanup(&global_thread_list,0);
	  pthread_mutex_unlock(&global_auth_thread_lock);
	  pthread_exit(NULL);
	}
      pthread_mutex_lock(&global_serv_client_lock);
      if (num_s_clt==0)
	{
	  expandkey(decrypted_all+40+1,(void*)session_key_expanded);
	}
      memcpy((void*)validity, decrypted_all+40+16+1,4);
      pthread_mutex_lock(&global_auth_thread_lock);
      have_key='Y';
      pthread_mutex_unlock(&global_auth_thread_lock);
      char filenm[56];
      sprintf(filenm,"session_key.out.%s",myid);
      FILE *fp_key=fopen(filenm,"w");
      unsigned char session_key_new[EXPANDED_KEY_SIZE];
      unsigned char session_key_enc[EXPANDED_KEY_SIZE];
      unsigned char validity_enc[KEY_SIZE];
      expandkey(decrypted_all+40+1,(void*)session_key_new);
      aes_128_encrypt_cbc(session_key_new,s_2_as_key,iv_aes,EXPANDED_KEY_SIZE,session_key_enc);
      aes_128_encrypt_cbc(decrypted_all+40+16+1,s_2_as_key,iv_aes,4,validity_enc);
      fwrite(validity_enc,1,KEY_SIZE,fp_key);
      fwrite(session_key_enc,1,EXPANDED_KEY_SIZE,fp_key);
      fclose(fp_key);
      create_or_update_serv_thread(NULL,NULL,clientid,-1,-1,NULL,&client_addr,1);
      pthread_mutex_unlock(&global_serv_client_lock);  
    }
  pthread_mutex_lock(&global_auth_thread_lock);
  cleanup(&global_thread_list,0);
  pthread_mutex_unlock(&global_auth_thread_lock);
  pthread_exit(NULL);
} 
void * remove_stalled(void *arg)
{
  while(1)
    {
      sleep(1);
      pthread_mutex_lock(&global_serv_client_lock);
      servingclientinfo *start=global_servingclient_list;
      while(start!=NULL)
	{
	  if(start->waiting!=0)
	    start->waiting++;
	  if (start->waiting==3)
	    start->alive=0;
	  start=start->next;
	}
      pthread_mutex_unlock(&global_serv_client_lock);
    }
}
char unique_client(unsigned char clientid[],int * main_sock,struct sockaddr_storage *st, struct sockaddr_storage *clt_addr)
{
  pthread_mutex_lock(&global_serv_client_lock);
  servingclientinfo *start=global_servingclient_list;
  while(start!=NULL)
    {
      if(memcmp(start->cid,clientid,40)==0 && memcmp((void*)&(start->client_addr),(void*)clt_addr,sizeof(struct sockaddr_storage))==0 )
	{
	  *main_sock = start->main_socket;
	  *st=start->client_int_storage;
	  pthread_mutex_unlock(&global_serv_client_lock);
	  if (start->waiting!=0 && start->alive==1)
	    return 1;
	  else if (start->waiting==0 && start->alive==1)
	    return 2;
	}
      start=start->next;
    }
  pthread_mutex_unlock(&global_serv_client_lock);
  return 0;
}
void prepare_serv_arg(client_serv_arg *arg, unsigned char clientid[], struct sockaddr_storage client_addr, int client_int_socket, struct sockaddr_storage internal_storage, unsigned char buf[])
{
  arg->client_int_socket=client_int_socket;
  memcpy((void*)(arg->clientid),(void*)clientid,40);
  memcpy((void*)&(arg->return_storage),(void*)&client_addr,sizeof(struct sockaddr_storage));
  memcpy((void*)&(arg->int_storage),(void*)&internal_storage,sizeof(struct sockaddr_storage));
  memset((void*)&(arg->first_buf),0,500);
  memcpy((void*)&(arg->first_buf),(void*)buf,451);
}
void * client_serv_start(void* arg)
{
  struct sockaddr_storage my_int_storage;
  struct sockaddr_storage client_addr;
  unsigned char my_id[40];
  unsigned char my_buf[BUFSIZE],my_buf_e[BUFSIZE];
  unsigned char iv_aes[KEY_SIZE];
  memset(iv_aes,0,KEY_SIZE);
  size_t addr_len=sizeof(struct sockaddr_storage);
  int this_con_socket = (*((client_serv_arg*)arg)).client_int_socket;
  memcpy(&client_addr,&(*((client_serv_arg*)arg)).return_storage,sizeof(struct sockaddr_storage));
  memcpy(&my_int_storage,&(*((client_serv_arg*)arg)).int_storage,sizeof(struct sockaddr_storage));
  memcpy(my_buf,(*((client_serv_arg*)arg)).first_buf,sizeof((*((client_serv_arg*)arg)).first_buf));
  memcpy(my_id,(*((client_serv_arg*)arg)).clientid,sizeof(my_id));
  unsigned char message_type;
  aes_128_n_decrypt_cbc(my_buf,session_key_expanded,iv_aes,1,(void*)&message_type);
  if(message_type==1)
    {
      unsigned char client_session_nonce;
      aes_128_n_decrypt_cbc((my_buf+16),session_key_expanded,iv_aes,1,(void*)&client_session_nonce);
      memset(my_buf,0,sizeof(my_buf));
      aes_128_n_encrypt_cbc((void *)myid,(void *)session_key_expanded,(void *)iv_aes,40,(void *)my_buf);
      unsigned char response_type=1;
      aes_128_n_encrypt_cbc((void *)&response_type,(void *)session_key_expanded,(void *)iv_aes,1,(void *)(my_buf+48));
      client_session_nonce=client_session_nonce+1;
      aes_128_n_encrypt_cbc((void *)&client_session_nonce,(void *)session_key_expanded,(void *)iv_aes,1,(void *)(my_buf+64));
      memcpy(my_buf+80,&client_addr,sizeof(struct sockaddr_storage));
      unsigned int length=80;
      unsigned char nummessage=1;
      memcpy((void*)&(my_buf[BUFSIZE-5]),(void*)&length,4);
      my_buf[BUFSIZE-1]=nummessage;
      if(sendto(this_con_socket, my_buf, BUFSIZE, 0, (struct sockaddr*)&my_int_storage, sizeof(struct sockaddr_storage))!= BUFSIZE)
	{
	  pthread_mutex_lock(&global_serv_client_lock);
	  cleanup2(&global_servingclient_list,my_id,&client_addr);
	  if(num_s_clt==1)
	    {
	      memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
	      memset(validity,0,4);
	      pthread_mutex_lock(&global_auth_thread_lock);
	      have_key='N';
	      pthread_mutex_unlock(&global_auth_thread_lock);
	    }
	  pthread_mutex_unlock(&global_serv_client_lock);  
	  pthread_exit(NULL);
	}
    }
  else
    {
      pthread_mutex_lock(&global_serv_client_lock);
      cleanup2(&global_servingclient_list,my_id,&client_addr);
      if(num_s_clt==1)
	{
	  memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
	  memset(validity,0,4);
	  pthread_mutex_lock(&global_auth_thread_lock);
	  have_key='N';
	  pthread_mutex_unlock(&global_auth_thread_lock);
	}
      pthread_mutex_unlock(&global_serv_client_lock);  
      pthread_exit(NULL);
    }
  if(recvfrom(this_con_socket, my_buf, 451, 0, (struct sockaddr*)&my_int_storage, &addr_len)!=-1)
    {
      aes_128_n_decrypt_cbc((void *)(my_buf),(void *)session_key_expanded,(void *)iv_aes,1,&message_type);
    }
  else
    {
      pthread_mutex_lock(&global_serv_client_lock);
      cleanup2(&global_servingclient_list,my_id,&client_addr);
      if(num_s_clt==1)
	{
	  memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
	  memset(validity,0,4);
	  pthread_mutex_lock(&global_auth_thread_lock);
	  have_key='N';
	  pthread_mutex_unlock(&global_auth_thread_lock);
	}
      pthread_mutex_unlock(&global_serv_client_lock);
      pthread_exit(NULL);
    }
  if (message_type==2)
    {
      char filename[256];
      aes_128_n_decrypt_cbc((my_buf+16),session_key_expanded,iv_aes,256,(void*)filename);
      int fd=-1;
      searchfromhere(filename,&fd,".",NULL);
      memset(my_buf,0,sizeof(my_buf));
      aes_128_n_encrypt_cbc((void *)myid,(void *)session_key_expanded,(void *)iv_aes,40,(void *)my_buf);
      unsigned char response_type=1;
      aes_128_n_encrypt_cbc((void *)&response_type,(void *)session_key_expanded,(void *)iv_aes,1,(void *)(my_buf+48));
      if (fd==-1)
	{
	  unsigned char filefound = 'N';
	  aes_128_n_encrypt_cbc((void *)&filefound,(void *)session_key_expanded,(void *)iv_aes,1,(void *)(my_buf+64));
	  memcpy(my_buf+80,&client_addr,sizeof(struct sockaddr_storage));
	  unsigned int length=80;
	  unsigned char nummessage=1;
	  memcpy((void*)&(my_buf[BUFSIZE-5]),(void*)&length,4); 
	  my_buf[BUFSIZE-1]=nummessage;
	  if(sendto(this_con_socket, my_buf, BUFSIZE, 0, (struct sockaddr*)&my_int_storage, sizeof(struct sockaddr_storage))!= BUFSIZE)
	    {
	      pthread_mutex_lock(&global_serv_client_lock);
	      cleanup2(&global_servingclient_list,my_id,&client_addr);
	      if(num_s_clt==1)
		{
		  memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
		  memset(validity,0,4);
		  pthread_mutex_lock(&global_auth_thread_lock);
		  have_key='N';
		  pthread_mutex_unlock(&global_auth_thread_lock);
		}
	      pthread_mutex_unlock(&global_serv_client_lock); 
	      pthread_exit(NULL);
	    }
	}
      else
	{
	  unsigned char filefound='Y';
	  aes_128_n_encrypt_cbc((void *)&filefound,(void *)session_key_expanded,(void *)iv_aes,1,(void *)(my_buf+64));
	  uint64_t filesize=(uint64_t)(lseek64(fd,(off_t)0,SEEK_END));
	  lseek64(fd,(off_t)0,SEEK_SET);
	  aes_128_n_encrypt_cbc((void *)&filesize,(void *)session_key_expanded,(void *)iv_aes,sizeof(uint64_t),(void *)(my_buf+80));
	  memcpy(my_buf+96,&client_addr,sizeof(struct sockaddr_storage));
	  unsigned int length=96;
	  unsigned char nummessage=1;
	  memcpy((void*)&(my_buf[BUFSIZE-5]),(void*)&length,4); 
	  my_buf[BUFSIZE-1]=nummessage;
	  if(sendto(this_con_socket, my_buf, BUFSIZE, 0, (struct sockaddr*)&my_int_storage, sizeof(struct sockaddr_storage))!=BUFSIZE)
	    {
              close(fd);
	      pthread_mutex_lock(&global_serv_client_lock);
	      cleanup2(&global_servingclient_list,my_id,&client_addr);
	      if(num_s_clt==1)
		{
		  memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
		  memset(validity,0,4);
		  pthread_mutex_lock(&global_auth_thread_lock);
		  have_key='N';
		  pthread_mutex_unlock(&global_auth_thread_lock);
		}
	      pthread_mutex_unlock(&global_serv_client_lock); 
	      pthread_exit(NULL);
	    }
	  memset(my_buf,0,sizeof(my_buf));
	  if(recvfrom(this_con_socket, my_buf, 451, 0, (struct sockaddr*)&my_int_storage, &addr_len)!=-1)
	    {
	      aes_128_n_decrypt_cbc((void *)(my_buf),(void *)session_key_expanded,(void *)iv_aes,1,&message_type);
	    }
	  else
	    {
              close(fd);
	      pthread_mutex_lock(&global_serv_client_lock);
	      cleanup2(&global_servingclient_list,my_id,&client_addr);
	      if(num_s_clt==1)
		{
		  memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
		  memset(validity,0,4);
		  pthread_mutex_lock(&global_auth_thread_lock);
		  have_key='N';
		  pthread_mutex_unlock(&global_auth_thread_lock);
		}
	      pthread_mutex_unlock(&global_serv_client_lock);
	      pthread_exit(NULL);
	    }
	  int rem=filesize%MAXINOUTBUF;
	  int numblock=(filesize-rem)/MAXINOUTBUF;
	  int startprocess=0;
	  while(startprocess <numblock+1)
	    {
	      memset(my_buf,0,sizeof(my_buf));
	      memset(my_buf_e,0,sizeof(my_buf_e));
	      if(startprocess<numblock)
		{
		  if (read(fd,my_buf,MAXINOUTBUF))
		    {
		      aes_128_n_encrypt_cbc((void *)my_buf,(void *)session_key_expanded,(void *)iv_aes,MAXINOUTBUF,(void *)(my_buf_e));
		      aes_128_n_encrypt_cbc((void *)my_buf_e,(void *)session_key_expanded,(void *)iv_aes,MAXINOUTBUF,(void *)(my_buf));
		      memcpy(my_buf_e+MAXINOUTBUF,&client_addr,sizeof(struct sockaddr_storage));
		      unsigned int length=MAXINOUTBUF;
		      memcpy((void*)&(my_buf_e[BUFSIZE-5]),(void*)&length,4); 
		      my_buf_e[BUFSIZE-1]=1;
		      if(sendto(this_con_socket, my_buf_e, BUFSIZE, 0, (struct sockaddr*)&my_int_storage, sizeof(struct sockaddr_storage))!= BUFSIZE)
			{
                          close(fd);
			  pthread_mutex_lock(&global_serv_client_lock);
			  cleanup2(&global_servingclient_list,my_id,&client_addr);
			  if(num_s_clt==1)
			    {
			      memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
			      memset(validity,0,4);
			      pthread_mutex_lock(&global_auth_thread_lock);
			      have_key='N';
			      pthread_mutex_unlock(&global_auth_thread_lock);
			    }
			  pthread_mutex_unlock(&global_serv_client_lock);
			  pthread_exit(NULL);
			}
		    }
		}
	      else
		{
		  if(read(fd,my_buf,rem))
		    {
		      aes_128_n_encrypt_cbc((void *)my_buf,(void *)session_key_expanded,(void *)iv_aes,rem,(void *)(my_buf_e));
		      aes_128_n_encrypt_cbc((void *)my_buf_e,(void *)session_key_expanded,(void *)iv_aes,rem+16-rem%16,(void *)(my_buf));
		      memcpy(my_buf_e+rem+16-rem%16,&client_addr,sizeof(struct sockaddr_storage));
		      unsigned int length=(rem+16-rem%16);
		      memcpy((void*)&(my_buf_e[BUFSIZE-5]),(void*)&length,4); 
		      my_buf_e[BUFSIZE-1]=1;
		      if(sendto(this_con_socket, my_buf_e, BUFSIZE, 0, (struct sockaddr*)&my_int_storage, sizeof(struct sockaddr_storage))!= BUFSIZE)
			{
                          close(fd);
			  pthread_mutex_lock(&global_serv_client_lock);
			  cleanup2(&global_servingclient_list,my_id,&client_addr);
			  if(num_s_clt==1)
			    {
			      memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
			      memset(validity,0,4);
			      pthread_mutex_lock(&global_auth_thread_lock);
			      have_key='N';
			      pthread_mutex_unlock(&global_auth_thread_lock);
			    }
			  pthread_mutex_unlock(&global_serv_client_lock); 
			  pthread_exit(NULL);
			}
		    }
		  else
		    {
		      aes_128_n_encrypt_cbc((void *)my_buf,(void *)session_key_expanded,(void *)iv_aes,0,(void *)(my_buf_e));
		      aes_128_n_encrypt_cbc((void *)my_buf_e,(void *)session_key_expanded,(void *)iv_aes,rem+16-rem%16,(void *)(my_buf));
		      memcpy(my_buf_e+rem+16-rem%16,&client_addr,sizeof(struct sockaddr_storage));
		      unsigned int length=(rem+16-rem%16);
		      memcpy((void*)&(my_buf_e[BUFSIZE-5]),(void*)&length,4);
		      my_buf_e[BUFSIZE-1]=1;
		      if (sendto(this_con_socket, my_buf_e, BUFSIZE, 0, (struct sockaddr*)&my_int_storage, sizeof(struct sockaddr_storage))!= BUFSIZE)
			{
                          close(fd);
			  pthread_mutex_lock(&global_serv_client_lock);
			  cleanup2(&global_servingclient_list,my_id,&client_addr);
			  if(num_s_clt==1)
			    {
			      memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
			      memset(validity,0,4);
			      pthread_mutex_lock(&global_auth_thread_lock);
			      have_key='N';
			      pthread_mutex_unlock(&global_auth_thread_lock);
			    }
			  pthread_mutex_unlock(&global_serv_client_lock);
			  pthread_exit(NULL);
			}
		    }
		}
	      memset(my_buf_e,0,sizeof(my_buf_e));
	      if(recvfrom(this_con_socket, my_buf_e, 451, 0, (struct sockaddr*)&my_int_storage, &addr_len)!=-1)
		{
		  //Continue transferring remaining pieces if mac matches
		  unsigned char mac[KEY_SIZE];
		  if (startprocess < numblock)
		    memcpy(mac,&(my_buf[MAXINOUTBUF-KEY_SIZE]),KEY_SIZE);
		  else
		    memcpy(mac,&(my_buf[rem-rem%16]),KEY_SIZE);
		  if (memcmp(mac,my_buf_e,KEY_SIZE)!=0)
		    {
		      close(fd);
		      pthread_mutex_lock(&global_serv_client_lock);
		      cleanup2(&global_servingclient_list,my_id,&client_addr);
		      if(num_s_clt==1)
			{
			  memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
			  memset(validity,0,4);
			  pthread_mutex_lock(&global_auth_thread_lock);
			  have_key='N';
			  pthread_mutex_unlock(&global_auth_thread_lock);
			}
		      pthread_mutex_unlock(&global_serv_client_lock);
		      pthread_exit(NULL);
		    }
		}
	      else
		{
		  close(fd);
		  pthread_mutex_lock(&global_serv_client_lock);
		  cleanup2(&global_servingclient_list,my_id,&client_addr);
		  if(num_s_clt==1)
		    {
		      memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
		      memset(validity,0,4);
		      pthread_mutex_lock(&global_auth_thread_lock);
		      have_key='N';
		      pthread_mutex_unlock(&global_auth_thread_lock);
		    }
		  pthread_mutex_unlock(&global_serv_client_lock);
		  pthread_exit(NULL);
		}
	      startprocess++;
	    }
	  close(fd);
	  unsigned char ok[3]={'o','k','\0'};
	  memset(my_buf,0,sizeof(my_buf));
	  aes_128_n_encrypt_cbc((void *)ok,(void *)session_key_expanded,(void *)iv_aes,3,(void *)(my_buf));
	  memcpy(my_buf+KEY_SIZE,&client_addr,sizeof(struct sockaddr_storage));
	  length=16;
	  memcpy(&(my_buf[BUFSIZE-5]),(void*)&length,4);
	  my_buf[BUFSIZE-1]=1;
	  if(sendto(this_con_socket, my_buf, BUFSIZE, 0, (struct sockaddr*)&my_int_storage, sizeof(struct sockaddr_storage))!= BUFSIZE)
	    {
	      pthread_mutex_lock(&global_serv_client_lock);
	      cleanup2(&global_servingclient_list,my_id,&client_addr);
	      if(num_s_clt==1)
		{
		  memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
		  memset(validity,0,4);
		  pthread_mutex_lock(&global_auth_thread_lock);
		  have_key='N';
		  pthread_mutex_unlock(&global_auth_thread_lock);
		}
	      pthread_mutex_unlock(&global_serv_client_lock);  
	      pthread_exit(NULL);
	    }
	}
    }
  pthread_mutex_lock(&global_serv_client_lock);
  cleanup2(&global_servingclient_list,my_id,&client_addr);
  if(num_s_clt==1)
    {
      memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
      memset(validity,0,4);
      pthread_mutex_lock(&global_auth_thread_lock);
      have_key='N';
      pthread_mutex_unlock(&global_auth_thread_lock);
    }
  pthread_mutex_unlock(&global_serv_client_lock);
  pthread_exit(NULL);
}
int still_valid(int fp_key)
{
  struct stat st;
  fstat(fp_key,&st);
  int val;
  memcpy(&val,validity,4);
  time_t mod=st.st_mtime;
  time_t nw;
  time(&nw);
  if(nw-mod>val)
    return 0;
  return 1;
}
int invalidid(unsigned char clientid[])
{
  int i;
  for (i=0;i<40;i++)
    if (!(isprint(clientid[i])||clientid[i]=='\0'))
      return 1;
  return 0;
}
int main(int argc,  char **argv)
{
  int sockfd;  
  struct addrinfo hints, *servinfo, *p;
  int rv; int buffersize=BUFSIZE;
  unsigned char buf[500],pending_buf[500],buf_serv[BUFSIZE];
  struct addrinfo client_int_addr;
  struct sockaddr_storage client_int_auth_storage;  
  struct sockaddr_storage client_int_auth_storage2;  
  struct sockaddr_storage client_int_serv_storage; 
  struct sockaddr_storage client_int_serv_storage2; 
  struct sockaddr_storage client_int_serv_storage_catch; 
  struct sockaddr_storage pending_client_addr;
  unsigned char clientid[40];
  unsigned char iv_aes[16];
  struct addrinfo as_addr;
  struct timeval rcvwt;
  rcvwt.tv_sec=0;rcvwt.tv_usec=1;
  servingclientinfo *start_poll;
  struct sockaddr_storage client_addr;
  size_t client_addr_len=sizeof(client_addr);
  int pending=0;
  unsigned char encrypted='X';
  char client_int_auth_port[] = "8000";  
  char client_int_serv_port[] = "9000";
  pthread_t rs;
  if (argc != 6 || strlen(argv[5])>=40 ) 
    {
      fprintf(stderr,"usage: ./server IP Port KMSIP KMSPort ServerID\n");
      exit(1);
    }
  memset((void*)s_2_as_key,'\0',KEY_SIZE);
  printf("Password:");
  struct termios old,new;
  tcgetattr(STDIN_FILENO,&old);
  memcpy((void*)&new,(void*)&old,sizeof(struct termios));
  new.c_lflag &= ~ECHO;
  tcsetattr(STDIN_FILENO,TCSANOW,&new);
  if(!scanf("%s",s_2_as_key))
    exit(1);
  tcsetattr(STDIN_FILENO,TCSANOW,&old);
  printf("\n");
  memset((void*)myid, '\0', 40);
  memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
  memcpy(myid,argv[5],strlen(argv[5]));
  srand(time(NULL)+5000);
  construct_addr(argv[3],argv[4],&as_addr);
  as_addr_storage=*((struct sockaddr_storage*)as_addr.ai_addr);
  pthread_mutex_init(&global_auth_thread_lock,NULL);
  pthread_mutex_init(&global_serv_client_lock,NULL);
  memset((void*)&hints, 0, sizeof (hints));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_DGRAM;
  if ((rv = getaddrinfo(argv[1], argv[2], &hints, &servinfo)) != 0) 
    {
      fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
      return 1;
    }
  for(p = servinfo; p != NULL; p = p->ai_next) 
    {
      if ((sockfd = socket(p->ai_family, p->ai_socktype,
			   p->ai_protocol)) == -1) 
	{
	  continue;
	}
      setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,(void *)&rcvwt,sizeof(rcvwt));
      setsockopt(sockfd,SOL_SOCKET,SO_SNDBUF,(void *)&buffersize,sizeof(buffersize));
      if (bind(sockfd,p->ai_addr,p->ai_addrlen) == -1) 
	{
	  close(sockfd);
	  continue;
	}
      break;
    }
  if (p == NULL) 
    {
      fprintf(stderr, "server failed to bind socket\n");
      exit(1);
    }
  memset((void*)iv_aes, '\0', 16);
  int client_int_auth_socket=-1; //main holds it
  int client_int_auth_socket2=-1; //client thread holds it
  int client_int_serv_socket=-1; //main holds it
  int client_int_serv_socket2=-1; //client thread holds it
  num_s_clt=0;
  unsigned char empty;
  pthread_create(&rs,NULL,remove_stalled,NULL);
  while(1)
    {
      empty=0; //Server runs continuously listening from two kinds of addresses. One is connection from Client and other is from KMS
      //(which happens only if it started an authentication request to KMS). Empty=1 means in this pass server didn't read anything.
      memset(buf,0,sizeof(buf));
      if (pending!=1 || have_key!='Y') 
	{
	  if(recvfrom(sockfd, buf, sizeof(buf) , 0, (struct sockaddr*)&client_addr, &client_addr_len)==-1)
	    {
	      empty=1;
	    }
	  if(empty!=1 && memcmp(&client_addr,&as_addr_storage,client_addr_len)!=0)
	    memcpy((void *)&encrypted,(void*)(buf),1);
	}
      if(!empty) 
	{
	  pthread_mutex_lock(&global_auth_thread_lock);
	  if (memcmp(&client_addr,&as_addr_storage,client_addr_len)==0 && (pending!=1 || have_key!='Y'))
	    {
	      pthread_mutex_unlock(&global_auth_thread_lock);
	      sendto(client_int_auth_socket, buf, 80, 0, (struct sockaddr*)&client_int_auth_storage2, sizeof(struct sockaddr_storage));
	    }
	  else if (encrypted=='N' && (pending!=1 || have_key!='Y'))
	    {
	      if(global_thread_list!=NULL)
		{
		  pthread_mutex_unlock(&global_auth_thread_lock);	      
		  continue;	   
		}
	      pthread_mutex_unlock(&global_auth_thread_lock);	      
	      char filenm[56];
	      sprintf(filenm,"session_key.out.%s",myid);
	      int fp_key=open(filenm,O_RDONLY);
	      if(fp_key==-1) {
		pthread_mutex_lock(&global_serv_client_lock);
		if (num_s_clt==0)
		  {
		    pthread_mutex_lock(&global_auth_thread_lock);
		    have_key='N';
		    pthread_mutex_unlock(&global_auth_thread_lock);
		    memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
		    memset(validity,0,4);
		  }
		pthread_mutex_unlock(&global_serv_client_lock);
		close(fp_key);
	      }	      
              else
		{
		  unsigned char buf_temp[EXPANDED_KEY_SIZE];
		  if(!read(fp_key,buf_temp,KEY_SIZE))
		    exit(1);
		  aes_128_decrypt_cbc(buf_temp,s_2_as_key,iv_aes,4,validity);
		  if (still_valid(fp_key))
		    {
		      pthread_mutex_lock(&global_auth_thread_lock);
		      have_key='Y';
		      pthread_mutex_unlock(&global_auth_thread_lock);
		      memset(buf_temp,0,EXPANDED_KEY_SIZE);
		      if(!read(fp_key,buf_temp,EXPANDED_KEY_SIZE))
			exit(1);
		      pthread_mutex_lock(&global_serv_client_lock);
		      if (num_s_clt==0)
			{
			  aes_128_decrypt_cbc(buf_temp,s_2_as_key,iv_aes,EXPANDED_KEY_SIZE,session_key_expanded);
			}
		      pthread_mutex_unlock(&global_serv_client_lock);
		    }
		  else
		    {
		      pthread_mutex_lock(&global_serv_client_lock);
		      if (num_s_clt==0)
			{
			  pthread_mutex_lock(&global_auth_thread_lock);
			  have_key='N';
			  pthread_mutex_unlock(&global_auth_thread_lock);
			  memset(session_key_expanded,0,EXPANDED_KEY_SIZE);
			  memset(validity,0,4);
			}
		      pthread_mutex_unlock(&global_serv_client_lock);
		    }
		  close(fp_key);
		}
	      memcpy((void *)clientid,(void*)(buf+1),40);
	      construct_addr(argv[1],client_int_auth_port,&client_int_addr);
	      if ((client_int_auth_socket = socket(client_int_addr.ai_family, client_int_addr.ai_socktype,
						   client_int_addr.ai_protocol)) == -1) 
		{
		  continue;
		}
	      setsockopt(client_int_auth_socket,SOL_SOCKET,SO_RCVTIMEO,(void *)&rcvwt,sizeof(rcvwt));
	      client_int_auth_storage=*((struct sockaddr_storage*)client_int_addr.ai_addr);
	      if (bind(client_int_auth_socket,client_int_addr.ai_addr,client_int_addr.ai_addrlen) == -1) 
		{
		  continue;
		}
	      int x=strtoll(client_int_auth_port,NULL,10);
	      sprintf(client_int_auth_port,"%d",++x);
	      construct_addr(argv[1],client_int_auth_port,&client_int_addr);
	      if ((client_int_auth_socket2 = socket(client_int_addr.ai_family, client_int_addr.ai_socktype,
						    client_int_addr.ai_protocol)) == -1) 
		{
		  continue;
		}
	      client_int_auth_storage2=*((struct sockaddr_storage*)client_int_addr.ai_addr);
	      struct timeval rcvwt2;
	      rcvwt2.tv_sec=1;rcvwt2.tv_usec=0;
	      setsockopt(client_int_auth_socket2,SOL_SOCKET,SO_RCVTIMEO,(void *)&rcvwt2,sizeof(rcvwt2));
	      if (bind(client_int_auth_socket2,client_int_addr.ai_addr,client_int_addr.ai_addrlen) == -1) 
		{
		  continue;
		}
	      x=strtoll(client_int_auth_port,NULL,10);
	      sprintf(client_int_auth_port,"%d",--x);
	      prepare_auth_arg(&argtoauth,clientid,myid,client_int_auth_storage,client_addr,client_int_auth_socket2);
	      create_new_auth_thread(client_auth_start,(void*)&argtoauth,client_int_auth_socket,client_int_auth_socket2);
	    }
	  else if(have_key=='N' && encrypted=='Y')
	    {
	      pthread_mutex_unlock(&global_auth_thread_lock);
	      if(pending!=1)
		{
		  pending=1;
		  memcpy(pending_buf,buf,sizeof(pending_buf));
		  memcpy(&pending_client_addr,&client_addr,sizeof(struct sockaddr_storage));
		}
	    }
	  else if (have_key=='Y' && (encrypted=='Y' || pending==1)) 
	    {
	      pthread_mutex_unlock(&global_auth_thread_lock);
	      if(pending==1)
		{
		  pending=0;
		  memcpy(buf,pending_buf,sizeof(pending_buf));
		  memcpy(&client_addr,&pending_client_addr,sizeof(struct sockaddr_storage));
		}
	      pthread_mutex_lock(&global_serv_client_lock);
	      aes_128_n_decrypt_cbc(buf+1,session_key_expanded,iv_aes,40,clientid);
	      pthread_mutex_unlock(&global_serv_client_lock);
	      if(invalidid(clientid)) continue;
	      char status = unique_client(clientid,&client_int_serv_socket,&client_int_serv_storage,&client_addr);
	      if (status == 1)
		{
		  construct_addr(argv[1],client_int_serv_port,&client_int_addr);
		  if ((client_int_serv_socket = socket(client_int_addr.ai_family, client_int_addr.ai_socktype,
						       client_int_addr.ai_protocol)) == -1) 
		    {
		      continue;
		    }
		  setsockopt(client_int_serv_socket,SOL_SOCKET,SO_RCVTIMEO,(void *)&rcvwt,sizeof(rcvwt));
		  setsockopt(client_int_serv_socket,SOL_SOCKET,SO_RCVBUF,(void *)&buffersize,sizeof(buffersize));
		  client_int_serv_storage=*((struct sockaddr_storage*)client_int_addr.ai_addr);
		  if (bind(client_int_serv_socket,client_int_addr.ai_addr,client_int_addr.ai_addrlen) == -1) 
		    {
		      continue;
		    }
		  int x;
		  x=strtoll(client_int_serv_port,NULL,10);
		  sprintf(client_int_serv_port,"%d",++x);
		  construct_addr(argv[1],client_int_serv_port,&client_int_addr);
		  client_int_serv_storage2=*((struct sockaddr_storage*)client_int_addr.ai_addr);
		  if ((client_int_serv_socket2 = socket(client_int_addr.ai_family, client_int_addr.ai_socktype,
							client_int_addr.ai_protocol)) == -1) 
		    {
		      continue;
		    }
		  struct timeval rcvwt2;
		  rcvwt2.tv_sec=60;rcvwt2.tv_usec=0;
		  setsockopt(client_int_serv_socket2,SOL_SOCKET,SO_RCVTIMEO,(void *)&rcvwt2,sizeof(rcvwt2));
		  setsockopt(client_int_serv_socket2,SOL_SOCKET,SO_SNDBUF,(void *)&buffersize,sizeof(buffersize));
		  if (bind(client_int_serv_socket2,client_int_addr.ai_addr,client_int_addr.ai_addrlen) == -1) 
		    {
		      continue;
		    }
		  x=strtoll(client_int_serv_port,NULL,10);
		  sprintf(client_int_serv_port,"%d",++x);
		  prepare_serv_arg(&argtoserv,clientid,client_addr,client_int_serv_socket2,client_int_serv_storage,buf+49);
		  pthread_mutex_lock(&global_serv_client_lock);
		  create_or_update_serv_thread(client_serv_start,(void*)&argtoserv,clientid,client_int_serv_socket,client_int_serv_socket2,&client_int_serv_storage2,&client_addr,0);
		  pthread_mutex_unlock(&global_serv_client_lock);
		}
	      else if (status==2)
		{
		  sendto(client_int_serv_socket, buf+49, 451, 0, (struct sockaddr*)&client_int_serv_storage, sizeof(struct sockaddr_storage));
		}
	    }
	  else
	    pthread_mutex_unlock(&global_auth_thread_lock);
	}
      pthread_mutex_lock(&global_auth_thread_lock);
      if(global_thread_list!=NULL)
	{
	  memset(buf,0,sizeof(buf));
	  if(recvfrom(client_int_auth_socket, buf, 500, 0, (struct sockaddr*)&client_int_auth_storage, &client_addr_len)!=-1)
	    {
	      unsigned char nummessage=buf[499];
	      if(nummessage==2) 
		{
		  unsigned char length1=buf[497];
		  unsigned char length2=buf[498];
		  unsigned char *buf1;
		  buf1=(unsigned char*)malloc(length1);
		  struct sockaddr_storage dest1;
		  unsigned char *buf2;
		  buf2=(unsigned char*)malloc(length2);
		  struct sockaddr_storage dest2;
		  memcpy((void*)buf1,(void*)buf,length1);
		  memcpy((void*)&dest1,(void*)(buf+length1),sizeof(dest1));
		  memcpy((void*)buf2,(void*)(buf+length1+sizeof(dest1)),length2);
		  memcpy((void*)&dest2,(void*)(buf+length1+length2+sizeof(dest1)),sizeof(dest1));
		  sendto(sockfd, buf1, length1, 0, (struct sockaddr*)&dest1, sizeof(dest1));
		  sendto(sockfd, buf2, length2, 0, (struct sockaddr*)&dest2, sizeof(dest2));
		  free(buf1);
		  free(buf2);
		}
	      else 
		{
		  unsigned char length1=buf[498];
		  unsigned char *buf1;
		  struct sockaddr_storage dest1;
		  buf1=(unsigned char*)malloc(length1);
		  memcpy((void*)buf1,(void*)buf,length1);
		  memcpy((void*)&dest1,(void*)(buf+length1),sizeof(dest1));
		  sendto(sockfd, buf1, length1, 0, (struct sockaddr*)&dest1, sizeof(dest1));
		  free(buf1);
		}
	    }
	}
      cleanup(&global_thread_list,1);
      pthread_mutex_unlock(&global_auth_thread_lock); 
      pthread_mutex_lock(&global_serv_client_lock);
      start_poll=global_servingclient_list;
      while (start_poll != NULL)
	{
	  memset(buf_serv,0,BUFSIZE);
	  if(recvfrom(start_poll->main_socket, buf_serv, BUFSIZE, 0, (struct sockaddr*)&client_int_serv_storage_catch, &client_addr_len)==BUFSIZE)
	    {
	      unsigned int length1;
	      memcpy((void*)&length1,(void*)&(buf_serv[BUFSIZE-5]),4);
	      unsigned char *buf1;
	      struct sockaddr_storage dest1;
	      buf1=(unsigned char*)malloc(length1);
	      memcpy((void*)buf1,(void*)buf_serv,length1);
	      memcpy((void*)&dest1,(void*)(buf_serv+length1),sizeof(dest1));
	      sendto(sockfd, buf1, length1, 0, (struct sockaddr*)&dest1, sizeof(dest1));
	      free(buf1);
	    }
	  start_poll=start_poll->next;
	}
      cleanup3();
      if(num_s_clt==0)
      	strcpy(client_int_serv_port,"9000");
      pthread_mutex_unlock(&global_serv_client_lock);
    }
  return 0;
}
