void bse(void *ptarr[],void *key,size_t sz,size_t *res,int *dn, int (*cf)(void *a,void *b,void *arg),void *arg);
void * ms(void *head,size_t noffset, size_t poffset,void ** tail,size_t sz,int (*cf)(void *a,void *b,void *arg),void **tmpbuf,size_t tmpbufsize,void *arg);
size_t  msbse(void *head,size_t noffset, size_t poffset,size_t sz,int (*cf)(void *a,void *b,void *arg),void** tmpbuf,size_t tmpbufsize,void * ptarr[],void *key,void *arg);
void * mst(void *head,size_t noffset, size_t sz,int (*cf)(void *a,void *b,void *arg),void **tmpbuf,size_t tmpbufsize,void *arg);
