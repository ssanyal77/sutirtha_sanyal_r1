void bse(void *ptarr[],void *key,size_t sz,void **res,int (*cf)(void *a,void *b));
void * ms(void *head,size_t noffset, size_t poffset,void ** tail,size_t sz,int (*cf)(void *a,void *b),void **tmpbuf,size_t tmpbufsize);
void * msbse(void *head,size_t noffset, size_t poffset,size_t sz,int (*cf)(void *a,void *b),void** tmpbuf,size_t tmpbufsize,void * ptarr[],void *key);
void * mst(void *head,size_t noffset, size_t sz,int (*cf)(void *a,void *b),void **tmpbuf,size_t tmpbufsize);
