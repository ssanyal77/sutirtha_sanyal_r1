//Author - Sutirtha Sanyal
#include<string.h>
#define MAXDEPTH 64
static void* _mst_(void* n, size_t noff,void* * tail,size_t lo,size_t hi,int (*cf)(void* a,void* b),void* *tmpbuf,size_t ub)
{
  void* tl1,*tl2;
  register size_t recd=0, i,j,mid;
  register void * n2,*p,*head;
  void  *narray[MAXDEPTH],*tl1array[MAXDEPTH],*n2array[MAXDEPTH],**tailarray[MAXDEPTH], *retval;
  size_t  loarray[MAXDEPTH],hiarray[MAXDEPTH],midarray[MAXDEPTH];
  short cid[MAXDEPTH];
 start:mid=lo+(hi-lo+1)/2; 
  if(lo==hi){*tail=n;
    if(recd>0){retval=n;if(cid[recd]==1)goto ret1;else goto ret2;}
    else
      return n;
  }
  i=lo;n2=n;
  if(mid<ub && tmpbuf[mid]!=0){
    n2=tmpbuf[mid];
  }
  else
    {
      while(i<mid){
        if(i<ub)tmpbuf[i]=n2;
        /*n2=n2->next;*/
        n2=*((void**)(n2+noff));
        i++;
      }
    }
  n2array[recd]=n2;hiarray[recd]=hi;tailarray[recd]=tail;midarray[recd]=mid;
  recd++;
  hi=mid-1;tail=&tl1;cid[recd]=1;
  goto start;
  //n=_mst_(n,noff,ptsize,&tl1,lo,mid-1,cf);
 ret1: n=retval;recd--;hi=hiarray[recd];n2=n2array[recd];mid=midarray[recd];
  loarray[recd]=lo; tl1array[recd]=tl1;narray[recd]=n;recd++;
  lo=mid;n=n2; tail=&tl2;cid[recd]=2;
  goto start;
  //n2=_mst_(n2,noff,ptsize,&tl2,mid,hi,cf);
 ret2:n2=retval;
  recd--;
  lo=loarray[recd];mid=midarray[recd];tl1=tl1array[recd];
  n=narray[recd];
  tail=tailarray[recd];
  i=lo,j=mid;
  if(!cf(n,n2)) head=n;
  else head=n2;
  if(cf(tl1,tl2)) *tail=tl1;
  else *tail=tl2;
  if(head==n) goto l; else goto r;
 l:p=n;if(i<mid-1)n=*((void**)(n+noff));i++;
  while ( i<mid &&  !cf(n,n2)){p=n;if(i<mid-1)n=*((void**)(n+noff));i++;}
  *((void**)(p+noff))=n2;
  if(i==mid)
    goto e;
 r: p=n2;if(j<hi)n2=*((void**)(n2+noff));j++;
  while ( j<hi+1 &&  cf(n,n2)){p=n2;if(j<hi)n2=*((void**)(n2+noff));j++;}
  if(i==mid-1){*((void**)(p+noff))=n;if(j==hi+1)goto e; *((void**)(n+noff))=n2;goto e;} 
  *((void**)(p+noff))=n;
  if(j==hi+1)goto e;
  goto l;
  //return head;
 e: if(recd>0){retval=head;if(cid[recd]==1)goto ret1;else goto ret2;}
  else
    return head;
}
void * mst(void *head,size_t noffset, size_t sz,int (*cf)(void *a,void *b),void** tmpbuf,size_t ub)
{
  void *tail=NULL; register size_t i;
  if (sz==0)return NULL;
  head=_mst_(head,noffset,(void**)&tail,0,sz-1,cf,(void**)tmpbuf,ub);
  *((void**)((tail)+noffset))=0;
  for(i=0;i<ub;i++)tmpbuf[i]=0;
  return head;
}
static void* _ms_(void* n, size_t noff,size_t poff,  void** tail,size_t lo,size_t hi,int (*cf)(void *a,void *b),void** tmpbuf,size_t ub)
{
  register void* n2,*p,*head;
  void* tl1,*tl2;
  register size_t recd=0, i,j,mid;
  void* narray[MAXDEPTH],*tl1array[MAXDEPTH],*n2array[MAXDEPTH],**tailarray[MAXDEPTH], *retval;
  size_t  loarray[MAXDEPTH],hiarray[MAXDEPTH],midarray[MAXDEPTH];
  short cid[MAXDEPTH];
 start:mid=lo+(hi-lo+1)/2; 
  if(lo==hi){*tail=n;
    if(recd>0){retval=n;if(cid[recd]==1)goto ret1;else goto ret2;}
    else
      return n;
  }
  i=lo;n2=n;
  if(mid<ub && tmpbuf[mid]!=0){
    n2=tmpbuf[mid];
  }
  else
    {
      while(i<mid){
        if(i<ub)tmpbuf[i]=n2;
        n2=*((void**)(n2+noff));
        i++;
      }
    }
  n2array[recd]=n2;hiarray[recd]=hi;tailarray[recd]=tail;midarray[recd]=mid;
  recd++;
  hi=mid-1;tail=&tl1;cid[recd]=1;
  goto start;
 ret1: n=retval;recd--;hi=hiarray[recd];n2=n2array[recd];mid=midarray[recd];
  loarray[recd]=lo; tl1array[recd]=tl1;narray[recd]=n;recd++;
  lo=mid;n=n2; tail=&tl2;cid[recd]=2;
  goto start;
 ret2:n2=retval;
  recd--;
  lo=loarray[recd];mid=midarray[recd];tl1=tl1array[recd];
  n=narray[recd];
  tail=tailarray[recd];
  i=lo,j=mid;
  if(!cf(n,n2)) head=n;
  else head=n2;
  if(cf(tl1,tl2)) *tail=tl1;
  else *tail=tl2;
  if(head==n)goto l; else goto r;
 l:p=n;if(i<mid-1)n=*((void**)(n+noff));i++;
  while ( i<mid &&  !cf(n,n2)){p=n;if(i<mid-1)n=*((void**)(n+noff));i++;}
  *((void**)(p+noff))=n2;
  *((void**)(n2+poff))=p;
  if(i==mid)
    goto e;
 r:p=n2;if(j<hi)n2=*((void**)(n2+noff));j++;
  while ( j<hi+1 &&  cf(n,n2)){p=n2;if(j<hi)n2=*((void**)(n2+noff));j++;}
  if(i==mid-1){
    *((void**)(p+noff))=n;
    *((void**)(n+poff))=p;
    if(j==hi+1)goto e;
    *((void**)(n+noff))=n2;
    *((void**)(n2+poff))=n;  
    goto e;}      
  *((void**)(p+noff))=n;
  *((void**)(n+poff))=p;
  if(j==hi+1)goto e;
  goto l;
 e:if(recd>0){retval=head;if(cid[recd]==1)goto ret1;else goto ret2;}
  else
    return head;
}
void * ms(void *head,size_t noffset, size_t poffset,void ** tail,size_t sz,int (*cf)(void *a,void *b),void **tmpbuf,size_t ub)
{
  register size_t i;
  if (sz==0)return NULL; 
  head=_ms_(head,noffset,poffset,(void**)tail,0,sz-1,cf,(void**)tmpbuf,ub);
  *((void**)((*tail)+noffset))=0;
  *((void**)(head+poffset))=0;
  for(i=0;i<ub;i++)tmpbuf[i]=0;
  return head;
}
static void* _msbse_(void* n, size_t noff,size_t poff, void** tail,size_t lo,size_t hi,int (*cf)(void *a,void *b),void** ptarr,void** tmpbuf, size_t ub, void* *res,void* key)
{
  void* tl1,*tl2;
  register void* n2,*p,*head;
  register size_t recd=0, i,j,mid,processed=0;
  void* narray[MAXDEPTH],*tl1array[MAXDEPTH],*n2array[MAXDEPTH],**tailarray[MAXDEPTH], *retval;
  size_t  loarray[MAXDEPTH],hiarray[MAXDEPTH],midarray[MAXDEPTH];
  short cid[MAXDEPTH];
 start:mid=lo+(hi-lo+1)/2; 
  if(lo==hi){*tail=n;
    if(recd>0){retval=n;if(cid[recd]==1)goto ret1;else goto ret2;}
    else
      {ptarr[0]=n;
	if(*res==0 && !cf(key,ptarr[0]) && !cf(ptarr[0],key))
	  *res=ptarr[0];
	return n;}
  }
  i=lo;n2=n;
  if(mid<ub && tmpbuf[mid]!=0){
    n2=tmpbuf[mid];
  }
  else
    {
      while(i<mid){
        if(i<ub)tmpbuf[i]=n2;
        n2=*((void**)(n2+noff));
        i++;
      }
    }
  n2array[recd]=n2;hiarray[recd]=hi;tailarray[recd]=tail;midarray[recd]=mid;
  recd++;
  hi=mid-1;tail=&tl1;cid[recd]=1;
  goto start;
 ret1: n=retval;recd--;hi=hiarray[recd];n2=n2array[recd];mid=midarray[recd];
  loarray[recd]=lo; tl1array[recd]=tl1;narray[recd]=n;recd++;
  lo=mid;n=n2; tail=&tl2;cid[recd]=2;
  goto start;
 ret2:n2=retval;
  recd--;
  lo=loarray[recd];mid=midarray[recd];tl1=tl1array[recd];
  n=narray[recd];
  tail=tailarray[recd];
  i=lo,j=mid;
  if(!cf(n,n2)) head=n;
  else head=n2;
  if(cf(tl1,tl2)) *tail=tl1;
  else *tail=tl2;
  if(head==n)goto l; else goto r;
 l:p=n;
  if(i<mid-1){ if(recd==0){  ptarr[processed++]=n;
      if(*res==0 && !cf(key,ptarr[processed-1]) && !cf(ptarr[processed-1],key))
	*res=ptarr[processed-1];
    }
    n=*((void**)(n+noff));
  }
  i++;
  while ( i<mid &&  !cf(n,n2)){
    p=n;
    if(i<mid-1){
      if(recd==0){
	ptarr[processed++]=n;
	if(*res==0 && !cf(key,ptarr[processed-1]) && !cf(ptarr[processed-1],key))
	  *res=ptarr[processed-1];
      }
      n=*((void**)(n+noff));
    }
    i++;
  }
  *((void**)(p+noff))=n2;
  *((void**)(n2+poff))=p;
  if(i==mid)
    {
      if(recd==0){
	ptarr[processed++]=n;
	if(*res==0 && !cf(key,ptarr[processed-1]) && !cf(ptarr[processed-1],key))
	  *res=ptarr[processed-1];
	while(processed<hi+1){
	  ptarr[processed++]=n2;
	  if(*res==0 && !cf(key,ptarr[processed-1]) && !cf(ptarr[processed-1],key))
	    *res=ptarr[processed-1];
	  n2=*((void**)(n2+noff));
	}
      }  
      goto e;
    }
 r: p=n2; 
  if(j<hi){ if(recd==0){ptarr[processed++]=n2;
      if(*res==0 && !cf(key,ptarr[processed-1]) && !cf(ptarr[processed-1],key))
	*res=ptarr[processed-1];
    }
    n2=*((void**)(n2+noff));
  }
  j++;
  while ( j<hi+1 &&  cf(n,n2)){p=n2;
    if(j<hi){
      if(recd==0){
	ptarr[processed++]=n2;
	if(*res==0 && !cf(key,ptarr[processed-1]) && !cf(ptarr[processed-1],key))
	  *res=ptarr[processed-1];
      }
      n2=*((void**)(n2+noff));
    }
    j++;
  }
  if(i==mid-1){
    *((void**)(p+noff))=n;
    *((void**)(n+poff))=p;
    if(j==hi+1){
      if(recd==0){
	ptarr[processed++]=n2;
	if(*res==0 && !cf(key,ptarr[processed-1]) && !cf(ptarr[processed-1],key))
	  *res=ptarr[processed-1];
	while(processed<hi+1){
	  ptarr[processed++]=n;
	  if(*res==0 && !cf(key,ptarr[processed-1]) && !cf(ptarr[processed-1],key))
	    *res=ptarr[processed-1];
	  n=*((void**)(n+noff));
	}
      }
      goto e;  
    }
    *((void**)(n+noff))=n2;
    *((void**)(n2+poff))=n; 
    if(recd==0){
      ptarr[processed++]=n;
      if(*res==0 && !cf(key,ptarr[processed-1]) && !cf(ptarr[processed-1],key))
	*res=ptarr[processed-1];
      while(processed<hi+1){
	ptarr[processed++]=n2;
	if(*res==0 && !cf(key,ptarr[processed-1]) && !cf(ptarr[processed-1],key))
	  *res=ptarr[processed-1];
	n2=*((void**)(n2+noff));
      }
    }
    goto e;
  }
  *((void**)(p+noff))=n;
  *((void**)(n+poff))=p;
  if(j==hi+1){
    if(recd==0){
      ptarr[processed++]=n2;
      if(*res==0 && !cf(key,ptarr[processed-1]) && !cf(ptarr[processed-1],key))
	*res=ptarr[processed-1];
      while(processed<hi+1){
	ptarr[processed++]=n;
	if(*res==0 && !cf(key,ptarr[processed-1]) && !cf(ptarr[processed-1],key))
	  *res=ptarr[processed-1];
	n=*((void**)(n+noff));
      }
    }
    goto e;  
  }
  goto l;
 e:if(recd>0){retval=head;if(cid[recd]==1)goto ret1;else goto ret2;}
  else
    return head;
}
void * msbse(void *head,size_t noffset, size_t poffset,size_t sz,int (*cf)(void *a,void *b),void** tmpbuf,size_t tmpbufsize,void * ptarr[],void *key)
{
  void *tail=NULL,*res=NULL; register size_t i;
  if (sz==0)return NULL;
  head=_msbse_(head,noffset,poffset,(void**)&tail,0,sz-1,cf,(void**)ptarr,(void**)tmpbuf,tmpbufsize,(void**)&res,(void*)key);
  *((void**)((tail)+noffset))=0;
  *((void**)(head+poffset))=0;
  for(i=0;i<tmpbufsize;i++)tmpbuf[i]=0;
  return res;
}
static void _bse_(void *ptarr[],void *key, size_t lo,size_t hi,void **res,int (*cf)(void *a,void *b))
{
  register size_t mid;
  while(lo<hi){
    mid=lo+(hi-lo)/2;
    if (cf(ptarr[mid],key))
      {if(lo<mid)hi=mid-1;else return;}
    else if (cf(key,ptarr[mid]))
      lo=mid+1;
    else
      {*res=ptarr[mid];return;}
  }
  if (!(cf(ptarr[lo],key)||cf(key,ptarr[lo]))){*res=ptarr[lo];return;}
}
void bse(void *ptarr[],void *key,size_t sz,void **res,int (*cf)(void *a,void *b))
{
  if(sz==0) *res=NULL;
  else{
    size_t  lo=0,hi=sz-1;
    _bse_(ptarr,key,lo,hi,res,cf);
  }
}
