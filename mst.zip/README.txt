A stable and fast implementation (O(n*lg(n)) runtime) of merge sort, without recursion, 
supporting double and single linked list.

Sorting is done by pointer manipulations only without any data movement.

In case of double linked list, both sorted and reverse sorted lists are obtained at once.

The merging happens in situ. For faster access, we use contiguous temporary buffer. 
Ideally, size of this buffer should be = number of elements * size of a void pointer. 
Otherwise, we use whatever temporary space can be allotted contiguously.


mst.c - The library implementing the sort. 
"ms" sorts double link and "mst" sorts single linked list.  
msttest.c - Testbench.

Unsorted data need to be presented in single linked list format from left to right.
In case of double linked list, previous pointers (from right to left) are organized automatically.


To compile, type "make".
To execute, type "./msttest <number of elements in test1> <number of elements in test2> <number of elements in test3>".

The arguments to the function "ms" are : 
a) Head of the unsorted list. 
b) In the node structure, the offset (in bytes) of next pointer. 
c) In the node structure, the offset (in bytes) of previous pointer. 
d) A double pointer to tail. After sorting, the reverse list is accessible via tail. 
e) Number of elements. 
f) Pointer to comparison function. This function should return 0 if first node is less than or equal
to the second node. Else 1 is returned.
g) Pointer to the temporary buffer.
h) Size of the temp buffer.

Arguments to "mst" are similar.

Also, contains:
 "msbse" - For doing combined sorting and searching of a specific key directly from the unsorted list. 
Also builds the pointer array required for subsequent binary search.  
"ptarr" argument is the reference to the pointer array which will be filled by this routine. "key" is the 
pointer to the structure which we are searching in the list. 
Returns the pointer to the list element matching the key.
In case of duplicate keys, only the first one in the stable order will be returned. 
Other duplicate keys can be found by following the next pointer from the returned pointer.

"bse" - For doing binary search using the pointer array built by "msbse". If exists, sets the result pointer 
to the record matching the key.
