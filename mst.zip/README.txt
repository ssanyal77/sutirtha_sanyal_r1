A stable and fast implementation (O(n*lg(n)) runtime) of merge sort, without recursion, 
supporting double and single linked list.

Sorting is done by pointer manipulations only without any data movement.

In case of double linked list, both sorted and reverse sorted lists are obtained at once.

The merging happens in situ. For faster access, we use contiguous temporary buffer. 
Ideally, size of this buffer should be = number of elements * size of a void pointer. 
Otherwise, we use whatever temporary space can be allotted contiguously.


mst.c - The library implementing the sort. 
"ms" sorts double link and "mst" sorts single linked list.  
msttest.c - Testbench.

Unsorted data need to be presented in single linked list format from left to right.
In case of double linked list, previous pointers (from right to left) are organized automatically.


To compile, type "make".
To execute, type
"./msttest <number of elements in test1> <number of elements in test2> <number of elements in test3> <number of elements in test4>".

The arguments to the function "ms" are : 
a) Head of the unsorted list. 
b) In the element structure, the offset (in bytes) of next pointer. 
c) In the element structure, the offset (in bytes) of previous pointer. 
d) A double pointer to tail. After sorting, the reverse list is accessible via tail. 
e) Number of elements. 
f) Pointer to comparison function f. This function should return 0 if first element is less than or equal
to the second element, else 1 is returned. This function must be transitive, i.e., for any three elements e1, e2 and e3,
f(e1,e2)=f(e2,e3)=>f(e1,e3)=f(e1,e2).
g) Pointer to the temporary buffer.
h) Size of the temporary buffer.
i) Pointer to fixed data. During comparison, apart from the two elements being compared, a set of fixed data
is needed sometimes for comparison. User provides pointer to the fixed data which is passed on to the comparison
function f.

Arguments to "mst" are similar. In case of single linked list, the next pointer of the last element may not be set to 0.
Hence that should not be checked or used.

Also, contains:
 "msbse" - For doing combined sorting and searching of a specific key directly from the unsorted list. 
Also builds the pointer array required for subsequent binary search.  
"ptarr" argument is the reference to the pointer array which will be filled by this routine. "key" is the 
pointer to the structure which we are searching in the list. 
Returns the index to the list element matching the key.
In case of duplicate keys, only the index of the last one in the stable order will be returned.
Other duplicate keys can be found by following the previous pointer from the returned element.

"bse" - For doing binary search using the pointer array built by "msbse". If exists, sets the result to the index of the
entry matching the key. The indicator variable "dn", which is an argument to this function, is set to 0.
If the key doesn't exist, result will be the index of the element present in the list which is immediately above the key.
dn is set to 1.
If the key doesn't exist, and its value is greater than the greatest element of the list, result will be the index of the
greatest element of the list.
dn is set to -1.

The 2nd test generates the worst case scenario. 
A "free run" occurs when two or more elements are already in the sorted order in one half of the entire list being sorted
and there are no elements in between them from the other half of the list. This reduces the runtime of the sort.
This test permutes the original sorted list in a way that during the subsequent sort to restore the original list, there will be no 
free run at any step in any level. In other words, the loops in the lines 118 and 124 in mst.c, never go beyond one element in 
this case.

The library is thread safe. The 3rd test spawns "numthreads" number of threads to parallelly sort numthreads number of fields from
the list. numthreads/2 number of fields are integers and rest are strings. Number of threads should be less than or equal to the number
of physical cores available for parallel execution. Otherwise slowdown will be observed. 

The fourth test shows how we can use the library to fast detect all duplicates in the list. Here we are only concerned with the 
finding and grouping of all duplicates. 
The speedup comes from maintaining a "same" pointer at each element and set and use it in the way as shown in the line numbers 134-138 and 147, 
in msttest.c. This ensures that if there are d number of duplicates of an element, we find them all by doing exactly d-1 comparisons in 
all cases. 

The exact amount of speedup depends on how duplicates were spread out in the original list and the run time overhead of the comparison function. 
On the other hand, if the list doesn't contain any duplicate, this wouldn't lead to any perceptible slowdown. Only the first condition of the line 134
in msttest.c will be checked. 
Hence this technique can be used anywhere for potential speed up. This uses the stable property of the sort.
