//Author - Sutirtha Sanyal
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <string.h>
#include <pthread.h>
#include <time.h>
#include <math.h>
#include "ms.h"
#define chk 1000000
typedef struct tag1{
  //Preferred way of declaring linked list where next and previous pointers are declared first.
  struct tag1* next;
  struct tag1* prev;
  struct tag1* same;
  int val1;
  int index;
  unsigned char name[4];
}ele1;
typedef struct tag2{
  struct tag2* next;
  struct tag2* prev;
  int val1;
}ele2;
typedef struct tag4a{
  struct tag4a *next;
  char * str;
}string;
typedef struct tag4{
  struct tag4* next;
  struct tag4 * same;
  string * strs;
  int index;
}ele4;
typedef struct tag5{
  size_t noff;
  size_t poff;
  size_t numele;
  int thnum;
  int numthreads;
  void * nlist;
  void ** head;
  void ** tail;
  void ** tmpbuf;
}argtothread;
typedef struct tag6{
  int numthreads;
  int indnum;
}argtocomp;
typedef struct tag6a{
  int numfields;
  int indnum;
}argtocompdup;
typedef struct tag7{
  struct tag7* next;
  struct tag7* prev;
  struct tag7* same;
  struct tag4* headp;
  int count;
}duplicates;
void randstr(unsigned char x[],int size)
{
  int i;
  *(x)=rand()%26+65; 
  for (i=1;i<size-1;i++)
    {
      *(x+i)=rand()%26+97;
    }
  *(x+size-1)=0;
}
void randstr2(char x[],int size)
{
  int i;
  for (i=0;i<size-1;i++)
    {
      *(x+i)=rand()%2+97;
    }
  *(x+size-1)=0;
}
int cfstrs(void *a,void *b,void *arg)
{
  int numthreads=((argtocomp*)arg)->numthreads;
  int indnum=((argtocomp*)arg)->indnum;
  return strcmp((char *)(a+2*numthreads*sizeof(void*)+(numthreads/2)*sizeof(int)+indnum*sizeof(int)),(char *)(b+2*numthreads*sizeof(void*)+(numthreads/2)*sizeof(int)+indnum*sizeof(int)))<=0?0:1;
}
int cfints(void *a,void *b,void *arg)
{
  int numthreads=((argtocomp*)arg)->numthreads;
  int indnum=((argtocomp*)arg)->indnum;
  int z1=*((int*)(a+2*numthreads*sizeof(void*)+indnum*sizeof(int)));
  int z2=*((int*)(b+2*numthreads*sizeof(void*)+indnum*sizeof(int)));
  if(z1<=z2)return 0;
  return 1;
}
int cf1(void *a,void *b,void *arg)
{
  if(((ele1 *)a)->same!=0&&((ele1 *)b)->same!=0&&((ele1 *)a)->same==((ele1 *)b)->same)
    {
      ((ele1 *)b)->same=a;
      return 0;
    }
  int r=strcmp((char *)(((ele1 *)a)->name),(char *)(((ele1 *)b)->name));
  if (r==0)((ele1 *)b)->same=a;
  return r<=0?0:1;
}
int cf11(void *a,void *b,void *arg)
{
  if(((ele1 *)a)->index<=((ele1 *)b)->index)
    return 0;
  return 1;
}
int cf1s(void *a,void *b,void *arg)
{
  if(((ele1 *)a)->val1<=((ele1 *)b)->val1)
    return 0;
  return 1;
}
int cf2(void *a,void *b,void *arg)
{
  if(((ele2 *)a)->val1<=((ele2 *)b)->val1)
    return 0;
  return 1;
}
int cfs(void *a,void *b,void *arg)
{
  return strcmp(((string*)a)->str,((string*)b)->str)<=0?0:1;
}
int cf4(void *a,void *b,void *arg)
{
  int numfields,r;string *s1=((ele4 *)a)->strs,*s2=((ele4 *)b)->strs;
  if(((ele4 *)a)->same!=0&&((ele4 *)b)->same!=0&&((ele4 *)a)->same==((ele4 *)b)->same)
    {
      ((ele4 *)b)->same=a;
      return 0;
    }
  numfields=*((int*)arg);
  for(int u=0;u<numfields;u++)
    {
      r=strcmp( s1->str,s2->str);
      if(r<0)return 0;
      else if(r>0)return 1;
      s1=s1->next;s2=s2->next;
    }
  ((ele4 *)b)->same=a;
  return 0;
}
int cfd(void *a,void *b,void *arg)
{
  if( ((duplicates*)a)->count>=((duplicates*)b)->count)
    return 0;
  return 1;
}
int cfw(void *a,void *b,void *arg)//Generates worst case w.r.t. cf2.
{
  size_t start=2,end=*((size_t*)arg);
  while (start<=end){
    if(((ele2 *)a)->val1%start<((ele2 *)b)->val1%start)
      return 1;
    else  if(((ele2 *)a)->val1%start>((ele2 *)b)->val1%start)
      return 0;
    else 
      start*=2;
  }
  return 0;
}
void print1(ele1 *n)
{
  for(;n!=NULL;n=n->next)
    printf("Val1 %d Index %d Name %s; ",n->val1,n->index,n->name);
}
void print2(ele2 *n)
{
  for(;n!=NULL;n=n->next)
    printf("Val1 %d ",n->val1);
}
void check1(ele1 *n[],int (*cf)(void* a,void* b,void *arg),void *arg,size_t nm1)
{
  size_t i=0;
  for (i=1;i<nm1;i++) {
    if (cf(n[i-1],n[i],arg)||(!cf(n[i],n[i-1],arg)&&(n[i-1]->index>n[i]->index))) printf("\nCheck Failed\n");
    if (n[i-1]->next!=n[i]) printf("\nCheck Failed\n");
    if (n[i]->prev!=n[i-1]) printf("\nCheck Failed\n");
  }
  if (n[0]->prev!=NULL) printf("\nCheck Failed\n");
  if (n[nm1-1]->next!=NULL) printf("\nCheck Failed\n");
}
void check1n(ele1 *n,ele1* tail,int (*cf)(void* a,void* b,void *arg),void *arg,size_t nm1)
{
  size_t i=0;
  if (n==NULL) return;
  for(;n->next!=NULL;i++,n=n->next)
    if(cf(n,n->next,arg))printf("Check Failed\n");
  if(i!=nm1-1)printf("Check Failed\n");
  if(tail!=NULL){if(n!=tail)printf("Check Failed\n");
    for(;tail->prev!=NULL;i--,tail=tail->prev)
      if(tail->prev->next!=tail)printf("Check Failed\n");
    if(i!=0)printf("Check Failed\n");
  }}
void check1s(ele1 *n,int (*cf)(void* a,void* b,void* arg),void *arg,size_t nm1)
{
  size_t i=0;
  if (n==NULL) return;
  for(;i<nm1-1;i++,n=n->next)
    if(cf(n,n->next,arg)||(!cf(n->next,n,arg)&&(n->index>n->next->index)))printf("Check Failed\n");
}
void check2(ele2 *n,ele2* tail,int (*cf)(void* a,void* b,void* arg),void *arg,size_t nm2)
{
  size_t i=0;
  if (n==NULL) return;
  for(;n->next!=NULL;i++,n=n->next)
    if(cf(n,n->next,arg))printf("Check Failed\n");
  if(i!=nm2-1)printf("Check Failed\n");
  if(tail!=NULL){if(n!=tail)printf("Check Failed\n");
    for(;tail->prev!=NULL;i--,tail=tail->prev)
      if(tail->prev->next!=tail)printf("Check Failed\n");
    if(i!=0)printf("Check Failed\n");}
}
void printa1(ele1 *n[],size_t sz)
{
  size_t i;
  for(i=0;i<sz;i++)
    printf("Val1 %d Index %d Name %s; ",n[i]->val1,n[i]->index,n[i]->name);
}
void printblank()
{
  int i;
  for (i=0;i<25;i++)
    {
      printf("\b");
    }
}
void printline(int x)
{
  int i;
  unsigned char ch='\%';
  printf("[");
  for (i=0;i<20;i++)
    {
      if (i<x/5)
	{
	  printf(".");
	  continue;
	}
      printf(" ");
    }
  printf("]");
  printf("%d",x);
  printf("%c",ch);
}
void start_display(void)
{
  short i;
  char ch='\%';
  printf("[");
  for (i=0;i<20;i++)
    {
      printf(" ");
    }
  printf("]");
  printf("0%c",ch);
}
void showprogress(int x)
{
  static int prev=0;
  char ch='\%';
  int y=x/5;
  if (y>prev)
    {
      prev=(y<20)?y:0;
      printblank();
      printline(x);
      fflush(stdout);
    }
  else
    {
      if(x<10)
	{
	  printf("\b\b");
	  printf("%d%c",x,ch);
	  fflush(stdout);
	}
      else
	{
	  printf("\b\b\b");
	  printf("%d%c",x,ch);
	  fflush(stdout);
	}
    }
}
void tst1(size_t nm1)
{
  ele1 * n,*tail=NULL,**ptarr;
  size_t i,r=-1;//r=-1 means r=2^(8*sizeof(size_t))-1
  int k,cnt=0,d=0;ele1* nlist=NULL;
  ele1** fr=malloc((nm1%chk!=0?nm1/chk+1:nm1/chk)*sizeof(ele1*));
  void **tmpbuf;
  start_display();
  for(i=0;i<nm1;i+=chk)
    {
      if (nlist==NULL)
	{
	  nlist=(ele1*)malloc(((nm1>=chk)?chk:nm1)*sizeof(ele1));
	  fr[cnt++]=nlist;
	  n=nlist;
	  for (k=0;k<(nm1>=chk?chk:nm1);k++){
	    n->index=k;
	    n->same=0;
	    randstr(n->name,4);
	    n->val1=rand()%nm1;
	    n->next=(k==((nm1>=chk)?chk-1:(nm1-1)))?NULL:n+1;
	    n=(k<((nm1>=chk)?chk-1:(nm1-1)))?n->next:n;
	  }
	}
      else{
	n->next=(ele1*)malloc((((nm1-i)>=chk)?chk:(nm1-i))*sizeof(ele1));
	fr[cnt++]=n->next;
	n=n->next;
	for (k=0;k<((nm1-i)>=chk?chk:(nm1-i));k++){
	  n->index=i+k;
	  n->same=0;
	  n->val1=rand()%nm1;
	  randstr(n->name,4);
	  n->next=(k==(((nm1-i)>=chk)?chk-1:(nm1-i-1)))?NULL:n+1;
	  n=(k<(((nm1-i)>=chk)?chk-1:(nm1-i-1)))?n->next:n;
	}
      }
      if((nm1-i)>=chk)showprogress(((long long)i+chk)*100/nm1);
      else showprogress(100);
    }
  printf("\nDone building unsorted list.\n");
  printf("\nUnsorted List\n");
  //print1(nlist);
  tmpbuf=malloc((nm1)*sizeof(void*));
  ptarr=malloc((nm1)*sizeof(ele1*));
  struct timespec s,e;
  clock_gettime(CLOCK_REALTIME,&s);
  nlist=(ele1 *)mst((void *)nlist,0,nm1,cf1,tmpbuf,nm1,0);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nSorting took %lu second(s) and %lu nanosecond(s).",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nSorting took %lu second(s) and %lu nanosecond(s).",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  printf("\n\nSorted List\n");
  //print1(nlist);
  check1s(nlist,cf1,0,nm1);
  ele1 *key=malloc(sizeof(ele1));
  key->index=17;
  clock_gettime(CLOCK_REALTIME,&s);
  r=msbse((void *)nlist,0,sizeof(ele1*),nm1,cf11,tmpbuf,nm1,(void**)ptarr,(void*)key,0);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nSorting and searching took %lu second(s) and %lu nanosecond(s).\n",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nSorting and searching took %lu second(s) and %lu nanosecond(s).\n",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  printf("\n\nSorted List\n");
  //printa1(ptarr,nm1);
  check1(ptarr,cf11,0,nm1);
  printf("\nSearched Element\n");
  if(r!=-1)printf("%d %d\n",ptarr[r]->val1,ptarr[r]->index);else printf("Key not found");
  key->index=-1;r=-1;
  clock_gettime(CLOCK_REALTIME,&s);
  bse((void**)ptarr,(void*)key,nm1,(size_t *)&r,&d,cf11,0);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nSearching took %lu second(s) and %lu nanosecond(s).",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nSearching took %lu second(s) and %lu nanosecond(s).",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  if(r!=-1){if(d==0)printf("\nSearched element %d  at index %lu.\n",ptarr[r]->index,r);
    else if(d==1) {if (r!=0)printf("\nSearched element not in the list.\nKey immediately above it is %d at index %lu.\nKey immediately below it is %d at index %lu\n",ptarr[r]->index,r,ptarr[r-1]->index,r-1);
      else printf("\nSearched element not in the list.\nKey immediately above it is %d at index %lu.\n",ptarr[r]->index,r);
    }
    else printf("\nSearched element not in the list.\nKey immediately below it is %d at index %lu.\n",ptarr[r]->index,r);
  }
  key->val1=ptarr[rand()%nm1]->val1;r=-1;
  r=msbse(ptarr[0],0,sizeof(ele2*),nm1,cf1s,tmpbuf,nm1,(void**)ptarr,(void*)key,0);
  //printa1(ptarr,nm1);
  check1(ptarr,cf1s,0,nm1);
  r=-1;d=0;
  key->val1=ptarr[rand()%nm1]->val1;
  clock_gettime(CLOCK_REALTIME,&s);
  bse((void**)ptarr,(void*)key,nm1,(size_t *)&r,&d,cf1s,0);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nSearching took %lu second(s) and %lu nanosecond(s).",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nSearching took %lu second(s) and %lu nanosecond(s).",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  if(r!=-1){if(d==0)printf("\nSearched element %d at index %lu.\n",ptarr[r]->val1,r);
    else if(d==1){if(r!=0)printf("\nSearched element not in the list.\nKey immediately above it is %d at index %lu.\nKey immediately below it is %d at index %lu\n",ptarr[r]->val1,r,ptarr[r-1]->val1,r-1);
      else printf("\nSearched element not in the list.\nKey immediately above it is %d at index %lu.\n",ptarr[r]->val1,r);
    }
    else printf("\nSearched element not in the list.\nKey immediately below it is %d at index %lu.\n",ptarr[r]->val1,r);
  }
  r=-1;d=0;
  key->val1=rand()%nm1;
  clock_gettime(CLOCK_REALTIME,&s);
  bse((void**)ptarr,(void*)key,nm1,(size_t *)&r,&d,cf1s,0);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nSearching took %lu second(s) and %lu nanosecond(s).",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nSearching took %lu second(s) and %lu nanosecond(s).",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  if(r!=-1){if(d==0)printf("\nSearched element %d at index %lu.\n",ptarr[r]->val1,r);
    else if(d==1) {if(r!=0)printf("\nSearched element not in the list.\nKey immediately above it is %d at index %lu.\nKey immediately below it is %d at index %lu\n",ptarr[r]->val1,r,ptarr[r-1]->val1,r-1);
      else printf("\nSearched element not in the list.\nKey immediately above it is %d at index %lu.\n",ptarr[r]->val1,r);
    }
    else printf("\nSearched element not in the list.\nKey immediately below it is %d at index %lu.\n",ptarr[r]->val1,r);
  }
  free(key);
  nlist=(ele1 *)ms(ptarr[0],0,sizeof(ele2*),(void**)&tail,nm1,cf1,tmpbuf,nm1,0);
  //print1(nlist);
  check1n(nlist,tail,cf1,0,nm1);
  free(ptarr);
  free(tmpbuf);
  for(k=0;k<cnt;k++)free(fr[k]);
  free(fr);
  printf("\n**********\n");
}
void tst2(void *arg,size_t nm2)
{
  ele2 * n;
  size_t i;
  int k,cnt=0;ele2* nlist=NULL;
  ele2 ** fr=malloc((nm2%chk!=0?nm2/chk+1:nm2/chk)*sizeof(ele2*));
  struct timespec s,e;
  start_display();
  void* tail=NULL;
  void** tmpbuf=malloc((nm2)*sizeof(void*));
  for(i=0;i<nm2;i+=chk)
    {
      if (nlist==NULL)
	{
	  nlist=(ele2*)malloc(((nm2>=chk)?chk:nm2)*sizeof(ele2));
	  fr[cnt++]=nlist;
	  n=nlist;
	  for (k=0;k<(nm2>=chk?chk:nm2);k++){
	    n->val1=k;
	    n->next=(k==((nm2>=chk)?chk-1:(nm2-1)))?NULL:n+1;
	    n=(k<((nm2>=chk)?chk-1:(nm2-1)))?n->next:n;
	  }
	}
      else{
	n->next=(ele2*)malloc((((nm2-i)>=chk)?chk:(nm2-i))*sizeof(ele2));
	fr[cnt++]=n->next;
	n->next->prev=n;
	n=n->next;
	for (k=0;k<((nm2-i)>=chk?chk:(nm2-i));k++){
	  n->val1=(i+k);
	  n->next=(k==(((nm2-i)>=chk)?chk-1:(nm2-i-1)))?NULL:n+1;
	  n=(k<(((nm2-i)>=chk)?chk-1:(nm2-i-1)))?n->next:n;
	}
      }
      if((nm2-i)>=chk)showprogress(((long long)i+chk)*100/nm2);
      else showprogress(100);
    }
  printf("\nDone building list.\n");
  clock_gettime(CLOCK_REALTIME,&s);
  nlist=(ele2 *)ms((void *)nlist,0,sizeof(ele2*),&tail,nm2,cfw,tmpbuf,nm2,arg);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nGenerated worst case in %lu second(s) and %lu nanosecond(s).\n",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nGenerated worst case in %lu second(s) and %lu nanosecond(s).\n",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  //print2(nlist);
  check2(nlist,tail,cfw,arg,nm2);
  clock_gettime(CLOCK_REALTIME,&s);
  nlist=(ele2 *)ms((void *)nlist,0,sizeof(ele2*),&tail,nm2,cf2,tmpbuf,nm2,0);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nSorting from worst case took %lu second(s) and %lu nanosecond(s).",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nSorting from worst case took %lu second(s) and %lu nanosecond(s).",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  //print2(nlist);
  check2(nlist,tail,cf2,0,nm2);
  free(tmpbuf);
  for(k=0;k<cnt;k++)free(fr[k]);
  free(fr);
  printf("\n**********\n");
}
void *thfn(void * arg)
{
  size_t numele=((argtothread*)arg)->numele;
  void* nlist=((argtothread*)arg)->nlist;
  size_t noff=((argtothread*)arg)->noff;
  size_t poff=((argtothread*)arg)->poff;
  int thnum=((argtothread*)arg)->thnum;
  int numthreads=((argtothread*)arg)->numthreads;
  int indnum=(thnum>=numthreads/2)?thnum-numthreads/2:thnum;
  void ** head=((argtothread*)arg)->head;
  void ** tail=((argtothread*)arg)->tail;
  void **tmpbuf=((argtothread*)arg)->tmpbuf;
  argtocomp argcmp;argcmp.numthreads=numthreads;argcmp.indnum=indnum;
  if(thnum<numthreads/2){
    (*(head))=(void *)ms((void *)nlist,noff,poff,(void**)tail,numele,cfints,tmpbuf,numele,(void*)&argcmp);
  }
  else{
    (*(head))=(void *)ms((void *)nlist,noff,poff,(void**)tail,numele,cfstrs,tmpbuf,numele,(void*)&argcmp);
  }
  pthread_exit(0);
}
void print3(int numthreads, void * nlist,size_t nm3,void ** heads)
{
  int k,ptrsz=2*numthreads*sizeof(void*);;size_t i;
  void * n;
  if(heads==0){
    for(k=0;k<numthreads;k++)
      {
	n=nlist;
	printf("Unsorted Field %d\n",k);
	if(k<numthreads/2){
	  for (i=0;i<nm3;i++){
	    printf("%d ",*((int*)(n+ptrsz+k*sizeof(int))));
	    n=*((void**)(n));
	  }
	  printf("\n");
	}
	else{
	  for (i=0;i<nm3;i++){
	    printf("%s ",((char *)(n+ptrsz+(numthreads/2)*sizeof(int)+(k-numthreads/2)*sizeof(int))));
	    n=*((void**)(n));
	  }
	  printf("\n");
	}
      }
  }
  else{
    for(k=0;k<numthreads;k++)
      {
	n=heads[k];
	printf("Sorted Field %d\n",k);
	if(k<numthreads/2){
	  for (i=0;i<nm3;i++){
	    printf("%d ",*((int*)(n+ptrsz+k*sizeof(int))));
	    n=*((void**)(n+k*sizeof(void*)));
	  }
	  printf("\n");
	}
	else{
	  for (i=0;i<nm3;i++){
	    printf("%s ",((char *)(n+ptrsz+(numthreads/2)*sizeof(int)+(k-numthreads/2)*sizeof(int))));
	    n=*((void**)(n+k*sizeof(void*)));
	  }
	  printf("\n");
	}
      }
  }
  printf("\n\n");
}
void tst3(size_t nm3,int numthreads)
{
  size_t i; int k,cnt=0;
  void* nlist=0,*n;
  void * heads[numthreads],*tails[numthreads];
  pthread_t ths[numthreads];
  argtothread args[numthreads];
  int ptrsz=2*numthreads*sizeof(void*);
  int elesize=ptrsz+(numthreads)*sizeof(int);
  void ** fr=malloc((nm3%chk!=0?nm3/chk+1:nm3/chk)*sizeof(void*));
  for(i=0;i<nm3;i+=chk)
    {
      if (nlist==NULL)
	{
	  nlist=(void*)malloc(((nm3>=chk)?chk:nm3)*elesize);
	  fr[cnt++]=nlist;
	  n=nlist;
	  for (k=0;k<(nm3>=chk?chk:nm3);k++){
	    for(int h=0;h<4*(numthreads/2);h+=4){*((int*)(n+ptrsz+h))=rand()%1000;
	      randstr(n+ptrsz+((numthreads/2)*sizeof(int))+h,4);}
	    for(int h=0;h<(numthreads)*sizeof(void*);h+=sizeof(void*)){
	      *((void**)(n+h))=(k==((nm3>=chk)?chk-1:(nm3-1)))?0:n+elesize;
	    }
	    n=(k<((nm3>=chk)?chk-1:(nm3-1)))?n+elesize:n;
	  }
	}
      else{
	*((void**)n)=(void*)malloc((((nm3-i)>=chk)?chk:(nm3-i))*elesize);
	fr[cnt++]=*((void**)n);
	for(int h=sizeof(void*);h<(numthreads)*sizeof(void*);h+=sizeof(void*))
	  *((void**)(n+h))=*((void**)n);
	n=*((void**)n);
	for (k=0;k<((nm3-i)>=chk?chk:(nm3-i));k++){
	  for(int h=0;h<4*(numthreads/2);h+=4){*((int*)(n+ptrsz+h))=rand()%1000;
	    randstr(n+ptrsz+((numthreads/2)*sizeof(int))+h,4);}
          for(int h=0;h<(numthreads)*sizeof(void*);h+=sizeof(void*)){
	    *((void**)(n+h))=(k==(((nm3-i)>=chk)?chk-1:(nm3-i-1)))?0:n+elesize;
          }
	  n=(k<(((nm3-i)>=chk)?chk-1:(nm3-i-1)))?n+elesize:n;
	}
      }
      if((nm3-i)>=chk)showprogress(((long long)i+chk)*100/nm3);
      else showprogress(100);
    }
  printf("\nDone building unsorted list.\n");
  //print3(numthreads,nlist,nm3,0);
  for(k=0;k<numthreads;k++)
    {
      args[k].noff=k*sizeof(void*);
      args[k].poff=numthreads*sizeof(void*)+k*sizeof(void*);
      args[k].numele=nm3;
      args[k].thnum=k;
      args[k].numthreads=numthreads;
      args[k].nlist=nlist;
      args[k].head=&(heads[k]);
      args[k].tail=&(tails[k]);
      args[k].tmpbuf=malloc(nm3*sizeof(void*));
    }
  struct timespec s,e;
  clock_gettime(CLOCK_REALTIME,&s);
  for(k=0;k<numthreads;k++)
    {
      pthread_create(&ths[k],0,thfn,(void*)(&args[k]));
    }
  for(k=0;k<numthreads;k++)
    {
      pthread_join(ths[k],0);
    }
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nSorted parallelly in %lu second(s) and %lu nanosecond(s).\n",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nSorted parallelly in %lu second(s) and %lu nanosecond(s).\n",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  //print3(numthreads,nlist,nm3,heads);
  argtocomp argcmp;
  argcmp.numthreads=numthreads;
  for(k=0;k<numthreads/2;k++)
    {
      n=heads[k];argcmp.indnum=k;
      if (*((void**)(n+numthreads*sizeof(void*)+k*sizeof(void*)))!=0)
	printf("Check Failed\n");
      for(i=0;i<nm3-1;i++){
	if(cfints(n,*((void**)(n+k*sizeof(void*))),(void*)&argcmp))
	  printf("Check Failed\n");
	if(*((void**)((*((void**)(n+k*sizeof(void*))))+numthreads*sizeof(void*)+k*sizeof(void*)))!=n)
	  printf("Check Failed\n");
	n=*((void**)(n+k*sizeof(void*)));
      }
      if(n!=tails[k])
	printf("Check Failed\n");
      if (*((void**)(tails[k]+k*sizeof(void*)))!=0)
	printf("Check Failed\n");
      free(args[k].tmpbuf);
    }
  for(k=numthreads/2;k<numthreads;k++)
    {
      n=heads[k];argcmp.indnum=k-numthreads/2;
      if (*((void**)(n+numthreads*sizeof(void*)+k*sizeof(void*)))!=0)
	printf("Check Failed\n");
      for(i=0;i<nm3-1;i++){
	if(cfstrs(n,*((void**)(n+k*sizeof(void*))),(void*)&argcmp))
	  printf("Check Failed\n");
	if(*((void**)((*((void**)(n+k*sizeof(void*))))+numthreads*sizeof(void*)+k*sizeof(void*)))!=n)
	  printf("Check Failed\n");
	n=*((void**)(n+k*sizeof(void*)));
      }
      if(n!=tails[k])
	printf("Check Failed\n");
      if (*((void**)(tails[k]+k*sizeof(void*)))!=0)
	printf("Check Failed\n");
      free(args[k].tmpbuf);
    }
  for(int u=0;u<cnt;u++)free(fr[u]);
  free(fr);
}
void genrecords(ele4 *n,int numfields)
{
  string *s;void** tmpbuf=0;
  n->strs=malloc(sizeof(string));
  s=n->strs;
  s->str=malloc(4);
  randstr2(s->str,4);
  for(int u=1;u<numfields;u++)
    {
      s->next=malloc(sizeof(string));s=s->next;
      s->str=malloc(4);
      randstr2(s->str,4);
    }
  s->next=0;
  n->strs=(string*)mst((void *)(n->strs),0,numfields,cfs,tmpbuf,0,0);
}
int checksame(void *a,void *b,void * arg)
{ string *s1,*s2;
  int numfields=((argtocompdup*)arg)->numfields;
  int indnum=((argtocompdup*)arg)->indnum;
  if(indnum==0){
    s1=((ele4*)a)->strs;s2=((ele4*)b)->strs;
    int r;
    for(int u=0;u<numfields;u++)
      {
	r=strcmp( s1->str,s2->str);
	if(r!=0)return r;
	s1=s1->next;s2=s2->next;
      }
    return 0;
  }
  else{
    s1=((duplicates*)a)->headp->strs;s2=((duplicates*)b)->headp->strs;
    int r;
    if(((duplicates *)a)->same!=0&&((duplicates *)b)->same!=0&&((duplicates *)a)->same==((duplicates *)b)->same)
      {
	((duplicates *)b)->same=a;
	return 0;
      }
    for(int u=0;u<numfields;u++)
      {
	r=strcmp( s1->str,s2->str);
	if(r<0)return 0;
	if(r>0)return 1;
	s1=s1->next;s2=s2->next;
      }
    ((duplicates *)b)->same=a;
    return 0;
  }
}
void printdup(duplicates* nd,int numfields)
{
  ele4 * n;string * s;int ct=0;
  while(nd!=0)
    {ct=0;
      printf("\nNumber of duplicate entries %d\n",nd->count);
      n=nd->headp;
      while(ct<nd->count){
	s=n->strs;
	printf("Index of element in original list %d: ",n->index);
	for(int u=0;u<numfields;u++){
	  printf("%s ",s->str);s=s->next;}
        printf("\n");
        ct++;n=n->next;
      }
      printf("\n*******************\n");
      nd=nd->next;
    }
}
void tst4(size_t nm4,int numfields)
{
  ele4 * n,*n1,*n2;
  duplicates *allduplicates,*ad2,*taild=0;
  size_t i;string *s1,*s2;
  int k,cnt=0;ele4* nlist=NULL;
  ele4 ** fr=malloc((nm4%chk!=0?nm4/chk+1:nm4/chk)*sizeof(ele4*));
  struct timespec s,e;
  start_display();
  int allpatterns;
  void** tmpbuf=malloc((nm4)*sizeof(void*));
  for(i=0;i<nm4;i+=chk)
    {
      if (nlist==NULL)
	{
	  nlist=(ele4*)malloc(((nm4>=chk)?chk:nm4)*sizeof(ele4));
	  fr[cnt++]=nlist;
	  n=nlist;
	  for (k=0;k<(nm4>=chk?chk:nm4);k++){
	    genrecords(n,numfields);
	    n->index=k;
	    n->same=0;
	    n->next=(k==((nm4>=chk)?chk-1:(nm4-1)))?NULL:n+1;
	    n=(k<((nm4>=chk)?chk-1:(nm4-1)))?n->next:n;
	  }
	}
      else{
	n->next=(ele4*)malloc((((nm4-i)>=chk)?chk:(nm4-i))*sizeof(ele4));
	fr[cnt++]=n->next;
	n=n->next;
	for (k=0;k<((nm4-i)>=chk?chk:(nm4-i));k++){
	  genrecords(n,numfields);
	  n->index=i+k;
	  n->same=0;
	  n->next=(k==(((nm4-i)>=chk)?chk-1:(nm4-i-1)))?NULL:n+1;
	  n=(k<(((nm4-i)>=chk)?chk-1:(nm4-i-1)))?n->next:n;
	}
      }
      if((nm4-i)>=chk)showprogress(((long long)i+chk)*100/nm4);
      else showprogress(100);
    }
  printf("\nDone building unsorted list.\n");
  clock_gettime(CLOCK_REALTIME,&s);
  nlist=mst((void *)nlist,0,nm4,cf4,tmpbuf,nm4,(void*)&numfields);
  allpatterns=0;i=0;
  n1=nlist;n2=n1->next;allpatterns++;i++;
  while(i<nm4){
    while(n2->same!=0){
      if(i==nm4)break;
      n1=n2;n2=n2->next;i++;
      if(i==nm4)break;
    }
    tmpbuf[allpatterns-1]=n2;
    if(i==nm4)break;
    n1=n2;
    n2=n2->next;i++;allpatterns++;
    if(i==nm4)break;
  }
  tmpbuf[allpatterns-1]=0;
  allduplicates=malloc(allpatterns*sizeof(duplicates));
  ad2=allduplicates;
  allpatterns=0;k=0;i=0;
  n1=nlist;n2=n1->next;
  allduplicates[k].headp=n1;
  allduplicates[k].next=allduplicates+k+1;
  allduplicates[k].count=1;allduplicates[k].same=0;
  allpatterns++;i++;
  while(i<nm4){
    while(n2!=tmpbuf[allpatterns-1]){
      allduplicates[k].count++;
      n2=n2->next;i++;
      if(i==nm4)break;
    }
    if(i==nm4)break;
    n1=n2;
    n2=n2->next;
    k++;
    allduplicates[k].headp=n1;
    allduplicates[k].next=allduplicates+k+1;
    allduplicates[k].count=1;allduplicates[k].same=0;
    allpatterns++;i++;
    if(i==nm4)break;
  }
  allduplicates=ms(allduplicates,0,sizeof(void*),(void **) &taild,allpatterns,cfd,tmpbuf,allpatterns,0);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nFound and grouped all duplicates (elements with higher number of duplicates listed first) in %lu second(s) and %lu nanosecond(s).\n",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nFound and grouped all duplicates (elements with higher number of duplicates listed first) in  %lu second(s) and %lu nanosecond(s).\n",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  duplicates *nd=allduplicates;
  argtocompdup argcmp;
  argcmp.numfields=numfields;
  argcmp.indnum=0;
  size_t sum=0,ct=0;
  for (int z=0;z<allpatterns;z++){
    sum+=nd->count;
    nd=nd->next;}
  if(sum!=nm4) printf("Check Failed\n");
  ct=0;
  nd=allduplicates;
  n=allduplicates->headp;n2=n;
  while(1){
    while(ct<nd->count)
      {
	if(checksame(n,n2,&argcmp)!=0)
	  printf("Check Failed\n");
	ct++;n2=n2->next;
      }
    nd=nd->next;
    if(nd==0)break;
    n=nd->headp;n2=n;ct=0;
  }
  //printdup(allduplicates,numfields);
  argcmp.indnum=1;
  allduplicates=ms(allduplicates,0,sizeof(void*),(void **) &taild,allpatterns,checksame,tmpbuf,allpatterns,&argcmp);
  nd=allduplicates;
  while(nd!=0)
    {
      if(nd->same!=0)printf("Check Failed\n");
      nd=nd->next;
    }
  for(i=0;i<nm4;i++){
    s1=nlist->strs;s2=s1->next;
    for(int z=0;;z++){
      free(s1);if(z==numfields-1)break;s1=s2;
      s2=s2->next;
    }
    nlist=nlist->next;
  }
  for(k=0;k<cnt;k++)free(fr[k]);
  free(ad2);free(tmpbuf);
  free(fr);
}
int main(int argc, char ** argv)
{ size_t nm1,nm2,nm3,nm4,end;
  int numthreads=4,numfields=8;
  nm1=(argc==1)?10000000:atoi(argv[1]);
  nm2=(argc<=2)?10000000:atoi(argv[2]);
  nm3=(argc<=3)?10000000:atoi(argv[3]);
  nm4=(argc<=4)?5000000:atoi(argv[4]);
  if(nm1==0||nm2==0||nm3==0||nm4==0)
    exit(1);
  end=pow(2,(ceil(log2(nm2))));
  srand(time(NULL));
  printf("Test 1 \n");
  tst1(nm1);
  printf("\nTest 2 (Checking for worst case.)\n");
  tst2((void *)(&end),nm2);
  printf("\nTest 3 (Checking for parallel sorting.)\n");
  tst3(nm3,numthreads);
  printf("\nTest 4 (Finding all duplicates efficiently.)\n");
  tst4(nm4,numfields);
  return 0;
}
