//Author - Sutirtha Sanyal
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
#include<math.h>
#include "ms.h"
#define chk 1000000
typedef struct tag1{
  //Preferred way of declaring linked list where next and previous pointers are declared first.
  struct tag1* next;
  struct tag1* prev;
  int index;  
  unsigned char name[4];
}node1;
typedef struct tag2{
  struct tag2* next;
  struct tag2* prev;
  int val1;
  int index;
  unsigned char name[4];
}node2;
typedef struct tag3{
  struct tag3* next;
  struct tag3* prev;
  int val1;
}node3;
size_t nm1,nm2,nm3,end;
void randstr(unsigned char x[],int size)
{
  int i;
  *(x)=rand()%26+65; 
  for (i=1;i<size-1;i++)
    {
      *(x+i)=rand()%26+97;
    }
  *(x+size-1)=0;
}
int cf1(void *a,void *b)
{
  return strcmp((char *)(((node1 *)a)->name),(char *)(((node1 *)b)->name))<=0?0:1;
}
int cf2(void *a,void *b)
{
  return strcmp((char *)(((node2 *)a)->name),(char *)(((node2 *)b)->name))<=0?0:1;
}
int cf22(void *a,void *b)
{
  if(((node2 *)a)->index<=((node2 *)b)->index)
    return 0;
  return 1;
}
int cf2s(void *a,void *b)
{
  if(((node2 *)a)->val1<=((node2 *)b)->val1)
    return 0;
  return 1;
}
int cf3(void *a,void *b)
{
  if(((node3 *)a)->val1<=((node3 *)b)->val1)
    return 0;
  return 1;
}
int cfw(void *a,void *b)//Generates worst case w.r.t. cf3.
{
  size_t start=2;
  while (start<=end){
    if(((node3 *)a)->val1%start<((node3 *)b)->val1%start)
      return 1;
    else  if(((node3 *)a)->val1%start>((node3 *)b)->val1%start)
      return 0;
    else 
      start*=2;
  }
  return 0;
}
void print1(node1 *n)
{
  for(;n!=NULL;n=n->next)
    printf("Name %s %d; ",n->name,n->index);
}
void print2(node2 *n)
{
  for(;n!=NULL;n=n->next)
    printf("Val1 %d Index %d Name %s; ",n->val1,n->index,n->name);
}
void print3(node3 *n)
{
  for(;n!=NULL;n=n->next)
    printf("Val1 %d ",n->val1);
}
void check2(node2 *n[],int (*cf)(void* a,void* b))
{
  size_t i=0;
  for (i=1;i<nm2;i++) {
    if (cf(n[i-1],n[i])) printf("\nCheck Failed\n");
    if (n[i-1]->next!=n[i]) printf("\nCheck Failed\n");
    if (n[i]->prev!=n[i-1]) printf("\nCheck Failed\n");
  }
  if (n[0]->prev!=NULL) printf("\nCheck Failed\n");
  if (n[nm2-1]->next!=NULL) printf("\nCheck Failed\n");
}
void check2n(node2 *n,node2* tail,int (*cf)(void* a,void* b))
{
  size_t i=0;
  if (n==NULL) return;
  for(;n->next!=NULL;i++,n=n->next)
    if(cf(n,n->next))printf("Check Failed\n");
  if(i!=nm2-1)printf("Check Failed\n");
  if(tail!=NULL){if(n!=tail)printf("Check Failed\n");
    for(;tail->prev!=NULL;i--,tail=tail->prev)
      if(tail->prev->next!=tail)printf("Check Failed\n");
    if(i!=0)printf("Check Failed\n");
  }}
void check1s(node1 *n,node1* tail,int (*cf)(void* a,void* b))
{
  size_t i=0;
  if (n==NULL) return;
  for(;n->next!=NULL;i++,n=n->next)
    if(cf(n,n->next)||(!cf(n->next,n)&&(n->index>n->next->index)))printf("Check Failed\n");
  if(i!=nm1-1)printf("Check Failed\n");
  if(tail!=NULL){if(n!=tail)printf("Check Failed\n");
    for(;tail->prev!=NULL;i--,tail=tail->prev)
      if(tail->prev->next!=tail)printf("Check Failed\n");
    if(i!=0)printf("Check Failed\n");
  }}
void check2s(node2 *n,node2* tail,int (*cf)(void* a,void* b))
{
  size_t i=0;
  if (n==NULL) return;
  for(;n->next!=NULL;i++,n=n->next)
    if(cf(n,n->next)||(!cf(n->next,n)&&(n->index>n->next->index)))printf("Check Failed\n");
  if(i!=nm2-1)printf("Check Failed\n");
  if(tail!=NULL){if(n!=tail)printf("Check Failed\n");
    for(;tail->prev!=NULL;i--,tail=tail->prev)
      if(tail->prev->next!=tail)printf("Check Failed\n");
    if(i!=0)printf("Check Failed\n");
  }}
void check3(node3 *n,node3* tail,int (*cf)(void* a,void* b))
{
  size_t i=0;
  if (n==NULL) return;
  for(;n->next!=NULL;i++,n=n->next)
    if(cf(n,n->next))printf("Check Failed\n");
  if(i!=nm3-1)printf("Check Failed\n");
  if(tail!=NULL){if(n!=tail)printf("Check Failed\n");
    for(;tail->prev!=NULL;i--,tail=tail->prev)
      if(tail->prev->next!=tail)printf("Check Failed\n");
    if(i!=0)printf("Check Failed\n");}
}
void printa1(node1 *n[],size_t sz)
{
  size_t i;
  for(i=0;i<sz;i++)
    printf("Name %s %d; ",n[i]->name,n[i]->index);
}
void printa2(node2 *n[],size_t sz)
{
  size_t i;
  for(i=0;i<sz;i++)
    printf("Val1 %d Index %d Name %s; ",n[i]->val1,n[i]->index,n[i]->name);
}
void printblank()
{
  int i;
  for (i=0;i<25;i++)
    {
      printf("\b");
    }
}
void printline(int x)
{
  int i;
  unsigned char ch='\%';
  printf("[");
  for (i=0;i<20;i++)
    {
      if (i<x/5)
	{
	  printf(".");
	  continue;
	}
      printf(" ");
    }
  printf("]");
  printf("%d",x);
  printf("%c",ch);
}
void start_display(void)
{
  short i;
  char ch='\%';
  printf("[");
  for (i=0;i<20;i++)
    {
      printf(" ");
    }
  printf("]");
  printf("0%c",ch);
}
void showprogress(int x)
{
  static int prev=0;
  char ch='\%';
  int y=x/5;
  if (y>prev)
    {
      prev=(y<20)?y:0;
      printblank();
      printline(x);
      fflush(stdout);
    }
  else
    {
      if(x<10)
	{
	  printf("\b\b");
	  printf("%d%c",x,ch);
	  fflush(stdout);
	}
      else
	{
	  printf("\b\b\b");
	  printf("%d%c",x,ch);
	  fflush(stdout);
	}
    }
}
void tst1()
{
  node1  n[nm1],*n2=NULL,*ptarr[nm1],*key;
  size_t i;
  void **tmpbuf=malloc(nm1*sizeof(void *));
  memset(tmpbuf,0,nm1*sizeof(void *));
  for(i=0;i<nm1;i++)
    {
      n[i].next=n+i+1;
      n[i].index=i;
      randstr(n[i].name,4);
    } 
  key=malloc(sizeof(node1));
  strcpy((char*)key->name,"Abc");
  strcpy((char*)n[rand()%nm1].name,(char*)key->name);
  strcpy((char*)key->name,"Xyz");
  strcpy((char*)n[rand()%nm1].name,(char *)key->name);
  strcpy((char *)key->name,"Def");
  strcpy((char *)n[rand()%nm1].name,(char*)key->name);
  n[nm1-1].next=0;
  printf("Unsorted List\n");
  //print1(n);
  struct timespec s,e;
  clock_gettime(CLOCK_REALTIME,&s);
  n2=(node1 *)msbse((void *)n,0,sizeof(node1*),nm1,cf1,tmpbuf,nm1,(void**)ptarr,(void*)key);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nSorting and searching took %lu seconds and %lu nanoseconds.\n",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nSorting and searching took %lu seconds and %lu nanoseconds.\n",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  printf("\n\nSorted List\n");
  //printa1(ptarr,nm1);
  check1s(ptarr[0],ptarr[nm1-1],cf1);
  printf("\n\nSearched Element\n");
  if(n2!=NULL)printf("%s %d",n2->name,n2->index);else printf("Key not found");
  n2=NULL;
  strcpy((char *)key->name,"Abc");
  clock_gettime(CLOCK_REALTIME,&s);
  bse((void**)ptarr,(void*)key,nm1,(void**)&n2,cf1);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nSearching took %lu seconds and %lu nanoseconds.",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nSearching took %lu seconds and %lu nanoseconds.",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  printf("\nSearched Element\n");
  if(n2!=NULL)printf("%s %d",n2->name,n2->index);else printf("Key not found");
  n2=NULL;
  strcpy((char*)key->name,"Xyz");
  clock_gettime(CLOCK_REALTIME,&s);
  bse((void**)ptarr,(void*)key,nm1,(void**)&n2,cf1);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nSearching took %lu seconds and %lu nanoseconds.",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nSearching took %lu seconds and %lu nanoseconds.",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  printf("\nSearched Element\n");
  if(n2!=NULL)printf("%s %d",n2->name,n2->index);else printf("Key not found");
  printf("\n**********\n");
  free(key);
  free(tmpbuf);
}
void tst2()
{
  node2 * n,*tail=NULL,**ptarr;
  size_t i,k,cnt=0;node2* nlist=NULL;
  node2** fr=malloc((nm2%chk!=0?nm2/chk+1:nm2/chk)*sizeof(node2*));
  void **tmpbuf;
  start_display();
  for(i=0;i<nm2;i+=chk)
    {
      if (nlist==NULL)
	{
	  nlist=(node2*)malloc(((nm2>=chk)?chk:nm2)*sizeof(node2));
	  fr[cnt++]=nlist;
	  n=nlist;
	  for (k=0;k<(nm2>=chk?chk:nm2);k++){
	    n->index=k;
	    randstr(n->name,4);
	    n->val1=rand()%100;
	    n->next=(k==((nm2>=chk)?chk-1:(nm2-1)))?NULL:n+1;
	    n=(k<((nm2>=chk)?chk-1:(nm2-1)))?n->next:n;
	  }
	}
      else{
	n->next=(node2*)malloc((((nm2-i)>=chk)?chk:(nm2-i))*sizeof(node2));
	fr[cnt++]=n->next;
	n=n->next;
	for (k=0;k<((nm2-i)>=chk?chk:(nm2-i));k++){
	  n->index=i+k;
	  n->val1=rand()%100;
	  randstr(n->name,4);
	  n->next=(k==(((nm2-i)>=chk)?chk-1:(nm2-i-1)))?NULL:n+1;
	  n=(k<(((nm2-i)>=chk)?chk-1:(nm2-i-1)))?n->next:n;
	}
      }
      if((nm2-i)>=chk)showprogress(((long long)i+chk)*100/nm2);
      else showprogress(100);
    }
  printf("\nDone building unsorted list.\n");
  printf("\nUnsorted List\n");
  //print2(nlist);
  tmpbuf=malloc((nm2)*sizeof(void*));
  memset(tmpbuf,0,nm2*sizeof(void*));
  ptarr=malloc((nm2)*sizeof(node2*));
  struct timespec s,e;
  clock_gettime(CLOCK_REALTIME,&s);
  nlist=(node2 *)mst((void *)nlist,0,nm2,cf2,tmpbuf,nm2);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nSorting took %lu seconds and %lu nanoseconds.",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nSorting took %lu seconds and %lu nanoseconds.",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  printf("\n\nSorted List\n");
  //print2(nlist);
  check2s(nlist,tail,cf2);
  node2 *key=malloc(sizeof(node2));
  key->index=17;
  clock_gettime(CLOCK_REALTIME,&s);
  nlist=(node2 *)msbse((void *)nlist,0,sizeof(node2*),nm2,cf22,tmpbuf,nm2,(void**)ptarr,(void*)key);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nSorting and searching took %lu seconds and %lu nanoseconds.\n",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nSorting and searching took %lu seconds and %lu nanoseconds.\n",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  printf("\n\nSorted List\n");
  //printa2(ptarr,nm2);
  check2(ptarr,cf22);
  printf("\n\nSearched Element\n");
  if(nlist!=NULL)printf("%d %d\n",nlist->val1,nlist->index);else printf("Key not found");
  n=NULL;
  key->index=nm2/2;
  clock_gettime(CLOCK_REALTIME,&s);
  bse((void**)ptarr,(void*)key,nm2,(void**)&n,cf22);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nSearching took %lu seconds and %lu nanoseconds.",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nSearching took %lu seconds and %lu nanoseconds.",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  printf("\nSearched Element\n");
  if(n!=NULL)printf("%d %d",n->val1,n->index);else printf("Key not found");
  node2* z=malloc(sizeof(node2));//Add One.
  z->index=ptarr[nm2-1]->index+1;
  z->val1=rand()%100;
  randstr(z->name,4);
  z->next=n->next;
  n->next=z;
  if(n->prev!=NULL)n->prev->next=z;//Delete One.
  else ptarr[0]=z;
  key->index=nm2;
  nlist=(node2 *)msbse(ptarr[0],0,sizeof(node2*),nm2,cf22,tmpbuf,nm2,(void**)ptarr,(void*)key);
  //printa2(ptarr,nm2);
  check2(ptarr,cf22);
  printf("\n\nSearched Element\n");
  if(nlist!=NULL)printf("%d %d\n",nlist->val1,nlist->index);else printf("Key not found");
  n=NULL;
  key->index=nm2/2;
  clock_gettime(CLOCK_REALTIME,&s);
  bse((void**)ptarr,(void*)key,nm2,(void**)&n,cf22);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nSearching took %lu seconds and %lu nanoseconds.",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nSearching took %lu seconds and %lu nanoseconds.",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  printf("\nSearched Element\n");
  if(n!=NULL)printf("%d %d",n->val1,n->index);else printf("Key not found");
  free(key);
  nlist=(node2 *)ms((void*)ptarr[0],0,sizeof(node2*),(void**)&tail,nm2,cf2s,tmpbuf,nm2);
  //print2(nlist);
  check2s(nlist,tail,cf2s);
  nlist=(node2 *)ms(nlist,0,sizeof(node2*),(void**)&tail,nm2,cf2,tmpbuf,nm2);
  //print2(nlist);
  check2n(nlist,tail,cf2);
  free(ptarr);
  free(tmpbuf);
  free(z);
  for(k=0;k<cnt;k++)free(fr[k]);
  free(fr);
  printf("\n**********\n");
}
void tst3()
{
  node3 * n;
  size_t i;
  int k,cnt=0;node3* nlist=NULL;
  node3 ** fr=malloc((nm3%chk!=0?nm3/chk+1:nm3/chk)*sizeof(node3*));
  struct timespec s,e;
  start_display();
  void* tail=NULL;
  void** tmpbuf=malloc((nm3)*sizeof(void*));
  memset(tmpbuf,0,nm3*sizeof(void*));
  for(i=0;i<nm3;i+=chk)
    {
      if (nlist==NULL)
	{
	  nlist=(node3*)malloc(((nm3>=chk)?chk:nm3)*sizeof(node3));
	  fr[cnt++]=nlist;
	  n=nlist;
	  for (k=0;k<(nm3>=chk?chk:nm3);k++){
	    n->val1=k;
	    n->next=(k==((nm3>=chk)?chk-1:(nm3-1)))?NULL:n+1;
	    if(k==0)n->prev=NULL;//Optional. After sorting prev pointers are organized automatically.
	    if(nm3>1&&chk>1&&k<=((nm3>=chk)?chk-2:(nm3-2)))n->next->prev=n;
	    n=(k<((nm3>=chk)?chk-1:(nm3-1)))?n->next:n;
	  }
	}
      else{
	n->next=(node3*)malloc((((nm3-i)>=chk)?chk:(nm3-i))*sizeof(node3));
	fr[cnt++]=n->next;
	n->next->prev=n;
	n=n->next;
	for (k=0;k<((nm3-i)>=chk?chk:(nm3-i));k++){
	  n->val1=(i+k);
	  n->next=(k==(((nm3-i)>=chk)?chk-1:(nm3-i-1)))?NULL:n+1;
	  //if(nm3-i>1&&chk>1&&k<=(((nm3-i)>=chk)?chk-2:(nm3-i-2)))n->next->prev=n;
	  n=(k<(((nm3-i)>=chk)?chk-1:(nm3-i-1)))?n->next:n;
	}
      }
      if((nm3-i)>=chk)showprogress(((long long)i+chk)*100/nm3);
      else showprogress(100);
    }
  printf("\nDone building list.\n");
  clock_gettime(CLOCK_REALTIME,&s);
  nlist=(node3 *)ms((void *)nlist,0,sizeof(node3*),&tail,nm3,cfw,tmpbuf,nm3);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nGenerated worst case in %lu seconds and %lu nanoseconds.\n",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nGenerated worst case in %lu seconds and %lu nanoseconds.\n",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  //print3(nlist);
  check3(nlist,tail,cfw);
  clock_gettime(CLOCK_REALTIME,&s);
  nlist=(node3 *)ms((void *)nlist,0,sizeof(node3*),&tail,nm3,cf3,tmpbuf,nm3);
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("\n\nSorting from worst case took %lu seconds and %lu nanoseconds.",e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("\n\nSorting from worst case took %lu seconds and %lu nanoseconds.",e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  //print3(nlist);
  check3(nlist,tail,cf3);
  free(tmpbuf);
  for(k=0;k<cnt;k++)free(fr[k]);
  free(fr);
  printf("\n**********\n");
}
int main(int argc, char ** argv)
{ nm1=(argc==1)?19:atoi(argv[1]);
  nm2=(argc<=2)?19:atoi(argv[2]);
  nm3=(argc<=3)?10000000:atoi(argv[3]);
  nm1=(nm1==0)?19:nm1;
  nm2=(nm2==0)?19:nm2;
  end=pow(2,(ceil(log2(nm3))-1));
  srand(time(NULL));
  printf("Test 1 (Here we use array for storing the linked list. So, the number of elements cannot be arbitrarily large.)\n");
  tst1();
  printf("\nTest 2 \n");
  tst2();
  printf("\nTest 3 (Checking for worst case for large number of elements.)\n");
  tst3();
  return 0;
}
