//Author - Sutirtha Sanyal
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <string.h>
#include <pthread.h>
#include <time.h>
#include <math.h>
#include "avl.h"
typedef struct tag1{
  struct tag1* lch;
  struct tag1* rch;
  struct tag1* prt;
  int dh;
  int val;
  int rht;
  int lht;
}avlnode;
int intcomp(void *a,void* b,void *arg)
{
  if(((avlnode*)a)->val<=((avlnode*)b)->val)
    return 0;
  return 1;
}
int fib2(int h, int * res){
  if(res[h]!=0)return res[h];
  if(h==0){res[h]=1;return 1;}
  if(h==1){res[h]=2;return 2;}
  int t=fib2(h-2,res)+fib2(h-1,res);
  res[h]=t;
  return t;
}
void genwt(avlnode* root,avlnode *allnodes,int h,int *ni)
{
  avlnode* t=root;int u,s;
  if(h==0)return;
  if(root->lch==0)s=0;
  else s=1;
  for (u=0;u<h;u++)
    {
      if(!s){t->lch=allnodes+(*ni);(*ni)++;t->lch->dh=-1;t->lch->prt=t;t=t->lch;s=1;}
      else{t->rch=allnodes+(*ni);(*ni)++;t->rch->dh=1;t->rch->prt=t;t=t->rch;s=0;}
    }
  t->dh=0;
  t=root->dh==-1||root->dh==0?root->lch:root->rch;
  u=1;
  while(u<h-1)
    {
      genwt(t,allnodes,h-1-u,ni);
      t=t->dh==-1?t->rch:t->lch;
      u++;
    }
}
void checktree(avlnode * root,avlnode* max,int (*cf)(void* a,void* b,void * arg),void* arg)
{
  if(root==0)return;
  if(root->lch!=0)
    checktree(root->lch,max,cf,arg);
  if(max!=0&&cf(max,root,arg)==1)
    {
      printf("Fail 1\n");
      exit(1);}
  max=root;
  if(root->lch!=0){root->lht=root->lch->rht>root->lch->lht?root->lch->rht+1:root->lch->lht+1;}
  else root->lht=0;
  if(root->rch!=0)
    checktree(root->rch,max,cf,arg);
  if(root->rch!=0){root->rht=root->rch->rht>root->rch->lht?root->rch->rht+1:root->rch->lht+1;}
  else root->rht=0;
  if(root->lht-root->rht!=root->dh||root->dh>1||root->dh<-1)
    {
      printf("Fail 2\n");
      exit(1);
    }
}
int main(int argc, char ** argv)
{ size_t nm1,nm2;
  int numins=0,numdel=0,numsearch=0,i,nm3;
  avlnode *root,*allnodes;
  nm1=(argc==1)?10000000:atoi(argv[1]);
  nm2=(argc<=2)?10000000:atoi(argv[2]);
  nm3=(argc<=3)?32:atoi(argv[3]);
  srand(time(0));
  struct timespec s,e;
  size_t instime=0,deltime=0,searchtime=0;
  avlnode * res=0;
  allnodes=malloc(nm1*sizeof(avlnode));root=0;
  for(int c=0;c<nm1;c++){
    allnodes[c].lch=0;allnodes[c].rch=0;allnodes[c].prt=0;allnodes[c].lht=0;allnodes[c].rht=0;allnodes[c].dh=0;
    allnodes[c].val=rand()%100;
    clock_gettime(CLOCK_REALTIME,&s);
    root=avl_insert(root,allnodes+c,0,sizeof(void*),2*sizeof(void*),3*sizeof(void*),intcomp,0);
    clock_gettime(CLOCK_REALTIME,&e);
    instime+=e.tv_nsec>=s.tv_nsec?e.tv_nsec-s.tv_nsec:1000000000+e.tv_nsec-s.tv_nsec;
    numins++;
    i=rand()%numins;
    clock_gettime(CLOCK_REALTIME,&s);
    avlnode* t=avl_delete(root,allnodes+i,0,sizeof(void*),2*sizeof(void*),3*sizeof(void*));
    clock_gettime(CLOCK_REALTIME,&e);
    if(t!=0){ deltime+=e.tv_nsec>=s.tv_nsec?e.tv_nsec-s.tv_nsec:1000000000+e.tv_nsec-s.tv_nsec;
      numdel++;root=t;}
    i=rand()%numins;
    clock_gettime(CLOCK_REALTIME,&s);
    res=avl_search(root,allnodes+i,0,sizeof(void*),intcomp,0);
    clock_gettime(CLOCK_REALTIME,&e);
    if(res!=root){
      searchtime+=e.tv_nsec>=s.tv_nsec?e.tv_nsec-s.tv_nsec:1000000000+e.tv_nsec-s.tv_nsec;
      numsearch++;
    }
  }
  checktree(root,0,intcomp,0);
  free(allnodes);
  printf("Total time for %d number of AVL inserts is %lu ns. Average %lu ns.\n",numins,instime,instime/numins);
  printf("Total time for %d number of AVL deletes is %lu ns. Average %lu ns.\n",numdel,deltime,deltime/numdel);
  printf("Total time for %d number of AVL searches is %lu ns. Average %lu ns.\n",numsearch,searchtime,searchtime/numsearch);
  printf("********************\n");
  root=0;
  allnodes=malloc(nm2*sizeof(avlnode));
  for(int c=0;c<nm2;c++){
    allnodes[c].lch=0;allnodes[c].rch=0;allnodes[c].prt=0;allnodes[c].lht=0;allnodes[c].rht=0;allnodes[c].dh=0;
    allnodes[c].val=nm2-c;
  }
  clock_gettime(CLOCK_REALTIME,&s);
  for(int c=0;c<nm2;c++){
    root=avl_insert(root,allnodes+c,0,sizeof(void*),2*sizeof(void*),3*sizeof(void*),intcomp,0);
  }
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("%lu number of AVL inserts took %lu second(s) and %lu nanosecond(s).\n",nm2,e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("%lu number of AVL inserts took %lu second(s) and %lu nanosecond(s).\n",nm2,e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  checktree(root,0,intcomp,0);
  if(root->lht>=root->rht)
    { if(root->lht!=(int)(log2(nm2)))
	{printf("Height bound failed.\n");exit(1);}
      else printf("Height of AVL tree for %1$lu distinct elements inserted in (asc/desc)ending order is %2$d. floor(lg(%1$lu))=%2$d.\n",nm2,root->lht);
    }
  else
    {if(root->rht!=(int)(log2(nm2)))
	{printf("Height bound failed.\n");exit(1);}
      else printf("Height of AVL tree for %1$lu distinct elements inserted in (asc/desc)ending order is %2$d. floor(lg(%1$lu))=%2$d.\n",nm2,root->rht);
    }
  free(allnodes);
  printf("********************\n");
  int *resl=malloc((nm3+1)*sizeof(int));
  memset(resl,0,(nm3+1)*sizeof(int));
  int fh=fib2(nm3,resl);
  int tn=fh;
  int ni=1,r;
  avlnode * key=0;
  for (int u=nm3-2;u>=0;u-=2)
    tn+=resl[u];
  allnodes=malloc(tn*sizeof(avlnode));
  for(int c=0;c<tn;c++){
    allnodes[c].lch=0;allnodes[c].rch=0;allnodes[c].prt=0;allnodes[c].dh=0;allnodes[c].val=0;
  }
  for(int u=nm3;u>=0;u-=2){
    r=ni-1;
    genwt(allnodes+ni-1,allnodes,u,&ni);
    if(u==0)break;
    if(u==1){allnodes[r].dh=1;break;}
    if(u==2||u==3)key=allnodes[r].lch->rch;
    allnodes[r].dh=1;allnodes[r].rch=allnodes+ni;
    allnodes[ni].prt=allnodes+r;
    ni++;
  }
  checktree(allnodes,0,intcomp,0);
  clock_gettime(CLOCK_REALTIME,&s);
  root=avl_delete(allnodes,key,0,sizeof(void*),2*sizeof(void*),3*sizeof(void*));
  clock_gettime(CLOCK_REALTIME,&e);
  printf("Worst case delete for AVL tree of height %d took %lu ns.\n",nm3,e.tv_nsec>=s.tv_nsec?e.tv_nsec-s.tv_nsec:1000000000+e.tv_nsec-s.tv_nsec);
  checktree(root,0,intcomp,0);
  if(tn>20)
    {
      int q=0;
      while(q<20){
	avlnode* t=avl_delete(root,allnodes+rand()%tn,0,sizeof(void*),2*sizeof(void*),3*sizeof(void*));
	if(t!=0){root=t;
	  checktree(root,0,intcomp,0);
	}
	q++;
      }
    }
  free(allnodes);
  return 0;
}
