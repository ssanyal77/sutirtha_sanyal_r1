//Author - Sutirtha Sanyal
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <string.h>
#include <pthread.h>
#include <time.h>
#include <math.h>
#include "avl.h"
typedef struct tag1{
  struct tag1* lch;
  struct tag1* rch;
  struct tag1* prt;
  struct tag1* same;
  int dh;
  int val;
  int rht;
  int lht;
}avlnode;
int intcomp(void *a,void* b,void *arg)
{
  if(((avlnode*)a)->val<((avlnode*)b)->val)
    return -1;
  else if (((avlnode*)a)->val>((avlnode*)b)->val)
    return 1;
  return 0;
}
void checktree(avlnode * root,avlnode* max,int (*cf)(void* a,void* b,void * arg),void* arg)
{
  if(root==0)return;
  if(root->lch!=0)
    checktree(root->lch,max,cf,arg);
  if(max!=0&&cf(max,root,arg)==1)
    {
      printf("Fail 1\n");
      exit(1);}
  max=root;
  if(root->lch!=0){root->lht=root->lch->rht>root->lch->lht?root->lch->rht+1:root->lch->lht+1;}
  else root->lht=0;
  if(root->rch!=0)
    checktree(root->rch,max,cf,arg);
  if(root->rch!=0){root->rht=root->rch->rht>root->rch->lht?root->rch->rht+1:root->rch->lht+1;}
  else root->rht=0;
  if(root->lht-root->rht!=root->dh||root->dh>1||root->dh<-1)
    {
      printf("Fail 2\n");
      exit(1);
    }
}
int main(int argc, char ** argv)
{ size_t nm1,nm2;
  int numins=0,numdel=0,numsearch=0,i,nm3;
  avlnode *root,*allnodes;
  nm1=(argc==1)?10000000:atoi(argv[1]);
  nm2=(argc<=2)?10000000:atoi(argv[2]);
  nm3=(argc<=3)?10000000:atoi(argv[3]);
  srand(time(0));
  struct timespec s,e;
  size_t instime=0,deltime=0,searchtime=0;
  avlnode * head=0,*res=0;
  allnodes=malloc(nm1*sizeof(avlnode));root=0;
  for(int c=0;c<nm1;c++){
    allnodes[c].lch=0;allnodes[c].rch=0;allnodes[c].prt=0;allnodes[c].lht=0;allnodes[c].rht=0;allnodes[c].dh=0;
    allnodes[c].val=rand()%10000;
    clock_gettime(CLOCK_REALTIME,&s);
    root=avl_insert(root,allnodes+c,0,sizeof(void*),2*sizeof(void*),4*sizeof(void*),intcomp,0);
    clock_gettime(CLOCK_REALTIME,&e);
    instime+=e.tv_nsec>=s.tv_nsec?e.tv_nsec-s.tv_nsec:1000000000+e.tv_nsec-s.tv_nsec;
    numins++;
    i=rand()%numins;
    clock_gettime(CLOCK_REALTIME,&s);
    avlnode* t=avl_delete(root,allnodes+i,0,sizeof(void*),2*sizeof(void*),4*sizeof(void*));
    clock_gettime(CLOCK_REALTIME,&e);
    if(t!=0){ deltime+=e.tv_nsec>=s.tv_nsec?e.tv_nsec-s.tv_nsec:1000000000+e.tv_nsec-s.tv_nsec;
      numdel++;root=t;}
    i=rand()%nm1;
    clock_gettime(CLOCK_REALTIME,&s);
    res=avl_find(root,allnodes+i,0,sizeof(void*),intcomp,0);
    clock_gettime(CLOCK_REALTIME,&e);
    if(res!=root){
      searchtime+=e.tv_nsec>=s.tv_nsec?e.tv_nsec-s.tv_nsec:1000000000+e.tv_nsec-s.tv_nsec;
      numsearch++;}
  }
  checktree(root,0,intcomp,0);
  free(allnodes);
  printf("Total time for %d number of AVL inserts is %lu ns. Average %lu ns.\n",numins,instime,instime/numins);
  printf("Total time for %d number of AVL deletes is %lu ns. Average %lu ns.\n",numdel,deltime,deltime/numdel);
  printf("Total time for %d number of AVL searches is %lu ns. Average %lu ns.\n",numsearch,searchtime,searchtime/numsearch);
  printf("********************\n");
  root=0;
  allnodes=malloc(nm2*sizeof(avlnode));
  for(int c=0;c<nm2;c++){
    allnodes[c].lch=0;allnodes[c].rch=0;allnodes[c].prt=0;allnodes[c].lht=0;allnodes[c].rht=0;allnodes[c].dh=0;
    allnodes[c].val=nm2-c;
  }
  clock_gettime(CLOCK_REALTIME,&s);
  for(int c=0;c<nm2;c++){
    root=avl_insert(root,allnodes+c,0,sizeof(void*),2*sizeof(void*),4*sizeof(void*),intcomp,0);
  }
  clock_gettime(CLOCK_REALTIME,&e);
  if(e.tv_nsec>=s.tv_nsec)
    printf("%lu number of AVL inserts took %lu second(s) and %lu nanosecond(s).\n",nm2,e.tv_sec-s.tv_sec,e.tv_nsec-s.tv_nsec);
  else
    printf("%lu number of AVL inserts took %lu second(s) and %lu nanosecond(s).\n",nm2,e.tv_sec-s.tv_sec-1,1000000000+e.tv_nsec-s.tv_nsec);
  checktree(root,0,intcomp,0);
  if(root->lht>=root->rht)
    { if(root->lht!=(int)(log2(nm2)))
	{printf("Height bound failed.\n");exit(1);}
      else printf("Height of AVL tree for %1$lu distinct elements inserted in (asc/desc)ending order is %2$d. floor(lg(%1$lu))=%2$d.\n",nm2,root->lht);
    }
  else
    {if(root->rht!=(int)(log2(nm2)))
	{printf("Height bound failed.\n");exit(1);}
      else printf("Height of AVL tree for %1$lu distinct elements inserted in (asc/desc)ending order is %2$d. floor(lg(%1$lu))=%2$d.\n",nm2,root->rht);
    }
  free(allnodes);
  printf("********************\n");
  allnodes=malloc(nm3*sizeof(avlnode));
  root=0;int x=rand()%10;int y=x+rand()%10000;
  for(int c=0;c<nm3;c++){
    allnodes[c].lch=0;allnodes[c].rch=0;allnodes[c].prt=0;allnodes[c].lht=0;allnodes[c].rht=0;allnodes[c].dh=0;
    allnodes[c].val=c>=x&&c<=y?(x+y)/2:c;
  }
  int num1;
  if(nm3-1<x)
    {printf("No duplicates will be inserted.\n");num1=0;}
  else
    {num1=nm3-1<y?nm3-x:y-x+1;printf("%d number of duplicates with value %d inserted.\n",num1,(x+y)/2);}
  for(int c=0;c<nm3;c++){
    root=avl_insert(root,allnodes+c,0,sizeof(void*),2*sizeof(void*),4*sizeof(void*),intcomp,0);
  }
  avlnode key;key.val=(x+y)/2;
  clock_gettime(CLOCK_REALTIME,&s);
  avl_findall(root,&key,0,sizeof(void*),3*sizeof(void*),intcomp,0, (void*)&head);
  clock_gettime(CLOCK_REALTIME,&e);
  printf("Finding duplicates took %lu ns.\n",e.tv_nsec>=s.tv_nsec?e.tv_nsec-s.tv_nsec:1000000000+e.tv_nsec-s.tv_nsec);
  avlnode *t=head;int num2=0;
  while(t!=0){
    if(t->val!=key.val)
      {printf("Check Failed 1.\n");exit(1);}
    if(t->rht==-1)
      {printf("Check Failed 2.\n");exit(1);}
    num2++;
    t->rht=-1;
    t=t->same;}
  if(num2!=num1)
    {
      printf("Check Failed 3.\n");
      exit(1);}
  if(head!=0)
    printf("%d number of duplicates found with value %d.\n",num2,head->val);
  free(allnodes);
  return 0;
}
