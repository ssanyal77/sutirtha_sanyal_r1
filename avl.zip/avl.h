void* avl_insert(void* root, void * key, size_t loff,size_t roff,size_t poff,size_t doff,int (*cf)(void* a,void* b,void *arg),void *arg);
void* avl_delete(void* root, void * key,size_t loff,size_t roff,size_t poff,size_t doff);
void* avl_search(void* root, void * key, size_t loff,size_t roff,int (*cf)(void* a,void* b,void *arg),void *arg);
