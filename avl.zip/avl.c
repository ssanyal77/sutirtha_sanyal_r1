//Author - Sutirtha Sanyal
#include<string.h>
void* avl_insert(void* root, void * key, size_t loff,size_t roff,size_t poff,size_t doff,int (*cf)(void* a,void* b,void *arg),void *arg)
{
  if (root==0){root=key;*((void**)(root+loff))=0;
    *((void**)(root+roff))=0;*((void**)(root+poff))=0;*((int*)(root+doff))=0;
    return root;
  }
  register void *x=root,*x2,*t;
  while(1){
    if(!cf(key,x,arg)){
      if(*((void**)(x+loff))!=0)x=*((void**)(x+loff));
      else {
	*((void**)(x+loff))=key;
	*((void**)((*((void**)(x+loff)))+poff))=x;
	break;
      }}
    else {if(*((void**)(x+roff))!=0)x=*((void**)(x+roff));
      else {
	*((void**)(x+roff))=key;
	*((void**)((*((void**)(x+roff)))+poff))=x;
	break;}}
  }
  x2=x;
  x=key;
  while(x!=0)
    {
      if((*((int*)(x+doff))==0&&(*((void**)(x+loff))!=0||*((void**)(x+roff))!=0))||*((void**)(x+poff))==0)return root;
      if(x==*((void**)(*((void**)(x+poff))+roff))){
	*((int*)((*((void**)(x+poff)))+doff))=*((int*)((*((void**)(x+poff)))+doff))-1;
	if(*((int*)((*((void**)(x+poff)))+doff))!=0&&*((int*)((*((void**)(x+poff)))+doff))!=-2){
	  if( *((void**)((*((void**)(x+poff)))+poff))!=0&& *((void**)(x+poff))==*((void**)((*((void**)((*((void**)(x+poff)))+poff)))+roff)))
	    x2=*((void**)((*((void**)(x+poff)))+poff));}
      }
      else{
	*((int*)((*((void**)(x+poff)))+doff))=*((int*)((*((void**)(x+poff)))+doff))+1;
	if(*((int*)((*((void**)(x+poff)))+doff))!=0&&*((int*)((*((void**)(x+poff)))+doff))!=2){
	  if( *((void**)((*((void**)(x+poff)))+poff))!=0&& *((void**)(x+poff))==*((void**)((*((void**)((*((void**)(x+poff)))+poff)))+loff)))
	    x2=*((void**)((*((void**)(x+poff)))+poff));
	}
      }
      if(*((int*)((*((void**)(x+poff)))+doff))==0)return root;
      if(*((int*)((*((void**)(x+poff)))+doff))==2){
	x=*((void**)(x+poff));
	while(1){
	  if(*((int*)(x2+doff))>0)
	    {
	      *((void**)((*((void**)(x2+loff)))+poff))=*((void**)(x2+poff));
	      if(*((void**)(x2+poff))!=0)
		{
		  if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		    *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+loff));
		  else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+loff));
		}
	      *((void**)(x2+poff))=*((void**)(x2+loff));
	      *((int*)(x2+doff))=(*((void***)(x2+roff))==0)?0:*((int*)(x2+doff))-2;
	      *((int*)((*((void**)(x2+loff)))+doff))=(x2==x)?0:-1;
	      t=*((void***)(x2+loff));
	      if(*((void**)((*((void**)(x2+loff)))+roff))!=0)
		*((void**)((*((void**)((*((void**)(x2+loff)))+roff)))+poff))=x2;
	      *((void***)(x2+loff))= *((void**)((*((void**)(x2+loff)))+roff));
	      *((void***)(t+roff))=x2;x2=t;
	    }
	  else {
	    *((void**)((*((void**)(x2+roff)))+poff))=*((void**)(x2+poff));
	    if(*((void**)(x2+poff))!=0)
	      {
		if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		  *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+roff));
		else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+roff));
	      }
	    *((void**)(x2+poff))=*((void**)(x2+roff));
	    *((int*)(x2+doff))=(*((void***)(x2+loff))==0)?0:*((int*)(x2+doff))+2;
	    *((int*)((*((void**)(x2+roff)))+doff))=1;
	    t=*((void***)(x2+roff));
	    if(*((void**)((*((void**)(x2+roff)))+loff))!=0)
	      *((void**)((*((void**)((*((void**)(x2+roff)))+loff)))+poff))=x2;
	    *((void***)(x2+roff))= *((void**)((*((void**)(x2+roff)))+loff));
	    *((void***)(t+loff))=x2;x2=t;
	  }
	  if(*((int*)(x2+doff))==0){if(*((void**)(x2+poff))==0){root=x2;*((void**)(root+poff))=0;}break;}
	  x2=*((void**)(x2+poff));
	}
	return root;
      }
      if(*((int*)((*((void**)(x+poff)))+doff))==-2){
	x=*((void**)(x+poff));
	while(1){
	  if(*((int*)(x2+doff))<0)
	    {
	      *((void**)((*((void**)(x2+roff)))+poff))=*((void**)(x2+poff));
	      if(*((void**)(x2+poff))!=0)
		{
		  if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		    *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+roff));
		  else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+roff));
		}
	      *((void**)(x2+poff))=*((void**)(x2+roff));
	      *((int*)(x2+doff))=(*((void***)(x2+loff))==0)?0:*((int*)(x2+doff))+2;
	      *((int*)((*((void**)(x2+roff)))+doff))=(x2==x)?0:1;
	      t=*((void***)(x2+roff));
	      if(*((void**)((*((void**)(x2+roff)))+loff))!=0)
		*((void**)((*((void**)((*((void**)(x2+roff)))+loff)))+poff))=x2;
	      *((void***)(x2+roff))= *((void**)((*((void**)(x2+roff)))+loff));
	      *((void***)(t+loff))=x2;x2=t;
	    }
	  else {
	    *((void**)((*((void**)(x2+loff)))+poff))=*((void**)(x2+poff));
	    if(*((void**)(x2+poff))!=0)
	      {
		if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		  *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+loff));
		else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+loff));
	      }
	    *((void**)(x2+poff))=*((void**)(x2+loff));
	    *((int*)(x2+doff))=(*((void***)(x2+roff))==0)?0:*((int*)(x2+doff))-2;
	    *((int*)((*((void**)(x2+loff)))+doff))=-1;
	    t=*((void***)(x2+loff));
	    if(*((void**)((*((void**)(x2+loff)))+roff))!=0)
	      *((void**)((*((void**)((*((void**)(x2+loff)))+roff)))+poff))=x2;
	    *((void***)(x2+loff))= *((void**)((*((void**)(x2+loff)))+roff));
	    *((void***)(t+roff))=x2;x2=t;
	  }
	  if(*((int*)(x2+doff))==0){if(*((void**)(x2+poff))==0){root=x2;*((void**)(root+poff))=0;}break;}
	  x2=*((void**)(x2+poff));
	}
	return root;
      }
      x=*((void**)(x+poff));
    }
  return root;
}
void* avl_delete(void * root,void * key, size_t loff, size_t roff,size_t poff,size_t doff)
{
  register void *x2,*t,*t2,*lnprt=(void*)0x1;
  if(key==0||(*((void**)(key+poff))==0&&*((void**)(key+loff))==0&&*((void**)(key+roff))==0))return 0;
  while(*((void**)(key+loff))!=0||*((void**)(key+roff))!=0) {
    if(*((int*)(key+doff))==0 )
      {
	if(*((int*)((*((void**)(key+loff)))+doff))!=-1)
	  {
	    if(*((int*)((*((void**)(key+loff)))+doff))==0){
	      if(lnprt==(void*)0x1)lnprt=*((void**)(key+poff));
	      *((int*)(key+doff))=-1;*((int*)((*((void**)(key+loff)))+doff))=-2;
	      if(*((void**)(key+poff))==0)root=*((void**)(key+loff));
	      *((void**)((*((void**)(key+loff)))+poff))=*((void**)(key+poff));
	      if(*((void**)(key+poff))!=0){if(key==*((void**)((*((void**)(key+poff)))+loff)))
		  *((void**)((*((void**)(key+poff)))+loff))=*((void**)(key+loff));
		else *((void**)((*((void**)(key+poff)))+roff))=*((void**)(key+loff));
	      }
	      *((void**)(key+poff))=*((void**)(key+loff));
	      t=*((void**)(key+loff));
	      if(*((void**)((*((void**)(key+loff)))+roff))!=0)
		*((void**)((*((void**)((*((void**)(key+loff)))+roff)))+poff))=key;
	      *((void**)(key+loff))=*((void**)((*((void**)(key+loff)))+roff));
	      *((void**)(t+roff))=key;
	    }
	    else {
	      *((int*)(key+doff))=-2;*((int*)((*((void**)(key+loff)))+doff))=-2;
	      if(lnprt==(void*)0x1)lnprt=*((void**)(key+poff));
	      if(*((void**)(key+poff))==0)root=*((void**)(key+loff));
	      *((void**)((*((void**)(key+loff)))+poff))=*((void**)(key+poff));
	      if(*((void**)(key+poff))!=0){if(key==*((void**)((*((void**)(key+poff)))+loff)))
		  *((void**)((*((void**)(key+poff)))+loff))=*((void**)(key+loff));
		else *((void**)((*((void**)(key+poff)))+roff))=*((void**)(key+loff));
	      }
	      *((void**)(key+poff))=*((void**)(key+loff));
	      t=*((void**)(key+loff));
	      if(*((void**)((*((void**)(key+loff)))+roff))!=0)
		*((void**)((*((void**)((*((void**)(key+loff)))+roff)))+poff))=key;
	      *((void**)(key+loff))=*((void**)((*((void**)(key+loff)))+roff));
	      *((void**)(t+roff))=key;
	    }
	  }
	else if(*((int*)((*((void**)(key+roff)))+doff))!=1)
	  {
	    if(*((int*)((*((void**)(key+roff)))+doff))==0){
	      if(lnprt==(void*)0x1)lnprt=*((void**)(key+poff));
	      *((int*)(key+doff))=1;*((int*)((*((void**)(key+roff)))+doff))=2;
	      if(*((void**)(key+poff))==0)root=*((void**)(key+roff));
	      *((void**)((*((void**)(key+roff)))+poff))=*((void**)(key+poff));
	      if(*((void**)(key+poff))!=0){if(key==*((void**)((*((void**)(key+poff)))+loff)))
		  *((void**)((*((void**)(key+poff)))+loff))=*((void**)(key+roff));
		else *((void**)((*((void**)(key+poff)))+roff))=*((void**)(key+roff));
	      }
	      *((void**)(key+poff))=*((void**)(key+roff));
	      t=*((void**)(key+roff));
	      if(*((void**)((*((void**)(key+roff)))+loff))!=0)
		*((void**)((*((void**)((*((void**)(key+roff)))+loff)))+poff))=key;
	      *((void**)(key+roff))=*((void**)((*((void**)(key+roff)))+loff));
	      *((void**)(t+loff))=key;
	    }
	    else {
	      *((int*)(key+doff))=2;*((int*)((*((void**)(key+roff)))+doff))=2;
	      if(lnprt==(void*)0x1)lnprt=*((void**)(key+poff));
	      if(*((void**)(key+poff))==0)root=*((void**)(key+roff));
	      *((void**)((*((void**)(key+roff)))+poff))=*((void**)(key+poff));
	      if(*((void**)(key+poff))!=0){if(key==*((void**)((*((void**)(key+poff)))+loff)))
		  *((void**)((*((void**)(key+poff)))+loff))=*((void**)(key+roff));
		else *((void**)((*((void**)(key+poff)))+roff))=*((void**)(key+roff));
	      }
	      *((void**)(key+poff))=*((void**)(key+roff));
	      t=*((void**)(key+roff));
	      if(*((void**)((*((void**)(key+roff)))+loff))!=0)
		*((void**)((*((void**)((*((void**)(key+roff)))+loff)))+poff))=key;
	      *((void**)(key+roff))=*((void**)((*((void**)(key+roff)))+loff));
	      *((void**)(t+loff))=key;
	    }
	  }
	else
	  {
	    x2=key;
	    while(*((void**)(x2+loff))!=0||*((void**)(x2+roff))!=0)
	      {
		if(*((int*)(x2+doff))>=0){x2=*((void**)(x2+loff));if(*((int*)(x2+doff))==1||*((int*)(x2+doff))==0)break;}
		else {x2=*((void**)(x2+roff));if(*((int*)(x2+doff))==-1||*((int*)(x2+doff))==0)break;}
	      }
	    x2=*((void**)(x2+poff));
	    while(1){
	      if(x2==key){
		if(lnprt==(void*)0x1)lnprt=*((void**)(key+poff));
		if(*((void**)(key+poff))==0)root=*((void**)(key+loff));
		*((void**)((*((void**)(x2+loff)))+poff))=*((void**)(x2+poff));
		if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		    *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+loff));
		  else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+loff));
		}
		*((int*)(x2+doff))=*((int*)((*((void**)(x2+loff)))+doff))==0?-1:-2;
		*((int*)((*((void**)(x2+loff)))+doff))=-2;
		*((void**)(x2+poff))=*((void**)(x2+loff));
		t=*((void**)(x2+loff));
		if(*((void**)((*((void**)(x2+loff)))+roff))!=0)
		  *((void**)((*((void**)((*((void**)(x2+loff)))+roff)))+poff))=x2;
		*((void**)(x2+loff))=*((void**)((*((void**)(x2+loff)))+roff));
		*((void**)(t+roff))=x2;
		break;
	      }
	      else  if(*((int*)(x2+doff))==1)
		{
		  *((void**)((*((void**)(x2+loff)))+poff))=*((void**)(x2+poff));
		  if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		      *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+loff));
		    else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+loff));
		  }
		  *((int*)(x2+doff))=*((int*)((*((void**)(x2+loff)))+doff))==0?0:-1;
		  *((int*)((*((void**)(x2+loff)))+doff))=-1;
		  *((void**)(x2+poff))=*((void**)(x2+loff));
		  t=*((void**)(x2+loff));
		  if(*((void**)((*((void**)(x2+loff)))+roff))!=0)
		    *((void**)((*((void**)((*((void**)(x2+loff)))+roff)))+poff))=x2;
		  *((void**)(x2+loff))=*((void**)((*((void**)(x2+loff)))+roff));
		  *((void**)(t+roff))=x2;x2=t;
		}
	      else if(*((int*)(x2+doff))==-1)
		{
		  *((void**)((*((void**)(x2+roff)))+poff))=*((void**)(x2+poff));
		  if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		      *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+roff));
		    else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+roff));
		  }
		  *((int*)(x2+doff))=*((int*)((*((void**)(x2+roff)))+doff))==0?0:1;
		  *((int*)((*((void**)(x2+roff)))+doff))=1;
		  *((void**)(x2+poff))=*((void**)(x2+roff));
		  t=*((void**)(x2+roff));
		  if(*((void**)((*((void**)(x2+roff)))+loff))!=0)
		    *((void**)((*((void**)((*((void**)(x2+roff)))+loff)))+poff))=x2;
		  *((void**)(x2+roff))=*((void**)((*((void**)(x2+roff)))+loff));
		  *((void**)(t+loff))=x2;x2=t;
		}
	      x2=*((void**)(x2+poff));
	    }
	  }
      }
    else if(*((int*)(key+doff))>=1)
      {
	x2=key;
	while(*((void**)(x2+loff))!=0||*((void**)(x2+roff))!=0)
	  {
	    if(*((int*)(x2+doff))>=0){x2=*((void**)(x2+loff));if(*((int*)(x2+doff))==1||*((int*)(x2+doff))==0)break;}
	    else {x2=*((void**)(x2+roff));if(*((int*)(x2+doff))==-1||*((int*)(x2+doff))==0)break;}
	  }
	x2=*((void**)(x2+poff));
	while(1){
	  if(x2==key){
	    if(lnprt==(void*)0x1)lnprt=*((void**)(key+poff));
	    if(*((void**)(key+poff))==0)root=*((void**)(key+loff));
	    *((void**)((*((void**)(x2+loff)))+poff))=*((void**)(x2+poff));
	    if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		*((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+loff));
	      else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+loff));
	    }
	    if(*((int*)(key+doff))==1){*((int*)(x2+doff))=*((int*)((*((void**)(x2+loff)))+doff))==0?0:-1;
	      *((int*)((*((void**)(x2+loff)))+doff))=-1;}
	    if(*((int*)(key+doff))==2){*((int*)(x2+doff))=*((int*)((*((void**)(x2+loff)))+doff))==0?1:0;
	      *((int*)((*((void**)(x2+loff)))+doff))=*((int*)((*((void**)(x2+loff)))+doff))==0?-1:0;
	      if(*((int*)(x2+doff))==0)*((int*)((*((void**)(x2+poff)))+doff))=*((int*)((*((void**)(x2+poff)))+doff))-1;
	    }
	    *((void**)(x2+poff))=*((void**)(x2+loff));
	    t=*((void**)(x2+loff));
	    if(*((void**)((*((void**)(x2+loff)))+roff))!=0)
	      *((void**)((*((void**)((*((void**)(x2+loff)))+roff)))+poff))=x2;
	    *((void**)(x2+loff))=*((void**)((*((void**)(x2+loff)))+roff));
	    *((void**)(t+roff))=x2;
	    break;
	  }
	  else  if(*((int*)(x2+doff))==1)
	    {
	      *((void**)((*((void**)(x2+loff)))+poff))=*((void**)(x2+poff));
	      if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		  *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+loff));
		else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+loff));
	      }
	      *((void**)(x2+poff))=*((void**)(x2+loff));
	      *((int*)(x2+doff))=*((int*)((*((void**)(x2+loff)))+doff))==0?0:-1;
	      *((int*)((*((void**)(x2+loff)))+doff))=-1;
	      t=*((void**)(x2+loff));
	      if(*((void**)((*((void**)(x2+loff)))+roff))!=0)
		*((void**)((*((void**)((*((void**)(x2+loff)))+roff)))+poff))=x2;
	      *((void**)(x2+loff))=*((void**)((*((void**)(x2+loff)))+roff));
	      *((void**)(t+roff))=x2;x2=t;
	    }
	  else if(*((int*)(x2+doff))==-1)
	    {
	      *((void**)((*((void**)(x2+roff)))+poff))=*((void**)(x2+poff));
	      if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		  *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+roff));
		else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+roff));
	      }
	      *((void**)(x2+poff))=*((void**)(x2+roff));
	      *((int*)(x2+doff))=*((int*)((*((void**)(x2+roff)))+doff))==0?0:1;
	      *((int*)((*((void**)(x2+roff)))+doff))=1;
	      t=*((void**)(x2+roff));
	      if(*((void**)((*((void**)(x2+roff)))+loff))!=0)
		*((void**)((*((void**)((*((void**)(x2+roff)))+loff)))+poff))=x2;
	      *((void**)(x2+roff))=*((void**)((*((void**)(x2+roff)))+loff));
	      *((void**)(t+loff))=x2;x2=t;
	    }
	  x2=*((void**)(x2+poff));
	}
      }
    else if(*((int*)(key+doff))<=-1){
      x2=key;
      while(*((void**)(x2+loff))!=0||*((void**)(x2+roff))!=0)
	{
	  if(*((int*)(x2+doff))>=0){x2=*((void**)(x2+loff));if(*((int*)(x2+doff))==1||*((int*)(x2+doff))==0)break;}
	  else {x2=*((void**)(x2+roff));if(*((int*)(x2+doff))==-1||*((int*)(x2+doff))==0)break;}
	}
      x2=*((void**)(x2+poff));
      while(1){
	if(x2==key){
	  if(lnprt==(void*)0x1)lnprt=*((void**)(key+poff));
	  if(*((void**)(key+poff))==0)root=*((void**)(key+roff));
	  *((void**)((*((void**)(x2+roff)))+poff))=*((void**)(x2+poff));
	  if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
	      *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+roff));
	    else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+roff));
	  }
	  if(*((int*)(key+doff))==-1){*((int*)(x2+doff))=*((int*)((*((void**)(x2+roff)))+doff))==0?0:1;
	    *((int*)((*((void**)(x2+roff)))+doff))=1;}
	  if(*((int*)(key+doff))==-2){*((int*)(x2+doff))=*((int*)((*((void**)(x2+roff)))+doff))==0?-1:0;
	    *((int*)((*((void**)(x2+roff)))+doff))=*((int*)((*((void**)(x2+roff)))+doff))==0?1:0;
	    if(*((int*)(x2+doff))==0)*((int*)((*((void**)(x2+poff)))+doff))=*((int*)((*((void**)(x2+poff)))+doff))+1;
	  }
	  *((void**)(x2+poff))=*((void**)(x2+roff));
	  t=*((void**)(x2+roff));
	  if(*((void**)((*((void**)(x2+roff)))+loff))!=0)
	    *((void**)((*((void**)((*((void**)(x2+roff)))+loff)))+poff))=x2;
	  *((void**)(x2+roff))=*((void**)((*((void**)(x2+roff)))+loff));
	  *((void**)(t+loff))=x2;x2=t;
	  break;
	}
	else  if(*((int*)(x2+doff))==1)
	  {
	    *((void**)((*((void**)(x2+loff)))+poff))=*((void**)(x2+poff));
	    if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		*((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+loff));
	      else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+loff));
	    }
	    *((void**)(x2+poff))=*((void**)(x2+loff));
	    *((int*)(x2+doff))=*((int*)((*((void**)(x2+loff)))+doff))==0?0:-1;
	    *((int*)((*((void**)(x2+loff)))+doff))=-1;
	    t=*((void**)(x2+loff));
	    if(*((void**)((*((void**)(x2+loff)))+roff))!=0)
	      *((void**)((*((void**)((*((void**)(x2+loff)))+roff)))+poff))=x2;
	    *((void**)(x2+loff))=*((void**)((*((void**)(x2+loff)))+roff));
	    *((void**)(t+roff))=x2;x2=t;
	  }
	else if(*((int*)(x2+doff))==-1)
	  {
	    *((void**)((*((void**)(x2+roff)))+poff))=*((void**)(x2+poff));
	    if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		*((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+roff));
	      else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+roff));
	    }
	    *((void**)(x2+poff))=*((void**)(x2+roff));
	    *((int*)(x2+doff))=*((int*)((*((void**)(x2+roff)))+doff))==0?0:1;
	    *((int*)((*((void**)(x2+roff)))+doff))=1;
	    t=*((void**)(x2+roff));
	    if(*((void**)((*((void**)(x2+roff)))+loff))!=0)
	      *((void**)((*((void**)((*((void**)(x2+roff)))+loff)))+poff))=x2;
	    *((void**)(x2+roff))=*((void**)((*((void**)(x2+roff)))+loff));
	    *((void**)(t+loff))=x2;x2=t;
	  }
	x2=*((void**)(x2+poff));
      }
    }
  }
  //key at leaf
  if(*((void**)((*((void**)(key+poff)))+roff))==key)
    {
      *((void**)((*((void**)(key+poff)))+roff))=0;
      (*((int*)((*((void**)(key+poff)))+doff)))++;
      t=*((void**)(key+poff));
      *((void**)(key+poff))=0;
    }
  else{
    *((void**)((*((void**)(key+poff)))+loff))=0;
    (*((int*)((*((void**)(key+poff)))+doff)))--;
    t=*((void**)(key+poff));
    *((void**)(key+poff))=0;
  }
  if(lnprt!=(void*)0x1){
    while(t!=lnprt&&(*((int*)(t+doff))==0))
      {
	if(*((void**)(t+poff))==0)break;
	if(t==*((void**)((*((void**)(t+poff)))+loff)))
	  (*((int*)((*((void**)(t+poff)))+doff)))--;
	else
	  (*((int*)((*((void**)(t+poff)))+doff)))++;
	t=*((void**)(t+poff));
      }
  }
  if(lnprt==(void*)0x1||t==lnprt){
    while(t!=0){
      if(*((int*)(t+doff))==0)
	{
	  if(t!=root){
	    if(t==*((void**)((*((void**)(t+poff)))+loff)))
	      (*((int*)((*((void**)(t+poff)))+doff)))--;
	    else
	      (*((int*)((*((void**)(t+poff)))+doff)))++;
	  }
	  t=*((void**)(t+poff));
	}
      else if(*((int*)(t+doff))==-1||*((int*)(t+doff))==1)break;
      else if (*((int*)(t+doff))==2){
	x2=t;
	while(*((void**)(x2+loff))!=0||*((void**)(x2+roff))!=0)
	  {
	    if(*((int*)(x2+doff))>=0){x2=*((void**)(x2+loff));if(*((int*)(x2+doff))==1||*((int*)(x2+doff))==0)break;}
	    else {x2=*((void**)(x2+roff));if(*((int*)(x2+doff))==-1||*((int*)(x2+doff))==0)break;}
	  }
	x2=*((void**)(x2+poff));
	while(1){
	  if(x2==t){
	    if(*((void**)(t+poff))==0)root=*((void**)(t+loff));
	    *((void**)((*((void**)(x2+loff)))+poff))=*((void**)(x2+poff));
	    if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		*((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+loff));
	      else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+loff));
	    }
	    *((void**)(x2+poff))=*((void**)(x2+loff));
	    *((int*)(x2+doff))=*((int*)((*((void**)(x2+loff)))+doff))==0?1:0;
	    *((int*)((*((void**)(x2+loff)))+doff))=*((int*)((*((void**)(x2+loff)))+doff))==0?-1:0;
	    t=*((void**)(x2+loff));
	    if(*((void**)((*((void**)(x2+loff)))+roff))!=0)
	      *((void**)((*((void**)((*((void**)(x2+loff)))+roff)))+poff))=x2;
	    *((void**)(x2+loff))=*((void**)((*((void**)(x2+loff)))+roff));
	    *((void**)(t+roff))=x2;
	    break;
	  }
	  else  if(*((int*)(x2+doff))==1)
	    {
	      *((void**)((*((void**)(x2+loff)))+poff))=*((void**)(x2+poff));
	      if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		  *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+loff));
		else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+loff));
	      }
	      *((void**)(x2+poff))=*((void**)(x2+loff));
	      *((int*)(x2+doff))=*((int*)((*((void**)(x2+loff)))+doff))==0?0:-1;
	      *((int*)((*((void**)(x2+loff)))+doff))=-1;
	      t2=*((void**)(x2+loff));
	      if(*((void**)((*((void**)(x2+loff)))+roff))!=0)
		*((void**)((*((void**)((*((void**)(x2+loff)))+roff)))+poff))=x2;
	      *((void**)(x2+loff))=*((void**)((*((void**)(x2+loff)))+roff));
	      *((void**)(t2+roff))=x2;x2=t2;
	    }
	  else if(*((int*)(x2+doff))==-1)
	    {
	      *((void**)((*((void**)(x2+roff)))+poff))=*((void**)(x2+poff));
	      if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		  *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+roff));
		else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+roff));
	      }
	      *((void**)(x2+poff))=*((void**)(x2+roff));
	      *((int*)(x2+doff))=*((int*)((*((void**)(x2+roff)))+doff))==0?0:1;
	      *((int*)((*((void**)(x2+roff)))+doff))=1;
	      t2=*((void**)(x2+roff));
	      if(*((void**)((*((void**)(x2+roff)))+loff))!=0)
		*((void**)((*((void**)((*((void**)(x2+roff)))+loff)))+poff))=x2;
	      *((void**)(x2+roff))=*((void**)((*((void**)(x2+roff)))+loff));
	      *((void**)(t2+loff))=x2;x2=t2;
	    }
	  x2=*((void**)(x2+poff));
	}
	if(*((int*)(t+doff))!=0)break;
	if(t!=root){
	  if(t==*((void**)((*((void**)(t+poff)))+loff)))
	    (*((int*)((*((void**)(t+poff)))+doff)))--;
	  else
	    (*((int*)((*((void**)(t+poff)))+doff)))++;
	}
	t=*((void**)(t+poff));
      }
      else if (*((int*)(t+doff))==-2){
	x2=t;
	while(*((void**)(x2+loff))!=0||*((void**)(x2+roff))!=0)
	  {
	    if(*((int*)(x2+doff))>=0){x2=*((void**)(x2+loff));if(*((int*)(x2+doff))==1||*((int*)(x2+doff))==0)break;}
	    else {x2=*((void**)(x2+roff));if(*((int*)(x2+doff))==-1||*((int*)(x2+doff))==0)break;}
	  }
	x2=*((void**)(x2+poff));
	while(1){
	  if(x2==t){
	    if(*((void**)(t+poff))==0)root=*((void**)(t+roff));
	    *((void**)((*((void**)(x2+roff)))+poff))=*((void**)(x2+poff));
	    if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		*((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+roff));
	      else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+roff));
	    }
	    *((void**)(x2+poff))=*((void**)(x2+roff));
	    *((int*)(x2+doff))=*((int*)((*((void**)(x2+roff)))+doff))==0?-1:0;
	    *((int*)((*((void**)(x2+roff)))+doff))=*((int*)((*((void**)(x2+roff)))+doff))==0?1:0;
	    t=*((void**)(x2+roff));
	    if(*((void**)((*((void**)(x2+roff)))+loff))!=0)
	      *((void**)((*((void**)((*((void**)(x2+roff)))+loff)))+poff))=x2;
	    *((void**)(x2+roff))=*((void**)((*((void**)(x2+roff)))+loff));
	    *((void**)(t+loff))=x2;
	    break;
	  }
	  else  if(*((int*)(x2+doff))==1)
	    {
	      *((void**)((*((void**)(x2+loff)))+poff))=*((void**)(x2+poff));
	      if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		  *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+loff));
		else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+loff));
	      }
	      *((void**)(x2+poff))=*((void**)(x2+loff));
	      *((int*)(x2+doff))=*((int*)((*((void**)(x2+loff)))+doff))==0?0:-1;
	      *((int*)((*((void**)(x2+loff)))+doff))=-1;
	      t2=*((void**)(x2+loff));
	      if(*((void**)((*((void**)(x2+loff)))+roff))!=0)
		*((void**)((*((void**)((*((void**)(x2+loff)))+roff)))+poff))=x2;
	      *((void**)(x2+loff))=*((void**)((*((void**)(x2+loff)))+roff));
	      *((void**)(t2+roff))=x2;x2=t2;
	    }
	  else if(*((int*)(x2+doff))==-1)
	    {
	      *((void**)((*((void**)(x2+roff)))+poff))=*((void**)(x2+poff));
	      if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		  *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+roff));
		else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+roff));
	      }
	      *((void**)(x2+poff))=*((void**)(x2+roff));
	      *((int*)(x2+doff))=*((int*)((*((void**)(x2+roff)))+doff))==0?0:1;
	      *((int*)((*((void**)(x2+roff)))+doff))=1;
	      t2=*((void**)(x2+roff));
	      if(*((void**)((*((void**)(x2+roff)))+loff))!=0)
		*((void**)((*((void**)((*((void**)(x2+roff)))+loff)))+poff))=x2;
	      *((void**)(x2+roff))=*((void**)((*((void**)(x2+roff)))+loff));
	      *((void**)(t2+loff))=x2;x2=t2;
	    }
	  x2=*((void**)(x2+poff));
	}
	if(*((int*)(t+doff))!=0)break;
	if(t!=root){
	  if(t==*((void**)((*((void**)(t+poff)))+loff)))
	    (*((int*)((*((void**)(t+poff)))+doff)))--;
	  else
	    (*((int*)((*((void**)(t+poff)))+doff)))++;
	}
	t=*((void**)(t+poff));
      }
    }
  }
  else {
    while(t!=lnprt){
      if(*((int*)(t+doff))==-1||*((int*)(t+doff))==1||*((int*)(t+doff))==0) t=*((void**)(t+poff));
      else if(*((int*)(t+doff))==2){
	x2=t;
	while(*((void**)(x2+loff))!=0||*((void**)(x2+roff))!=0)
	  {
	    if(*((int*)(x2+doff))>=0){x2=*((void**)(x2+loff));if(*((int*)(x2+doff))==1||*((int*)(x2+doff))==0)break;}
	    else {x2=*((void**)(x2+roff));if(*((int*)(x2+doff))==-1||*((int*)(x2+doff))==0)break;}
	  }
	x2=*((void**)(x2+poff));
	while(1){
	  if(x2==t){
	    if(*((void**)(t+poff))==0)root=*((void**)(t+loff));
	    *((void**)((*((void**)(x2+loff)))+poff))=*((void**)(x2+poff));
	    if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		*((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+loff));
	      else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+loff));
	    }
	    *((void**)(x2+poff))=*((void**)(x2+loff));
	    *((int*)(x2+doff))=*((int*)((*((void**)(x2+loff)))+doff))==0?1:0;
	    *((int*)((*((void**)(x2+loff)))+doff))=*((int*)((*((void**)(x2+loff)))+doff))==0?-1:0;
	    t=*((void**)(x2+loff));
	    if(*((void**)((*((void**)(x2+loff)))+roff))!=0)
	      *((void**)((*((void**)((*((void**)(x2+loff)))+roff)))+poff))=x2;
	    *((void**)(x2+loff))=*((void**)((*((void**)(x2+loff)))+roff));
	    *((void**)(t+roff))=x2;
	    break;
	  }
	  else  if(*((int*)(x2+doff))==1)
	    {
	      *((void**)((*((void**)(x2+loff)))+poff))=*((void**)(x2+poff));
	      if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		  *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+loff));
		else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+loff));
	      }
	      *((void**)(x2+poff))=*((void**)(x2+loff));
	      *((int*)(x2+doff))=*((int*)((*((void**)(x2+loff)))+doff))==0?0:-1;
	      *((int*)((*((void**)(x2+loff)))+doff))=-1;
	      t2=*((void**)(x2+loff));
	      if(*((void**)((*((void**)(x2+loff)))+roff))!=0)
		*((void**)((*((void**)((*((void**)(x2+loff)))+roff)))+poff))=x2;
	      *((void**)(x2+loff))=*((void**)((*((void**)(x2+loff)))+roff));
	      *((void**)(t2+roff))=x2;x2=t2;
	    }
	  else if(*((int*)(x2+doff))==-1)
	    {
	      *((void**)((*((void**)(x2+roff)))+poff))=*((void**)(x2+poff));
	      if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		  *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+roff));
		else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+roff));
	      }
	      *((void**)(x2+poff))=*((void**)(x2+roff));
	      *((int*)(x2+doff))=*((int*)((*((void**)(x2+roff)))+doff))==0?0:1;
	      *((int*)((*((void**)(x2+roff)))+doff))=1;
	      t2=*((void**)(x2+roff));
	      if(*((void**)((*((void**)(x2+roff)))+loff))!=0)
		*((void**)((*((void**)((*((void**)(x2+roff)))+loff)))+poff))=x2;
	      *((void**)(x2+roff))=*((void**)((*((void**)(x2+roff)))+loff));
	      *((void**)(t2+loff))=x2;x2=t2;
	    }
	  x2=*((void**)(x2+poff));
	}
	t=*((void**)(t+poff));
      }
      else if(*((int*)(t+doff))==-2){
	x2=t;
	while(*((void**)(x2+loff))!=0||*((void**)(x2+roff))!=0)
	  {
	    if(*((int*)(x2+doff))>=0){x2=*((void**)(x2+loff));if(*((int*)(x2+doff))==1||*((int*)(x2+doff))==0)break;}
	    else {x2=*((void**)(x2+roff));if(*((int*)(x2+doff))==-1||*((int*)(x2+doff))==0)break;}
	  }
	x2=*((void**)(x2+poff));
	while(1){
	  if(x2==t){
	    if(*((void**)(t+poff))==0)root=*((void**)(t+roff));
	    *((void**)((*((void**)(x2+roff)))+poff))=*((void**)(x2+poff));
	    if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		*((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+roff));
	      else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+roff));
	    }
	    *((void**)(x2+poff))=*((void**)(x2+roff));
	    *((int*)(x2+doff))=*((int*)((*((void**)(x2+roff)))+doff))==0?-1:0;
	    *((int*)((*((void**)(x2+roff)))+doff))=*((int*)((*((void**)(x2+roff)))+doff))==0?1:0;
	    t=*((void**)(x2+roff));
	    if(*((void**)((*((void**)(x2+roff)))+loff))!=0)
	      *((void**)((*((void**)((*((void**)(x2+roff)))+loff)))+poff))=x2;
	    *((void**)(x2+roff))=*((void**)((*((void**)(x2+roff)))+loff));
	    *((void**)(t+loff))=x2;
	    break;
	  }
	  else  if(*((int*)(x2+doff))==1)
	    {
	      *((void**)((*((void**)(x2+loff)))+poff))=*((void**)(x2+poff));
	      if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		  *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+loff));
		else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+loff));
	      }
	      *((void**)(x2+poff))=*((void**)(x2+loff));
	      *((int*)(x2+doff))=*((int*)((*((void**)(x2+loff)))+doff))==0?0:-1;
	      *((int*)((*((void**)(x2+loff)))+doff))=-1;
	      t2=*((void**)(x2+loff));
	      if(*((void**)((*((void**)(x2+loff)))+roff))!=0)
		*((void**)((*((void**)((*((void**)(x2+loff)))+roff)))+poff))=x2;
	      *((void**)(x2+loff))=*((void**)((*((void**)(x2+loff)))+roff));
	      *((void**)(t2+roff))=x2;x2=t2;
	    }
	  else if(*((int*)(x2+doff))==-1)
	    {
	      *((void**)((*((void**)(x2+roff)))+poff))=*((void**)(x2+poff));
	      if(*((void**)(x2+poff))!=0){if(x2==*((void**)((*((void**)(x2+poff)))+loff)))
		  *((void**)((*((void**)(x2+poff)))+loff))=*((void**)(x2+roff));
		else *((void**)((*((void**)(x2+poff)))+roff))=*((void**)(x2+roff));
	      }
	      *((void**)(x2+poff))=*((void**)(x2+roff));
	      *((int*)(x2+doff))=*((int*)((*((void**)(x2+roff)))+doff))==0?0:1;
	      *((int*)((*((void**)(x2+roff)))+doff))=1;
	      t2=*((void**)(x2+roff));
	      if(*((void**)((*((void**)(x2+roff)))+loff))!=0)
		*((void**)((*((void**)((*((void**)(x2+roff)))+loff)))+poff))=x2;
	      *((void**)(x2+roff))=*((void**)((*((void**)(x2+roff)))+loff));
	      *((void**)(t2+loff))=x2;x2=t2;
	    }
	  x2=*((void**)(x2+poff));
	}
	t=*((void**)(t+poff));
      }
    }
  }
  return root;
}
void * avl_search(void *root,void *key,size_t loff,size_t roff,int (*cf)(void *a,void *b,void * arg),void * arg)
{
  register void* t=root;
  while(t!=0){
    if(cf(t,key,arg))t=*((void**)(t+loff));
    else if (cf(key,t,arg))t=*((void**)(t+roff));
    else return t;
  }
  return 0;
}
