An implementation of AVL tree [1].

For each node of the tree, height of the left subtree - height of the right subtree = -1, 0 or 1. Also, at any time, in-order traversal
of the tree should produce a sorted output (but not necessarily in the stable order).

The principal benefit of this data structure is that, we can do fast search in O(lg(n)) time among all the elements even without doing any sort.

To compile, type "make".
To execute, type
"./avltest <random number of inserts/deletes/searches> <number of elements to be inserted in (asc/desc)ending order> <height of the AVL tree to check worst case delete scenario>".

Routines:

i) void * avl_insert(void * root, size_t loff, size_t roff, size_t poff, size_t doff, int (*cf)(void * a,void *b,void * arg), void * arg)

root - Root of the AVL tree.
loff - Offset of the pointer to left child.
roff - Offset of the pointer to right child.
poff - Offset of the pointer to parent.
doff - Offset of the integer to store height of left subtree-height of right subtree.
cf - Comparison function. Compares two objects, a and b. If a<b, -1 is returned. If a=b, 0 is returned.
     Else 1 is returned.
arg - Fixed data needed during comparison, if necessary.

Returns the root of the new AVL tree after insertion.

O(lg(n)) for all cases.

ii) void * avl_delete(void * root, void * key, size_t loff, size_t roff, size_t poff, size_t doff)

key - Pointer to the node which has to be deleted.

Other arguments are same as described previously.

Returns the root of the new AVL tree after deletion.

Comparison function is not required. User should attempt to delete a key which is already present in the tree rooted at root.
In other words, the key to be deleted must be reachable from the root.

After deletion, the loff, roff and poff fields in the key will be set to 0.

Trying to delete an already deleted key will return 0.

O(lg(n)) for best case and on average.
However, there could be scenarios (as one generated in test3), where deletion of one leaf node (or a node above a leaf) will trigger rotations at all levels of
the tree up to the root and for each level we also have to go down and rotate trees rooted at each sublevel.
Then runtime complexity becomes O((lg(n))^2).

iii) void * avl_search(void * root, void * key, size_t loff, size_t roff, size_t poff, size_t doff, int (*cf)(void * a,void *b,void * arg), void * arg)

Returns the pointer to the node matching the key. In case of duplicates, only the one reached first will be returned. Null if none found.

O(lg(n)) for all cases.

First test performs several random insertions, deletions (non-trivial, i.e., we count only cases where deleted keys are not being deleted again) and searches (non-trivial, i.e., we count only cases where searched element is not the root itself) in an AVL tree. Reports average time taken.

Second test shows that if we insert n distinct elements in ascending or descending order, height of the final tree will be exactly floor(lg(n)). 

Third test creates an AVL tree to show the worst case deletion scenario requiring O(h^2)(h=height of the tree) number of rotations.

References

[1] Adelson-Velsky, Georgy; Landis, Evgenii (1962). "An algorithm for the organization of information". Proceedings of the USSR Academy of Sciences (in Russian). 146: 263–266. English translation by Myron J. Ricci in Soviet Mathematics - Doklady, 3:1259–1263, 1962.
